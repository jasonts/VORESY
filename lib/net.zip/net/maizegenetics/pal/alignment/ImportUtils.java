/*
 * ImportUtils
 */
package net.maizegenetics.pal.alignment;

import net.maizegenetics.util.ExceptionUtils;
import net.maizegenetics.util.Utils;

import java.util.ArrayList;
import java.util.Hashtable;


/**
 * The class imports PAL alignment datatypes from
 * various file formats.
 *
 * @author terry
 */
public class ImportUtils {

    private ImportUtils() {
        // Utility Class - do not instantiate.
    }

    /**
     * Creates an alignment from a Hapmap file
     * @param filename
     * @return alignment
     */
    public static Alignment readFromHapmap(String filename, String chrom) {
        try {
            ArrayList<byte[]>[] theBLOBList = new ArrayList[GdpdmBLOBUtils.totalBLOBtypes];
            for (int i = 0; i < theBLOBList.length; i++) {
                theBLOBList[i] = new ArrayList<byte[]>();
            }
            byte[][] alleleBLOB = null;
            //array for BLOBs holding coverage plus header [taxa][SNPs]
            byte[] positionBLOB = null;
            byte[] SNPidBLOB = null;
//            String[][] chromsAvailable = GdpdmBLOBUtils.getFileInfo(Utils.addSuffixIfNeeded(filename, ".txt"), 2, 0);
            String[][] chromsAvailable = GdpdmBLOBUtils.getFileInfo(filename, 2, 0);
            int[] chromInfo = GdpdmBLOBUtils.getChromInFileInfo(chromsAvailable, chrom);
//            theBLOBList = AllelePositionBLOBUtils.createAllelePositionBLOBsFromHapmap(Utils.addSuffixIfNeeded(filename, ".txt"), theBLOBList, chrom, chromInfo);
            theBLOBList = AllelePositionBLOBUtils.createAllelePositionBLOBsFromHapmap(filename, theBLOBList, chrom, chromInfo);
            if (theBLOBList[0].size() > 1) {
                alleleBLOB = new byte[theBLOBList[0].size()][];
                //array for BLOBs holding SNPs plus header [taxa][SNPs]
                for (int i = 0; i < alleleBLOB.length; i++) {
                    alleleBLOB[i] = theBLOBList[0].get(i);
                }
                positionBLOB = (byte[])theBLOBList[1].get(0);
                SNPidBLOB = theBLOBList[4].get(0);
            }
            return new Pack1Alignment(alleleBLOB, positionBLOB, SNPidBLOB);
        }
        catch (Exception e) {
            throw new IllegalArgumentException("Problem creating Alignment: " + ExceptionUtils.getExceptionCauses(e));
        }
    }

    /**
     * Creates an alignment from all chromosomes in Hapmap file
     * @param filename
     * @return Alignment one combine alignment
     */
    public static Alignment readFromHapmap(String filename) {
        try {
//            String[][] chromsAvailable = GdpdmBLOBUtils.getFileInfo(Utils.addSuffixIfNeeded(filename, ".txt"), 2, 0);
            String[][] chromsAvailable = GdpdmBLOBUtils.getFileInfo(filename, 2, 0);
            //System.out.println(chromsAvailable[1][0]);
            String[] chroms = new String[chromsAvailable.length - 1];
//            int[] chromInfo;
            Alignment[] align = new Alignment[chromsAvailable.length - 1];
            for (int i = 1; i < chromsAvailable.length; i++) {
                chroms[i - 1] = chromsAvailable[i][0];
            }
            ArrayList<byte[]>[][] theBLOBList = new ArrayList[chroms.length][GdpdmBLOBUtils.totalBLOBtypes];
            for (int i = 0; i < theBLOBList.length; i++) {
                for (int j = 0; j < theBLOBList[i].length; j++) {
                    theBLOBList[i][j] = new ArrayList<byte[]>();
                }
            }
//            chromInfo = GdpdmBLOBUtils.getChromInFileInfo(chromsAvailable, chrom);
//            theBLOBList = AllelePositionBLOBUtils.createAllelePositionBLOBsFromHapmap(Utils.addSuffixIfNeeded(filename, ".txt"), theBLOBList, chroms, chromsAvailable);
            theBLOBList = AllelePositionBLOBUtils.createAllelePositionBLOBsFromHapmap(filename, theBLOBList, chroms, chromsAvailable);
            for (int i = 0; i < theBLOBList.length; i++) {
                byte[][] alleleBLOB = null;
                //array for BLOBs holding coverage plus header [taxa][SNPs]
                byte[] positionBLOB = null;
                byte[] SNPidBLOB = null;
                if (theBLOBList[i][0].size() > 1) {
                    alleleBLOB = new byte[theBLOBList[i][0].size()][];
                    //array for BLOBs holding SNPs plus header [taxa][SNPs]
                    for (int j = 0; j < alleleBLOB.length; j++) {
                        alleleBLOB[j] = theBLOBList[i][0].get(j);
                    }
                    positionBLOB = (byte[])theBLOBList[i][1].get(0);
                    SNPidBLOB = theBLOBList[i][4].get(0);
                }
                align[i] = new Pack1Alignment(alleleBLOB, positionBLOB, SNPidBLOB);
            }
            //return align;
            if(align.length==1) return align[0];
            return CombineAlignment.getInstance(align);
        }
        catch (Exception e) {
            throw new IllegalArgumentException("Problem creating Alignment: " + ExceptionUtils.getExceptionCauses(e));
        }
    }

    public static Pack1Alignment readFromLZMA(String filenameRoot) {
        throw new UnsupportedOperationException("Unsupported Operation");
    }

    /**
     * Reads data BLOBs from a given zip file
     * @param filenameRoot
     * @return Alignment
     */
    public static Alignment readFromZip(String filenameRoot) {
        try {
            ArrayList<byte[]>[] theBLOBList = new ArrayList[GdpdmBLOBUtils.totalBLOBtypes];
            for (int i = 0; i < theBLOBList.length; i++) {
                theBLOBList[i] = new ArrayList<byte[]>();
            }
            byte[][] alleleBLOB = null;
            //array for BLOBs holding coverage plus header [taxa][SNPs]
            byte[] positionBLOB = null;
            byte[] SNPidBLOB = null;
            theBLOBList = GdpdmBLOBUtils.readBLOBFromZip(Utils.addSuffixIfNeeded(filenameRoot, ".zip"), theBLOBList);
            if (theBLOBList[0].size() > 0) {
                alleleBLOB = new byte[theBLOBList[0].size()][];
                //array for BLOBs holding SNPs plus header [taxa][SNPs]
                for (int i = 0; i < alleleBLOB.length; i++) {
                    alleleBLOB[i] = theBLOBList[0].get(i);
                }
                positionBLOB = (byte[])theBLOBList[1].get(0);
                if (theBLOBList[4].size() == 0) {
                    SNPidBLOB = new byte[1030];
                    SNPidBLOB[GdpdmBLOBUtils.blobTypeField[0]] = 0x35;
                }
                else {
                    SNPidBLOB = theBLOBList[4].get(0);
                }
            }
//            System.out.println(alleleBLOB.length);
//            System.out.println(SNPidBLOB.length);
            return new Pack1Alignment(alleleBLOB, positionBLOB, SNPidBLOB);
        }
        catch (Exception e) {
            throw new IllegalArgumentException("Problem creating Alignment: " + ExceptionUtils.getExceptionCauses(e));
        }
    }

    /**
     * Creates an alignment from BLOBs in a gzip compressed file
     * @param fileName name of gzip file
     * @return Alignment
     */

public static Alignment readFromGZIP(String fileName) {
        try {
            ArrayList<byte[]>[] theBLOBList = new ArrayList[GdpdmBLOBUtils.totalBLOBtypes];
            for (int i = 0; i < theBLOBList.length; i++) {
                theBLOBList[i] = new ArrayList<byte[]>();
            }
            byte[][] alleleBLOB = null;
            byte[] positionBLOB = null;
            byte[] SNPidBLOB = null;
            theBLOBList = GdpdmBLOBUtils.readBLOBfromGZIP(Utils.addSuffixIfNeeded(fileName, ".gz"), theBLOBList);
            if (theBLOBList[0].size() > 0) {
                alleleBLOB = new byte[theBLOBList[GdpdmBLOBUtils.alleleBLOBtype - 49].size()][];
                for (int i = 0; i < alleleBLOB.length; i++) {
                    alleleBLOB[i] = theBLOBList[GdpdmBLOBUtils.alleleBLOBtype - 49].get(i);
                }
                positionBLOB = (byte[])theBLOBList[GdpdmBLOBUtils.allelePositionBLOBtype - 49].get(0);
                if (theBLOBList[GdpdmBLOBUtils.SNPIdBLOBtype - 49].size() == 0) {
                    SNPidBLOB = new byte[1030];
                    SNPidBLOB[GdpdmBLOBUtils.blobTypeField[0]] = 0x35;
                }
                else {
                    SNPidBLOB = theBLOBList[GdpdmBLOBUtils.SNPIdBLOBtype - 49].get(0);
                }
            }
            return new Pack1Alignment(alleleBLOB, positionBLOB, SNPidBLOB);
        }
        catch (Exception e) {
            throw new IllegalArgumentException("Problem creating Alignment: " + ExceptionUtils.getExceptionCauses(e));
        }
    }

    /**
     * Creates an alignment from a set of Plink files and desired chromosome
     * @param PEDfileName
     * @param MAPfileName
     * @param chrom
     * @return an alignment for desired chromosome
     */
    public static Alignment readFromPLINK(String PEDfileName, String MAPfileName, String chrom) {
        try {
            ArrayList<byte[]>[] theBLOBList = new ArrayList[GdpdmBLOBUtils.totalBLOBtypes];
            for (int i = 0; i < theBLOBList.length; i++) {
                theBLOBList[i] = new ArrayList<byte[]>();
            }
            byte[][] alleleBLOB = null;
            //array for BLOBs holding coverage plus header [taxa][SNPs]
            byte[] positionBLOB = null;
            byte[] SNPidBLOB = null;
            String[][] chromsAvailable = GdpdmBLOBUtils.getFileInfo(Utils.addSuffixIfNeeded(MAPfileName, ".map"), 0, 1);
            int[] chromInfo = GdpdmBLOBUtils.getChromInFileInfo(chromsAvailable, chrom);
            int numTaxa = GdpdmBLOBUtils.countLinesInFile(Utils.addSuffixIfNeeded(PEDfileName, ".ped"));
            theBLOBList = AllelePositionBLOBUtils.createAllelePositionBLOBsFromPlink(Utils.addSuffixIfNeeded(PEDfileName, ".ped"), Utils.addSuffixIfNeeded(MAPfileName, ".map"), theBLOBList, chrom, chromInfo, numTaxa);
            if (theBLOBList[0].size() > 1) {
                alleleBLOB = new byte[theBLOBList[0].size()][];
                //array for BLOBs holding SNPs plus header [taxa][SNPs]
                for (int i = 0; i < alleleBLOB.length; i++) {
                    alleleBLOB[i] = theBLOBList[0].get(i);
                }
                positionBLOB = (byte[])theBLOBList[1].get(0);
                SNPidBLOB = theBLOBList[4].get(0);
            }
            return new Pack1Alignment(alleleBLOB, positionBLOB, SNPidBLOB);
        }
        catch (Exception e) {
            throw new IllegalArgumentException("Problem creating Alignment: " + ExceptionUtils.getExceptionCauses(e));
        }
    }

    /**
     * Creates an alignment for each chromosome in a .map/.ped file pair
     * @param PEDfileName
     * @param MAPfileName
     * @return an alignment for each chromosome
     */
    public static Alignment readFromPLINK(String PEDfileName, String MAPfileName) {
        try {
            String[][] chromsAvailable = GdpdmBLOBUtils.getFileInfo(Utils.addSuffixIfNeeded(MAPfileName, ".map"), 0, 1);
//            int[] chromInfo;
            int numTaxa = GdpdmBLOBUtils.countLinesInFile(Utils.addSuffixIfNeeded(PEDfileName, ".ped"));
            String[] chroms = new String[chromsAvailable.length];
            Alignment[] align = new Alignment[chromsAvailable.length];
            for (int i = 0; i < chromsAvailable.length; i++) {
                chroms[i] = chromsAvailable[i][0];
            }
//            chrom = chromsAvailable[i][0];
//            chromInfo = GdpdmBLOBUtils.getChromInFileInfo(chromsAvailable, chrom);
            ArrayList<byte[]>[][] theBLOBList = new ArrayList[chroms.length][GdpdmBLOBUtils.totalBLOBtypes];
            for (int i = 0; i < theBLOBList.length; i++) {
                for (int j = 0; j < theBLOBList[i].length; j++) {
                    theBLOBList[i][j] = new ArrayList<byte[]>();
                }
            }
            byte[][] alleleBLOB = null;
            //array for BLOBs holding coverage plus header [taxa][SNPs]
            byte[] positionBLOB = null;
            byte[] SNPidBLOB = null;
            theBLOBList = AllelePositionBLOBUtils.createAllelePositionBLOBsFromPlink(Utils.addSuffixIfNeeded(PEDfileName, ".ped"), Utils.addSuffixIfNeeded(MAPfileName, ".map"), theBLOBList, chroms, chromsAvailable, numTaxa);
            for (int i = 0; i < theBLOBList.length; i++) {
                if (theBLOBList[i][0].size() > 1) {
                    alleleBLOB = new byte[theBLOBList[i][0].size()][];
                    //array for BLOBs holding SNPs plus header [taxa][SNPs]
                    for (int j = 0; j < alleleBLOB.length; j++) {
                        alleleBLOB[j] = theBLOBList[i][0].get(j);
                    }
                    positionBLOB = (byte[])theBLOBList[i][1].get(0);
                    SNPidBLOB = theBLOBList[i][4].get(0);
                }
                align[i] = new Pack1Alignment(alleleBLOB, positionBLOB, SNPidBLOB);
            }
            //return align;
            return CombineAlignment.getInstance(align);
        }
        catch (Exception e) {
            throw new IllegalArgumentException("Problem creating Alignment: " + ExceptionUtils.getExceptionCauses(e));
        }
    }

    /**
     * Creates an alignment from a set of Flapjack files and desired chromosome
     * @param genotypeFileName
     * @param MAPfileName
     * @param chrom
     * @return an alignment for desired chromosome
     */
    public static Alignment readFromFlapjack(String genotypeFileName, String MAPfileName, String chrom) {
        try {
            ArrayList<byte[]>[] theBLOBList = new ArrayList[GdpdmBLOBUtils.totalBLOBtypes];
            for (int i = 0; i < theBLOBList.length; i++) {
                theBLOBList[i] = new ArrayList<byte[]>();
            }
            byte[][] alleleBLOB = null;
            //array for BLOBs holding coverage plus header [taxa][SNPs]
            byte[] positionBLOB = null;
            byte[] SNPidBLOB = null;
            String[][] chromsAvailable = GdpdmBLOBUtils.getFileInfo(Utils.addSuffixIfNeeded(MAPfileName, ".map"), 1, 0);
            int[] chromInfo = GdpdmBLOBUtils.getChromInFileInfo(chromsAvailable, chrom);
            int numTaxa = GdpdmBLOBUtils.countLinesInFile(Utils.addSuffixIfNeeded(genotypeFileName, ".geno")) - 1;
            theBLOBList = AllelePositionBLOBUtils.createAllelePositionBLOBsFromFlapjack(Utils.addSuffixIfNeeded(genotypeFileName, ".geno"), Utils.addSuffixIfNeeded(MAPfileName, ".map"), theBLOBList, chrom, chromInfo, numTaxa);
            if (theBLOBList == null) {
                theBLOBList = AllelePositionBLOBUtils.createAllelePositionBLOBsFromFlapjack(Utils.addSuffixIfNeeded(genotypeFileName, ".geno"), Utils.addSuffixIfNeeded(MAPfileName, ".map"), theBLOBList, chrom, chromInfo, numTaxa);
            }
            if (theBLOBList[0].size() > 1) {
                alleleBLOB = new byte[theBLOBList[0].size()][];
                //array for BLOBs holding SNPs plus header [taxa][SNPs]
                for (int i = 0; i < alleleBLOB.length; i++) {
                    alleleBLOB[i] = theBLOBList[0].get(i);
                }
                positionBLOB = (byte[])theBLOBList[1].get(0);
                SNPidBLOB = theBLOBList[4].get(0);
            }
            return new Pack1Alignment(alleleBLOB, positionBLOB, SNPidBLOB);
        }
        catch (Exception e) {
            throw new IllegalArgumentException("Problem creating Alignment: " + ExceptionUtils.getExceptionCauses(e));
        }
    }

    /**
     * Creates a CombineAlignment from Flapjack files
     * Does NOT assume the file is sorted by position and/or chromosome
     * @param genotypeFileName
     * @param MAPfileName
     * @return CombineAlignment
     */
    public static Alignment readFromFlapjack(String genotypeFileName, String MAPfileName) {
        try {
            Object[][] fileInfo = GdpdmBLOBUtils.getFlapjackInfo(MAPfileName);

            // initializing theBLOBList
            ArrayList<byte[]>[][] theBLOBList = new ArrayList[fileInfo.length][GdpdmBLOBUtils.totalBLOBtypes];
            for (int i =0; i < theBLOBList.length; i++) {
                for (int j = 0; j < theBLOBList[i].length; j++) {
                    theBLOBList[i][j] = new ArrayList<byte[]>();
                }
            }

            String[] chromNames = new String[fileInfo.length];
            Hashtable[] tableArray = new Hashtable[fileInfo.length];
            int[] idLengths = new int[fileInfo.length];
            int[] numSites = new int[fileInfo.length];

            int numTaxa = GdpdmBLOBUtils.countLinesInFile(Utils.addSuffixIfNeeded(genotypeFileName, ".geno")) - 1;

            // defining fields describing flapjack file
            for (int i =0; i < fileInfo.length; i++) {
                chromNames[i] = (String)fileInfo[i][0];
                tableArray[i] = (Hashtable)fileInfo[i][1];
                idLengths[i] = ((Integer)fileInfo[i][2]).intValue();
                numSites[i] = tableArray[i].size();
            }

            // populate theBLOBList
            theBLOBList = AllelePositionBLOBUtils.createAllelePositionBLOBsFromFlapjack(Utils.addSuffixIfNeeded(genotypeFileName, ".geno"), Utils.addSuffixIfNeeded(MAPfileName, ".map"), theBLOBList, chromNames, tableArray, idLengths, numSites, numTaxa);

            Alignment[] align = new Alignment[chromNames.length];

            // create alignments
            for (int i = 0; i < theBLOBList.length; i++) {
                byte[][] alleleBLOB = null;
                //array for BLOBs holding coverage plus header [taxa][SNPs]
                byte[] positionBLOB = null;
                byte[] SNPidBLOB = null;
                if (theBLOBList[i][0].size() > 1) {
                    alleleBLOB = new byte[theBLOBList[i][0].size()][];
                    //array for BLOBs holding SNPs plus header [taxa][SNPs]
                    for (int j = 0; j < alleleBLOB.length; j++) {
                        alleleBLOB[j] = theBLOBList[i][0].get(j);
                    }
                    positionBLOB = (byte[])theBLOBList[i][1].get(0);
                    SNPidBLOB = theBLOBList[i][4].get(0);
                }
                align[i] = new Pack1Alignment(alleleBLOB, positionBLOB, SNPidBLOB);
            }
            return CombineAlignment.getInstance(align);
        }
        catch (Exception e) {
            throw new IllegalArgumentException("Problem creating Alignment: " + ExceptionUtils.getExceptionCauses(e));
        }
    }

    /**
     * Creates an array of alignments from a set of Flapjack files
     * @param genotypeFileName
     * @param MAPfileName
     * @return align an array of alignments from selected Flapjack files
     */
    public static Alignment readFromFlapjackOld(String genotypeFileName, String MAPfileName) {
        try {
            String[][] chromsAvailable = GdpdmBLOBUtils.getFileInfo(Utils.addSuffixIfNeeded(MAPfileName, ".map"), 1, 0);
//            int[] chromInfo;
            int numTaxa = GdpdmBLOBUtils.countLinesInFile(Utils.addSuffixIfNeeded(genotypeFileName, ".geno")) - 1;
            String[] chroms = new String[chromsAvailable.length];
            Alignment[] align = new Alignment[chromsAvailable.length];
//            ArrayList<Alignment> align = new ArrayList<Alignment>();
            //ArrayList<byte[]>[] theBLOBList = new ArrayList[GdpdmBLOBUtils.totalBLOBtypes];
            for (int i = 0; i < chromsAvailable.length; i++) {
                chroms[i] = chromsAvailable[i][0];
            }
//            chromInfo = GdpdmBLOBUtils.getChromInFileInfo(chromsAvailable, chrom);
            ArrayList<byte[]>[][] theBLOBList = new ArrayList[chroms.length][GdpdmBLOBUtils.totalBLOBtypes];
            for (int i = 0; i < theBLOBList.length; i++) {
                for (int j = 0; j < theBLOBList[i].length; j++) {
                    theBLOBList[i][j] = new ArrayList<byte[]>();
                }
            }
            theBLOBList = AllelePositionBLOBUtils.createAllelePositionBLOBsFromFlapjack(Utils.addSuffixIfNeeded(genotypeFileName, ".geno"), Utils.addSuffixIfNeeded(MAPfileName, ".map"), theBLOBList, chroms, chromsAvailable, numTaxa);
//            if (theBLOBList == null) {
//                theBLOBList = AllelePositionBLOBUtils.createAllelePositionBLOBsFromFlapjack(Utils.addSuffixIfNeeded(genotypeFileName, ".geno"), Utils.addSuffixIfNeeded(MAPfileName, ".map"), theBLOBList, chroms, chromsAvailable, numTaxa);
//            }
            for (int i = 0; i < theBLOBList.length; i++) {
                byte[][] alleleBLOB = null;
                //array for BLOBs holding coverage plus header [taxa][SNPs]
                byte[] positionBLOB = null;
                byte[] SNPidBLOB = null;
                if (theBLOBList[i][0].size() > 1) {
                    alleleBLOB = new byte[theBLOBList[i][0].size()][];
                    //array for BLOBs holding SNPs plus header [taxa][SNPs]
                    for (int j = 0; j < alleleBLOB.length; j++) {
                        alleleBLOB[j] = theBLOBList[i][0].get(j);
                    }
                    positionBLOB = (byte[])theBLOBList[i][1].get(0);
                    SNPidBLOB = theBLOBList[i][4].get(0);
                }
                align[i] = new Pack1Alignment(alleleBLOB, positionBLOB, SNPidBLOB);
//                Alignment a = new Pack1Alignment(alleleBLOB, positionBLOB, SNPidBLOB);
//                if (a != null) {
//                    align.add(a);
//                }
            }
//            Alignment[] aligns = new Alignment[align.size()];
//            for (int i = 0; i < align.size(); i++) {
//                aligns[i] = align.get(i);
//            }
            //return align;
            return CombineAlignment.getInstance(align);
        }
        catch (Exception e) {
            throw new IllegalArgumentException("Problem creating Alignment: " + ExceptionUtils.getExceptionCauses(e));
        }
    }

    public static Alignment createPack1AlignmentFromFile(ArrayList<String> fileList) {
        ArrayList<byte[]>[] theBLOBList = new ArrayList[GdpdmBLOBUtils.totalBLOBtypes];
        for (int i = 0; i < theBLOBList.length; i++) {
            theBLOBList[i] = new ArrayList<byte[]>();
        }
        byte[][] coverageBLOB = null, alleleBLOB = null;
        //array for BLOBs holding coverage plus header [taxa][SNPs]
        byte[] refSeqBLOB = null, positionBLOB = null, SNPidBLOB = null, qualityBLOB = null;
        try {
            for (String theFileName : fileList) {
                if (theFileName.endsWith(".gz")) {
                    theBLOBList = GdpdmBLOBUtils.readBLOBfromGZIP(theFileName, theBLOBList);
                } else if (theFileName.endsWith(".7z")) {
                    theBLOBList = GdpdmBLOBUtils.readBLOBfromLZMA(theFileName, theBLOBList);
                } else if (theFileName.endsWith(".txt")) {
                    String[][] chromsAvailable = GdpdmBLOBUtils.getFileInfo(theFileName, 2, 0);
                    String chrom = chromsAvailable[1][0];
                    int[] chromInfo = GdpdmBLOBUtils.getChromInFileInfo(chromsAvailable, chrom);
                    theBLOBList = AllelePositionBLOBUtils.createAllelePositionBLOBsFromHapmap(theFileName, theBLOBList, chrom, chromInfo);
                } else {
                    throw new IllegalArgumentException("Unknown file type.  Must be .map, .ped, .txt, .zip, or .7z.");
                }
            }
        } catch (Exception e) {
            throw new IllegalArgumentException("Problem reading Alignment: " + ExceptionUtils.getExceptionCauses(e));
        }
        if ((theBLOBList == null)) {
            throw new IllegalArgumentException("File empty.");
        }
        else if ((theBLOBList.length == 0)) {
            throw new IllegalArgumentException("No data in this file.");
        }
        //todo put reading coverage here.
        if (theBLOBList[0].size() > 1) {
            alleleBLOB = new byte[theBLOBList[0].size()][];
            //array for BLOBs holding SNPs plus header [taxa][SNPs]
            for (int i = 0; i < alleleBLOB.length; i++) {
                alleleBLOB[i] = theBLOBList[0].get(i);
            }
            positionBLOB = (byte[]) theBLOBList[1].get(0);
            if (theBLOBList[4].size() == 0) {
                SNPidBLOB = new byte[1030];
                SNPidBLOB[GdpdmBLOBUtils.blobTypeField[0]] = 0x35;
            }
            else {
                SNPidBLOB = theBLOBList[4].get(0);
            }
          //  SNPidBLOB = theBLOBList[4].get(0);
        }
        if (theBLOBList[2].size() > 0) {
            coverageBLOB = new byte[theBLOBList[2].size()][];
            for (int i = 0; i < alleleBLOB.length; i++) {
                coverageBLOB[i] = theBLOBList[2].get(i);
            }
        }
        if(!theBLOBList[6].isEmpty()) {
            qualityBLOB=(byte[]) theBLOBList[6].get(0);
        }
        try {
            if (coverageBLOB == null) {
                return new Pack1Alignment(alleleBLOB, positionBLOB, SNPidBLOB, qualityBLOB);
            } else {
                return new Pack1AlignmentWithCoverage(alleleBLOB, positionBLOB, SNPidBLOB, coverageBLOB, refSeqBLOB);
            }
        } catch (Exception e) {
            throw new IllegalArgumentException("Problem creating Alignment: " + ExceptionUtils.getExceptionCauses(e));
        }

    }

    public static Alignment createPack1AlignmentFromFile(String alleleFileName, String coverageFileName, String refseqFileName) {
        ArrayList<String> fileList = new ArrayList<String>();
        if (alleleFileName.length() != 0) {
            fileList.add(alleleFileName);
        }
        if ((coverageFileName != null) && (coverageFileName.length() != 0)) {
            fileList.add(coverageFileName);
        }
        if ((refseqFileName != null) && (refseqFileName.length() != 0)) {
            fileList.add(refseqFileName);
        }
        return createPack1AlignmentFromFile(fileList);
    }
}
