package net.maizegenetics.gwas.NAMgwas;

import java.util.regex.Pattern;

public class Analysis {
	public static final String ANALYSIS_STEPWISE_NOMISSING = "stepwise";
	public static final String ANALYSIS_BOOTSTRAP = "bootstrap";
	public static final String ANALYSIS_HAPLOTYPE = "haplotype";
	public static final String ANALYSIS_SINGLESNP = "singlesnp";
	public static final String ANALYSIS_PERMUTATIONS = "permutations";

	public static void main(String[] args) {
		fitModels(args);
	}
	
	public static void fitModels(String[] args) {
		String filename = null;
		Pattern equal = Pattern.compile("=");

		if (args.length == 0) {
			return;
		}
		else {
			for (String arg : args) {
				String[] parsed = equal.split(arg);
				if (parsed[0].startsWith("file")) filename = parsed[1];
			}

			if (filename == null) {
				System.err.println("No file name specified. Exiting program.");
				System.exit(-1);
			}
			else {
				FileNames files = new FileNames(filename);
				for (int chr = 1; chr <=10; chr++) {
					if (files.analysis.equalsIgnoreCase("project")) {
						if (files.projectedFile[chr - 1] != null) {
							ModelFitter fitter = new ModelFitter(chr, files);
							fitter.init();
							fitter.createProjectionData();
						}
					} else if (files.chrmodel[chr - 1] != null) {
						if (files.threaded && !files.analysis.equalsIgnoreCase(ANALYSIS_BOOTSTRAP)) {
							createModelFitterInstance(chr, files).start();
						} else {
							//debug
							System.out.println("testing chromosome " + chr);
							
							ModelFitter theFitter = createModelFitterInstance(chr, files);
							theFitter.init();
							theFitter.testSnps();
						}
					}
				}
			}
		}

	}

	public static ModelFitter createModelFitterInstance(int chr, FileNames files) {
		if (files.analysis.length() == 0) return  null;
		String name = files.analysis.substring(0, 4);
		if (name.equalsIgnoreCase("step")) {
			files.analysis = ANALYSIS_STEPWISE_NOMISSING;
			return new ModelFitterForwardRegression(chr, files);
		}
		if (name.equalsIgnoreCase("hapl")) {
			//not implemented
			System.out.println("Haplotype analysis is not implemented.");
			System.exit(0);
//			files.analysis = ANALYSIS_HAPLOTYPE;
		}
		if (name.equalsIgnoreCase("sing")) {
			files.analysis = ANALYSIS_SINGLESNP;
			return new ModelFitterNoMissingData(chr, files);
		}
		if (name.equalsIgnoreCase("perm")) {
//			files.analysis = ANALYSIS_PERMUTATIONS;
			System.out.println("Permutation testing is not implemented.");
			System.exit(0);
		}
		if (name.equalsIgnoreCase("boot")) {
			return new ModelFitterBootstrapForward(chr, files);
		}
		return null;
	}

}
