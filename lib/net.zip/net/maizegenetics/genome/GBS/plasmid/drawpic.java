/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.maizegenetics.genome.GBS.plasmid;

import java.io.File;
import net.maizegenetics.genome.GBS.repeat.visualizeGlm;
/**
 *
 * @author fl262
 */
public class drawpic {
	public static void main (String[] args) {
		String infileS = "E:/Research/plasmid/IBM/SAS/result/processed/filtered_glm.txt";
		String outfileS = "E:/temp/b.png";
		new visualizeGlm(new File(infileS), new File(outfileS));
	}

}
