package net.maizegenetics.gbs.homology;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;
import java.util.regex.Pattern;
import net.maizegenetics.genome.BaseEncoder;



/**
 * Takes a directory of qseq files and processes the file into count files by taxaName
 * based on a key file
 * Developer: ed
 * 
 */
public class ParseBarcodeRead {
    private static int chunkSize=BaseEncoder.chunkSize;
    //String baseDir="E:/SolexaAnal/";
    private int maximumMismatchInBarcodeAndOverhang=0;
    public static final String[] overhang={"CAGC","CTGC"};
    static String nullS="AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
//    static String[] fullCutSites={"GCAGC","GCTGC"};
    public static final String[] likelyReadEnd={"GCTGGATC","GCAGGATC","GCTGAGAT", "GCAGAGAT","GCAGC","GCTGC"};
 //   public static final String[] likelyReadEnd={"GCTGC"};
    public static final Pattern minimalEnd=Pattern.compile("GC[AT]G");

    //Original design CWGGATCGGAAGAGCGGTTCAGCAGGAATGCCGAG  -- Common Adapter
    //Redesign  CWGAGATCGGAAGAGCGGTTCAGCAGGAATGCCGAG  -- Common Adapter

    static int maxBarcodeLength=8;
    private Barcode[] theBarcodes;
    private long[] quickBarcodeList;
    private HashMap<Long,Integer> quickMap;



    public ParseBarcodeRead(String keyFile, int minQual, boolean fastq, String flowcell, String lane) {
        int totalBarcodes=setupBarcodeFiles(new File(keyFile),  flowcell,  lane);
        System.out.println("Total barcodes found in flowcell:"+totalBarcodes);
       // processDirectoryForCounting(new File(keyFile), minQual, fastq);
    }


/* Reads in an Illumina key file, creates a linear array of @link Barcode objects
 * representing the barcodes in the key file, then creates a hash map containing
 * indices from the linear array indexed by sequence.
 *
 * @param keyFile Illumina key file.
 * @param flowcell Only barcodes from this flowcell will be added to the array.
 * @param lane Only barcodes from this lane will be added to the array.
 * @return Number of barcodes in the array.
  */
    private int setupBarcodeFiles(File keyFile, String flowcell, String lane) {
        try{
            BufferedReader br=new BufferedReader(new FileReader(keyFile),65536);
            ArrayList<Barcode> theBarcodesArrayList=new ArrayList<Barcode>();
            String temp;
            while (((temp = br.readLine()) != null)) {
                String[] s=temp.split("\\s");  //split by whitespace
                if(s[0].equals(flowcell)&&s[1].equals(lane)) {
                    Barcode theBC=new Barcode(s[2],overhang,s[3], flowcell, lane);
                    theBarcodesArrayList.add(theBC);
                    System.out.println(theBC.barcodeS+" "+theBC.taxaName);
                }
            }
            theBarcodes=new Barcode[theBarcodesArrayList.size()];
            theBarcodesArrayList.toArray(theBarcodes);
            Arrays.sort(theBarcodes);
            quickBarcodeList=new long[theBarcodes.length*2];
            quickMap = new HashMap();
            for (int i = 0; i < theBarcodes.length; i++) {
                    quickBarcodeList[i*2]=theBarcodes[i].barOverLong[0];
                    quickBarcodeList[i*2+1]=theBarcodes[i].barOverLong[1];
                    quickMap.put(theBarcodes[i].barOverLong[0], i);
                    quickMap.put(theBarcodes[i].barOverLong[1], i);
            }
            Arrays.sort(quickBarcodeList);

/*
            quickBarcodeList=new long[theBarcodes.length];
            for(int i=0; i<theBarcodes.length; i++) {
                quickBarcodeList[i]=theBarcodes[i].barOverLong[0];
                //System.out.println(quickBarcodeList[i]+" "+BaseEncoder.getSequenceFromLong(quickBarcodeList[i]));
            }
 *
 */
        } catch(Exception e){
            System.out.println("Error with setupBarcodeFiles: "+e);
        }

        return theBarcodes.length;
    }

    private Barcode findBestBarcode(String queryS, int maxDivergence) {
        long query=BaseEncoder.getLongFromSeq(queryS.substring(0, chunkSize));
        //note because the barcodes are polyA after the sequence, they should always
        //sort ahead of the hit, this is the reason for the -(closestHit+2)
        int closestHit=Arrays.binarySearch(quickBarcodeList, query);
 //       System.out.println("findBestBarcode:"+queryS.substring(0, chunkSize)+":"+closestHit);
        if(closestHit>-2) return null; //hit or perfect
        if((query&quickBarcodeList[-(closestHit+2)])!=quickBarcodeList[-(closestHit+2)]) return null;
        int index =quickMap.get(quickBarcodeList[-(closestHit+2)]);
  //      System.out.println(theBarcodes[index].barcodeS);
        return theBarcodes[index];
	//note to see if it is a perfect match you can just bit AND
        //


    }

    /**
     * The barcode libraries used for this study can include two types of extraneous sequence
     * at the end of reads.  The first are chimeras created with the free ends.  These will
     * recreate the restriction site.  The second are short regions (less than 64bp), so that will they
     * will contain a portion of site and the universal adapter.
     * This finds the first of site in likelyReadEnd, keeps the restriction site overhang and then sets everything
     * to polyA afterwards
     * @param seq An unprocessed tag sequence.
     * @return returnValues An array of four strings: (1)Unprocessed tag, (2)Cut site position, (3)Processed tag, (4)Padded tag.
     */
     public static String[] removeSeqAfterSecondCutSite(String seq) {
         //this looks for a second restriction site, and then turns the remaining sequence to AAAA
        int pos=9999;
        int startSearchBase=3;
	String[] returnValues = new String[4];

	for(String fcs: likelyReadEnd) {
            int p=seq.indexOf(fcs, startSearchBase);
            if((p>startSearchBase)&&(p<pos)) {
                pos=p;
            }
        }
	returnValues[0] = seq;
	if(pos==9999){
	    returnValues[1] = null;
	    returnValues[2] = null;
	 }else{
	    returnValues[1] = String.valueOf(pos+4);
	    returnValues[2] = seq.substring(0, pos+4);
	 }

        if(pos<chunkSize*2) {
            int slen=seq.length();
              //  System.out.print("seq:"+seq);
            seq=seq.substring(0,pos+4)+nullS.substring(0, slen-pos-4);//this makes all bases after the second site AAAAAAA
                //we cut after base 4 as it could ligated to an adapter or another sequence
                //this is the length of the overhang+1

              //   System.out.println(" rseq:"+seq);
        }
	returnValues[3] = seq;
        return returnValues;
    }

  

    public ReadBarcodeResult divideSolexaFileToTaxaCountList(String seqS, String qualS, boolean fastq, int minQual) {
            long[] read=new long[2];
            if((minQual>0)&&(qualS!=null)) {
                int firstBadBase=BaseEncoder.getFirstLowQualityPos(qualS, minQual);
                if(firstBadBase<(64+8)) return null;
            }
            int miss = -1;
            if (fastq) { miss=seqS.indexOf('N'); } else { miss=seqS.indexOf('.'); }
            if((miss!=-1)&&(miss<(maxBarcodeLength+2*chunkSize))) return null;  //bad sequence so skip
            Barcode bestBarcode=findBestBarcode(seqS,maximumMismatchInBarcodeAndOverhang);
            if(bestBarcode==null) return null;  //overhang missing so skip
            String genomicSeq=seqS.substring(bestBarcode.barLength, seqS.length());
	    String[] tagProcessingResults = removeSeqAfterSecondCutSite(genomicSeq);
            String hap=tagProcessingResults[3];  //this is slow 20% of total time.   Tag, cut site processed, padded with poly-A
            read[0]=BaseEncoder.getLongFromSeq(hap.substring(0,chunkSize));
            read[1]=BaseEncoder.getLongFromSeq(hap.substring(chunkSize,2*chunkSize));
            ReadBarcodeResult rbr=new ReadBarcodeResult(read, (byte)64, bestBarcode.getTaxaName());
            return rbr;  //TODO need to replace with ReadResult

    }

     public ReadBarcodeResult divideSolexaFileToTaxaCountListX(String seqS, String qualS, boolean fastq, int minQual) {
            long[] read=new long[2];
            if((minQual>0)&&(qualS!=null)) {
                int firstBadBase=BaseEncoder.getFirstLowQualityPos(qualS, minQual);
                if(firstBadBase<(64+8)) return null;
            }
            int miss = -1;
            if (fastq) { miss=seqS.indexOf('N'); } else { miss=seqS.indexOf('.'); }
            if((miss!=-1)&&(miss<(maxBarcodeLength+2*chunkSize))) return null;  //bad sequence so skip
            Barcode bestBarcode=findBestBarcode(seqS,maximumMismatchInBarcodeAndOverhang);
            if(bestBarcode==null) return null;  //overhang missing so skip
            String genomicSeq=seqS.substring(bestBarcode.barLength, seqS.length());
            read=BaseEncoder.getLongArrayFromSeq(seqS);
	    String[] tagProcessingResults = removeSeqAfterSecondCutSite(genomicSeq);
            String hap=tagProcessingResults[3];  //this is slow 20% of total time.   Tag, cut site processed, padded with poly-A
            read[0]=BaseEncoder.getLongFromSeq(hap.substring(0,chunkSize));
            read[1]=BaseEncoder.getLongFromSeq(hap.substring(chunkSize,2*chunkSize));
            ReadBarcodeResult rbr=new ReadBarcodeResult(read, (byte)64, bestBarcode.getTaxaName());
            return rbr;  //TODO need to replace with ReadResult
    }

    public int getBarCodeCount() {
        return theBarcodes.length;
    }

    public Barcode getTheBarcodes(int index) {
        return theBarcodes[index];
    }



}



