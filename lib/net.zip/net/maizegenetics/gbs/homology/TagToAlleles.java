/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.maizegenetics.gbs.homology;

/**
 *Header:  Tags Count, number of longs per sequence
*Tag Sequence in long
*Allele Sequence in long
* Relationship
*    Error to Real
*   Real to Real
 * @author edbuckler
 */
public class TagToAlleles {
    int tagLengthInLong=2;  //TODO fully implement on reading
    byte[] tagLength;  //TODO record length of each tag
    long[][] tags;
    long[][] alleles;
    byte[] relationship;


}
