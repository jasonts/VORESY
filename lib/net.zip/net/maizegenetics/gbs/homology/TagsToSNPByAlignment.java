/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.maizegenetics.gbs.homology;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;
import net.maizegenetics.gbs.maps.TagsOnPhysicalMap;
import net.maizegenetics.gbs.tagdist.MutableSimpleAlignment;
import net.maizegenetics.gbs.tagdist.TagsByTaxa;
import net.maizegenetics.gbs.tagdist.TagsByTaxa.FilePacking;
import net.maizegenetics.gbs.tagdist.TagsByTaxaBit;
import net.maizegenetics.genome.BaseEncoder;
import net.maizegenetics.pal.alignment.Alignment;
import net.maizegenetics.pal.alignment.AnnotatedAlignmentUtils;
import net.maizegenetics.pal.alignment.ExportUtils;
import net.maizegenetics.pal.alignment.Locus;
import net.maizegenetics.pal.alignment.SimpleAlignment;
import net.maizegenetics.pal.datatype.DataType;
import net.maizegenetics.pal.datatype.IUPACNucleotides;
import net.maizegenetics.pal.ids.SimpleIdGroup;
import org.biojava3.alignment.Alignments;
import org.biojava3.alignment.template.Profile;
import org.biojava3.core.sequence.DNASequence;
import org.biojava3.core.sequence.compound.AmbiguityDNACompoundSet;
import org.biojava3.core.sequence.compound.NucleotideCompound;
import org.biojava3.core.util.ConcurrencyTools;

/**
 *
 * @author edbuckler
 */
public class TagsToSNPByAlignment {
    static int minTaxaCnt=0;

    public TagsToSNPByAlignment() {

    }

    

    public static void main(String[] args) {
        System.out.println(BaseEncoder.removePolyAFromEnd("CGTTGTGTGCAAAA"));
        String tagMapFileS="/Users/edbuckler/SolexaAnal/GBS/reftags/14FCGBS.tg.ndup.bin";
        String tagsByTaxaS="/Users/edbuckler/SolexaAnal/GBS/test/bitIBM110210.dist.txt";
  //      String tagsByTaxaS="/Users/edbuckler/SolexaAnal/GBS/test/HiSeq282_110214.dist.txt";
     //   String tagsByTaxaS="/Users/edbuckler/SolexaAnal/GBS/dist/NAMsort_110303.bibin";
     //   String tagsByTaxaS="/Users/edbuckler/SolexaAnal/GBS/test/IBM110210.dist.txt";
    //    String outHapMap="/Users/edbuckler/SolexaAnal/GBS/test/HiSeq282wHet_110215.hmp.txt";
        String outHapMap="/Users/edbuckler/SolexaAnal/GBS/test/NAMwHet_110315st.hmp.txt";

       TagsOnPhysicalMap theTOPM=new TagsOnPhysicalMap(tagMapFileS,true);  //Reads tag map file into an object
     //  XORtest(theTOPM);
       TagsByTaxa theTBT=new TagsByTaxaBit(tagsByTaxaS,FilePacking.Text);
      // TagsByTaxa theTBT=new TagsByTaxaBitFileMap(tagsByTaxaS);
       theTOPM.sortTable(true);
       theTOPM.printRows(5, true, true);
       int maxSize=1000000;
       MutableSimpleAlignment theMSA=createMutableAlignment(theTBT, maxSize+100);
    //   ArrayList<String> ts=new ArrayList<String>();
       TreeMap<Integer, String> ts = new TreeMap<Integer, String>();
       int lastIndex=theTOPM.getReadIndexForPositionIndex(0);
       int[] currPos=theTOPM.getPositionArray(lastIndex);
       if(currPos[0]>0) {ts.put(0,BaseEncoder.getSequenceFromLong(theTOPM.getTag(lastIndex)));}
       else currPos=null;
       int countSNPs=0, countLoci=0;
       long time=System.currentTimeMillis();
       for (int i = 0; (i < theTOPM.getSize())&&(countSNPs<maxSize); i++) {
           int ri=theTOPM.getReadIndexForPositionIndex(i);
           if(Arrays.equals(currPos, theTOPM.getPositionArray(ri))) {
               long[] tag=theTOPM.getTag(ri);
               int hit=theTBT.getTagIndex(tag);
               int cnt=(hit>-1)?theTBT.getNumberOfTaxaWithTag(hit):-1;
               //System.out.println(hit+":"+cnt);
               //String trimmedSeq=BaseEncoder.getSequenceFromLong(tag).substring(0, theTOPM.getTagLength(ri));
               String trimmedSeq=BaseEncoder.removePolyAFromEnd(BaseEncoder.getSequenceFromLong(tag));
               if(cnt>minTaxaCnt) ts.put(hit,trimmedSeq);
              // System.out.println(Arrays.toString(currPos)+":"+BaseEncoder.getSequenceFromLong(theTOPM.getTag(ri)));
           } else {
               if(ts.size()>1) {
                  // String[] s=new String[ts.size()];
                   Alignment a=getSNPsFromSequenceAlignment(ts);
                   if(a.getSiteCount()<=5) {
                       addSiteToMutableAlignment(theTBT,currPos[0], currPos[1], currPos[2], a, theMSA);
                       countSNPs+=a.getSiteCount();
                       countLoci++;
                       if(theMSA.getSiteCount()%100==0) {
                           double rate=(double)theMSA.getSiteCount()/(double)(System.currentTimeMillis()-time);
                           System.out.printf("Chr:%d Pos:%d Loci=%d SNPs=%d rate=%g SNP/millisec %n",currPos[0], currPos[2], countLoci, countSNPs, rate);
                          // System.out.println(theMSA.toString());
                       }
                      // System.out.println(theMSA.toString());
                   }
               }
               ts.clear();
               currPos=theTOPM.getPositionArray(ri);
               if(currPos[0]>0) {
                   long[] tag=theTOPM.getTag(ri);
                    int hit=theTBT.getTagIndex(tag);
                    int cnt=(hit>-1)?theTBT.getNumberOfTaxaWithTag(hit):-1;
                    if(cnt>minTaxaCnt) ts.put(hit,BaseEncoder.getSequenceFromLong(tag));
               //    System.out.println(Arrays.toString(currPos)+":"+BaseEncoder.getSequenceFromLong(theTOPM.getTag(ri)));
               } else currPos=null;
           }
           //if(theTOPM.getPositionArray(ri))

       }
       theMSA.sortSiteByPhysicalPosition();
       ExportUtils.writeToHapmap(theMSA, false, outHapMap, '\t');
       ConcurrencyTools.shutdown();
    }



    private static MutableSimpleAlignment createMutableAlignment(TagsByTaxa theTBT, int maxSites) {
        Locus[] theL=new Locus[11];
        for (int i = 0; i < theL.length; i++) {
            theL[i]=new Locus(""+i, ""+i, -1, -1, null, null);
        }
        MutableSimpleAlignment theMSA=new MutableSimpleAlignment(theTBT.getTaxaNames(),maxSites, theL);
        return theMSA;
    }

    private synchronized static void addSiteToMutableAlignment(TagsByTaxa theTBT, int chromosome, int strand,
            int startPos, Alignment tagAlignment, MutableSimpleAlignment theMSA) {
//        System.out.printf("%d %d %d %n",chromosome, strand, startPos);
//        System.out.println(tagAlignment.toString());
//        System.out.println("PosInLocus:"+tagAlignment.getPositionInLocus(0));
        for (int s = 0; s < tagAlignment.getSiteCount(); s++) {
            int currSite=theMSA.getNextFreeSite();
            theMSA.setLocusOfSite(currSite, (byte)chromosome);  //this is a cheap trick
            int position=(strand>0)?(startPos+tagAlignment.getPositionInLocus(s)):(startPos-tagAlignment.getPositionInLocus(s));
            theMSA.setPositionOfSite(currSite, position);
            theMSA.setStrandOfSite(currSite, (byte)strand);
            for (int tg = 0; tg < tagAlignment.getSequenceCount(); tg++) {
                int tagIndex=Integer.parseInt(tagAlignment.getTaxaName(tg));
                byte currBase=tagAlignment.getBase(tg, s);
//                System.out.println("Allele: "+currBase+" :"+(char)currBase);
                for (int tx = 0; tx < theTBT.getTaxaCount(); tx++) {
                    if(theTBT.getReadCountForTagTaxon(tagIndex, tx)>0) {
                        byte cb=theMSA.getBase(tx, currSite);
                        if(cb==DataType.UNKNOWN_BYTE) theMSA.setBase(tx, currSite, currBase);
                        else {
                            byte[] snpValue={cb,currBase};
 //                           System.out.println("HetSite:"+(char)cb+":"+(char)currBase+":"+(char)IUPACNucleotides.getDegerateSNPByteFromTwoSNPs(snpValue));
                            theMSA.setBase(tx, currSite, IUPACNucleotides.getDegerateSNPByteFromTwoSNPs(snpValue));
                        }
 //                       System.out.printf("SetAllele: %d %d %d %n",tx, currSite, currBase);
                    }
                }

            }

        }

    }



    private static Alignment getSNPsFromSequenceAlignment(TreeMap<Integer, String> tagSeqMap)  {
        List<DNASequence> lst = new ArrayList<DNASequence>();
        for (Entry<Integer,String> id : tagSeqMap.entrySet()) {
            DNASequence ds=new DNASequence(id.getValue());
            ds.setOriginalHeader(id.getKey().toString());
            ds.setCompoundSet(AmbiguityDNACompoundSet.getDNACompoundSet());
        //    System.out.println(ds.toString()+":"+ds.getCompoundSet().toString());
            lst.add(ds);
        }
        Profile<DNASequence, NucleotideCompound> profile = Alignments.getMultipleSequenceAlignment(lst);
    //    System.out.printf("Clustalw:%n%s%n", profile.toString(Profile.StringFormat.PDBWEB));
//
//        System.out.printf("Clustalw:%n%s%n", profile);
      //  System.out.println(Arrays.toString(profile.getCompoundCountsAt(3)));
        String[] aseqs=new String[tagSeqMap.size()];
        String[] names=new String[tagSeqMap.size()];
        for (int i = 1; i <= aseqs.length; i++) {
            aseqs[i-1]=profile.getAlignedSequence(i).getSequenceAsString();
            names[i-1]=profile.getAlignedSequence(i).getOriginalSequence().getOriginalHeader();
        }
        Alignment aa=SimpleAlignment.getInstance(new SimpleIdGroup(names),aseqs, new IUPACNucleotides());
//        System.out.println(aa.toString());
        Alignment faa=AnnotatedAlignmentUtils.removeConstantSitesIgnoreGapsMissing(aa);
//        System.out.println(faa.toString());
//        Alignment iaa=AnnotatedAlignmentUtils.extractIndels(aa, true);
//        System.out.println(iaa.toString());
    //    ConcurrencyTools.shutdown();
        return faa;
    }



}
