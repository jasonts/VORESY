/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.maizegenetics.gbs.homology;

import net.maizegenetics.genome.BaseEncoder;

/**
 *
 * @author edbuckler
 */
public class ReadBarcodeResult {
    long[] read;
    byte length;
    String taxonName;

    public ReadBarcodeResult(long[] read, byte length, String taxon) {
        this.read = read;
        this.length = length;
        this.taxonName = taxon;
    }

    @Override
    public String toString() {
        return BaseEncoder.getSequenceFromLong(read)+":"+(int)length+":"+taxonName;
    }

    public byte getLength() {
        return length;
    }

    public long[] getRead() {
        return read;
    }

    public String getTaxonName() {
        return taxonName;
    }
}
