/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package net.maizegenetics.gbs.pipeline;

import net.maizegenetics.gbs.maps.dep_ReadsWPhysicalMap;
import net.maizegenetics.gbs.tagdist.CombineReadCounts;
import net.maizegenetics.gbs.tagdist.TagCounts;
import net.maizegenetics.gbs.tagdist.TagsByTaxaByte;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import net.maizegenetics.genome.BaseEncoder;
import net.maizegenetics.gbs.homology.AlleleInfo;
import net.maizegenetics.gbs.maps.MapHaplotypes;
import net.maizegenetics.gbs.tagdist.MutableAlignmentForGBS;
import net.maizegenetics.gbs.tagdist.TagsByTaxa.FilePacking;
import net.maizegenetics.pal.alignment.Alignment;
import net.maizegenetics.pal.alignment.FilterAlignment;
import net.maizegenetics.pal.alignment.GdpdmBLOBUtils;
import net.maizegenetics.pal.alignment.ImportUtils;

/**
 *
 * @author edbuckler
 */
public class GBSPipelinesJG {

    public GBSPipelinesJG() {
    }

    public static void main(String[] args) {
//        createRefMarkerMap();
//        looseMatchesToWorkingReads();
//        makeReadCountsFileForTwoIBMFlowCells();
//        performVD();
//        loadExternalVD();
//        mergeVDs();
//        makeReadCountsTeosinte();
//        makeTeosinteGenoFile();
//        writeTeosinteAlleleInfoFile();
//        alignB73Htrhm();
//        alignB73();
//        analyzeIBMforGBSmethodsPaper();
//        testDuplicateTaxon();
//        makeReadsByTaxaTwoIBMFlowCells();
//        makePhysicalMapForTwoIBMFlowCells();
        //mapTwoIBMFlowCellsVs55KFrame();
    }

    public static void createRefMarkerMap() {
        /**
         * Virtual digest of a reference
         */
        String baseDir = "/usr/local/maizediv/";
        String refGenomeFasta = baseDir + "genome/maize_agp_v2.fasta";
        String refGenomeDigested = baseDir + "genome/virtual_digest/B73refVirtualV2.rwpm.bin";
        String qseqDir = baseDir + "illumina/434LFAAXX/qseq";
        String qseqKey = baseDir + "illumina/434LFAAXX/434LFAAXX_Multiplex_key.txt";
        String parsedTaxaDir = baseDir + "illumina/434LFAAXX/taxa";
        String collapsedTaxaDir = baseDir + "illumina/434LFAAXX/taxacollapse";
        String readsWorthMapping = baseDir + "illumina/434LFAAXX/counts/ReadCountsMin10_100421b.bin";
        String obsCommonReadsOnMap = baseDir + "illumina/434LFAAXX/counts/commonReadMap_100422.rwpm.bin";

        dep_VirtualDigester vd = new dep_VirtualDigester(new File(refGenomeFasta), new File(refGenomeDigested));
        System.gc();

        //Sort the physical map for quick searching and save
        dep_ReadsWPhysicalMap rwpmVD = new dep_ReadsWPhysicalMap(refGenomeDigested, true);
        rwpmVD.sortTable(true);
        rwpmVD.writeCountFile(new File(refGenomeDigested));
        System.gc();

        //Read and parse qseq or fastq file
       ParseBarcodeFiles pbf=new ParseBarcodeFiles(qseqDir,qseqKey,parsedTaxaDir,10,false);
       System.gc();

        //Take a GBSReads folder and collapse the folder by sorting and collapse identical reads
       TagCounts rc=new TagCounts(parsedTaxaDir, collapsedTaxaDir, 1, true, false, false);
       System.gc();

    //Fuse multiple taxa files into one, minimum frequency is 2, binary=true, simpleFilter=false
    //Use the physical genome as a base, and then add high quality reads to the top
       dep_ReadsWPhysicalMap theRef=new dep_ReadsWPhysicalMap(refGenomeDigested,true);
       theRef.sortTable(true);
//       CombineReadCounts shff=new CombineReadCounts(theRef,qualcollapsedTaxaDir,combinedFlowcellsReads, 2, true, false);
       System.gc();

       //Found that using the reference reads as all greater than 2 in frequency was the best
       //so readsWorthMapping=combinedFlowcellsReads
       //now use all the reads, but only populate with those with perfect matches
//       CreateReadsByTaxa crbt=new CreateReadsByTaxa(readsWorthMapping, collapsedTaxaDir, theReadsByTaxaAll, true);
       System.gc();

//       TagsByTaxaByte theRBT=new TagsByTaxaByte(theReadsByTaxaAll,true);
//       theRBT.writeDistFile(new File(theReadsByTaxaMinCount), true, 5);
//       theRBT.writeReadCountFile(new File(readsWorthMapping), true, 5);
//       System.gc();

      //Create an empty mapping list from the readList

       TagCounts rc3=new TagCounts(readsWorthMapping, true);
       dep_ReadsWPhysicalMap rwpm1=new dep_ReadsWPhysicalMap(rc3);
       rwpm1.writeCountFile(new File(obsCommonReadsOnMap));
       System.gc();

//       dep_ReadsWPhysicalMap rwpm2=new dep_ReadsWPhysicalMap(obsCommonReadsOnMap,true);


         dep_ReadsWPhysicalMap rwpmTest2=MapHaplotypes.blastUsingPhysicalMap(new dep_ReadsWPhysicalMap(refGenomeDigested,true),
                  new dep_ReadsWPhysicalMap(obsCommonReadsOnMap,true),3);
        rwpmTest2.writeCountFile(new File(obsCommonReadsOnMap));


//         TagsByTaxaByte theRBT2=new TagsByTaxaByte(theReadsByTaxaMinCount,true);
         System.gc();
        System.out.println("rwpmTest2 memory"+rwpmTest2);
//         rwpmTest2=MapHaplotypes.checkWorkingMapWithGenetic(baseGeneticMap,rwpmTest2,theRBT2,true,0.00001);
//         rwpmTest2.writeCountFile(new File(obsCommonReadsWithGenetic1),Integer.MAX_VALUE, true,true,0.01f,true);


    }

    public static void looseMatchesToWorkingReads() {
        String baseDir = "/usr/local/maizediv/";
        String refGenomeDigested = baseDir + "genome/virtual_digest/B73refVirtualV2.rwpm.bin";
        String mo17CtgsDigested = baseDir + "genome/Mo17/Mo17_454AllContigs_chr0.cut.bin";
        String GBSFrameWorkMapSuffix = baseDir + "illumina/434LFAAXX/GBS_framework/commonReadMap_100508t";
        String qseqDir = baseDir + "illumina/434LFAAXX/qseq";
        String qseqKey = baseDir + "illumina/434LFAAXX/434LFAAXX_Multiplex_key.txt";
        String parsedTaxaDir = baseDir + "illumina/434LFAAXX/taxa";
        String collapsedTaxaDir = baseDir + "illumina/434LFAAXX/taxacollapse";
        String referenceReadsFile = baseDir + "illumina/434LFAAXX/counts/RefReads_Q10_B73_Mo17_20100525.bin";
        String stringentReadsByTaxaFile = baseDir + "illumina/434LFAAXX/counts/ReadByTaxa_stringent_10taxa_20100525.bin";
        String RefRwPMFile = baseDir + "illumina/434LFAAXX/counts/RefReadsWPM_Q10_B73_Mo17_20100525.bin";
        String fullGeneticOuputFile = baseDir + "illumina/434LFAAXX/counts/geneticOutputWSkim_stringentRBT_20100526.txt";


        // use IBM good run to pick initial set of reference (working) reads: minQual 10
        ParseBarcodeFiles pbf = new ParseBarcodeFiles(qseqDir, qseqKey, parsedTaxaDir, 10, false);
        TagCounts rc = new TagCounts(parsedTaxaDir, collapsedTaxaDir, 1, true, false, false);

        // create reference reads from the B73 & Mo17 virtual digests combined with the high quality GBS reads from above
        dep_ReadsWPhysicalMap b73Ref = new dep_ReadsWPhysicalMap(refGenomeDigested, true);
        b73Ref.sortTable(true);

        dep_ReadsWPhysicalMap mo17Ref=new dep_ReadsWPhysicalMap(mo17CtgsDigested, true);
        mo17Ref.sortTable(true);

        TagCounts referenceReads = new CombineReadCounts(b73Ref, mo17Ref, collapsedTaxaDir, referenceReadsFile, 1, true);

        // now get all of the GBS reads, regardless of quality
        pbf = new ParseBarcodeFiles(qseqDir, qseqKey, parsedTaxaDir, 0, false);
        rc = new TagCounts(parsedTaxaDir, collapsedTaxaDir, 1, true, false, false);

        // populate the TagsByTaxaByte with reads that match perfectly, only write the reads that have data in 10 or more taxa
        CreateReadsByTaxa myCRBT = new CreateReadsByTaxa(referenceReadsFile, collapsedTaxaDir, stringentReadsByTaxaFile, 10, true);

        // create an empty mapping list from the reference readList
        TagCounts refReads=new TagCounts(referenceReadsFile, true);
        dep_ReadsWPhysicalMap RefRwPM=new dep_ReadsWPhysicalMap(refReads);
        RefRwPM.writeCountFile(new File(RefRwPMFile));
        System.gc();

        // populate the physical positions on the reference rwpm
        dep_ReadsWPhysicalMap rwpmRef=MapHaplotypes.blastUsingPhysicalMap(new dep_ReadsWPhysicalMap(refGenomeDigested,true),
                  new dep_ReadsWPhysicalMap(RefRwPMFile,true),3);
        rwpmRef.writeCountFile(new File(RefRwPMFile));

        // load the framework (imputed) genetic map
        Alignment[] GBSFrameworkMap = new Alignment[10];
        for (int chromosome = 1; chromosome <= 10; chromosome++) {
            GBSFrameworkMap[chromosome - 1] = ImportUtils.readFromHapmap(GBSFrameWorkMapSuffix + ".imc" + chromosome + ".hmp.txt");
            System.out.println("Chromosome " + chromosome + " GeneticMap  Taxa:" + GBSFrameworkMap[chromosome - 1].getSequenceCount() + " Sites:" + GBSFrameworkMap[chromosome - 1].getSiteCount());
        }

        // open the reference rwpm and stringent RBT
        RefRwPM = new dep_ReadsWPhysicalMap(RefRwPMFile, true);
        TagsByTaxaByte stringentRBT = new TagsByTaxaByte(stringentReadsByTaxaFile, FilePacking.Byte);

        // map the high stringency RBT
        MapHaplotypes.mapWorkingMapWithGenetic(GBSFrameworkMap, RefRwPM, stringentRBT, 0.02, 10, 10, fullGeneticOuputFile);

        // look for looser matching reads (try 48, then 32 bases): compare mapping with and wout the looser reads against the reference map

    }

    public static void performVD() {
        String Mo17JGI454Chr80Contigfile = "Q:/SolexaAnal/IBM/virtual_digests/JGI_Mo17_454/Mo17JGI454AllContigs_chr70.fasta";
        String Mo17JGI454Chr80VDfile = "Q:/SolexaAnal/IBM/virtual_digests/JGI_Mo17_454/Mo17JGI454VD_chr70.rwpm.bin";
        String AGPv1Fastafile = "/usr/local/maizediv/genome/maize_agp_v1.fasta";
        String AGPv1VDfile = "/usr/local/maizediv/genome/virtual_digest/B73refVirtualV1.rwpm.bin";
        String AGPv2Fastafile = "Q:/SolexaAnal/AGPv2/maize_agp_v2.fasta";
        String AGPv2VDfile = "Q:/SolexaAnal/IBM/virtual_digests/AGPv2/B73AGPv2VD.rwpm.bin";
        dep_VirtualDigester myVDigester=new dep_VirtualDigester(new File(AGPv1Fastafile), new File(AGPv1VDfile));
        System.gc();

        //Sort the physical map for quick searching and save
        dep_ReadsWPhysicalMap rwpmMyVD = new dep_ReadsWPhysicalMap(AGPv1VDfile, true);
        rwpmMyVD.sortTable(true);
        rwpmMyVD.writeCountFile(new File(AGPv1VDfile));
        System.gc();
    }

    public static void loadExternalVD() {
        String CSHLB73454VDfile = "Q:/SolexaAnal/IBM/virtual_digests/CSHL_Shiran_B73/454_tags_processed.txt";  // 1135193 tags
        String CSHLB73454VDoutfile = "Q:/SolexaAnal/IBM/virtual_digests/CSHL_Shiran_B73/B73_454_VD.rwpm.bin";
        String BGI_Mo17VDfile = "Q:/SolexaAnal/IBM/virtual_digests/BGI_Mo17/Mo17_virtualDigest_processed.txt"; // 3761353 tags
        String BGI_Mo17VDoutfile = "Q:/SolexaAnal/IBM/virtual_digests/BGI_Mo17/Mo17_BGI_VD.rwpm.bin";
        String B73K50VD454file = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/ShiranVDs/454asm_k50_tags.txt";  //  7680513 tags
        String B73K50VD454outfile = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/ShiranVDs/454k50VD.rwpm.bin";
        String B73K60VD454file = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/ShiranVDs/454asm_k60_tags.txt";  //  8539236 tags
        String B73K60VD454outfile = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/ShiranVDs/454k60VD.rwpm.bin";
        String B73K80VD454file = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/ShiranVDs/454asm_k80_tags.txt";  //  8580948 tags
        String B73K80VD454outfile = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/ShiranVDs/454k80VD.rwpm.bin";
        String B73K96VD454file = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/ShiranVDs/454asm_k96_tags.txt";  // 10426055 tags
        String B73K96VD454outfile = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/ShiranVDs/454k96VD.rwpm.bin";
        String flcDNAvdFile = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/ShiranVDs/flcdna_tags.txt";     //   733425 tags; 727955 with ACGT only
        String flcDNAvdOutFile = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/ShiranVDs/flcdna.rwpm.bin";

        int nRows = 727955;  //  <-----******CHANGE THIS ACCORDING TO THE SIZE OF EACH VD
        int maxTags = 10500000 + 1;
        String temp = "";
        String[] cells = new String[5];
        String ReadStr;
        long[] parts = new long[2];
        int chunkSize = BaseEncoder.chunkSize;
        byte chromosome;
        char strand; //'+', '-', "?"
        int posMin, posMax;

        try {
            FileReader fr = new FileReader(flcDNAvdFile); //  <-----CHANGE infile for the particular VD
            BufferedReader br = new BufferedReader(fr);
            dep_ReadsWPhysicalMap rwpmExternalVD = new dep_ReadsWPhysicalMap(nRows);
            int nAdded = 0;
            while ((br.ready()) && (rwpmExternalVD.getTagCount() < (maxTags - 2))) {
                temp = br.readLine().trim();
                cells = temp.split("\t");
                ReadStr = cells[0];
                parts[0] = BaseEncoder.getLongFromSeq(ReadStr.substring(0, chunkSize));
                parts[1] = BaseEncoder.getLongFromSeq(ReadStr.substring(chunkSize, 2 * chunkSize));
                chromosome = Byte.parseByte(cells[1]);
                strand = cells[2].charAt(0);
                posMin = Integer.parseInt(cells[3]);
                posMax = Integer.parseInt(cells[4]);
                if ((parts[0] != -1) && (parts[1] != -1)) {  // Nb: virtual reads containing N will encode as null
                    rwpmExternalVD.addHaplotype(parts, chromosome, (byte) strand, posMin, posMax, Short.MIN_VALUE, (byte) 0);
                    ++nAdded;
                }
            }
            System.out.println();
            System.out.println(nAdded + " reads added to rwpmExternalVD");
            System.out.println();
            rwpmExternalVD.sortTable(true);
            rwpmExternalVD.writeCountFile(new File(flcDNAvdOutFile));  //  <-----CHANGE outfile for the particular VD
            rwpmExternalVD.printRows(1000);

        } catch (Exception e) {
            System.out.println("Catch: e=" + e);
            e.printStackTrace();
            System.exit(1);
        }
    }

    public static void mergeVDs() {
        String AGPv2VDfile = "Q:/SolexaAnal/IBM/virtual_digests/AGPv2/B73AGPv2VD.rwpm.bin";
        String Mo17JGI454VDfile = "Q:/SolexaAnal/IBM/virtual_digests/JGI_Mo17_454/Mo17JGI454VD_chr70.rwpm.bin";
        String B73CSHL454VDfile = "Q:/SolexaAnal/IBM/virtual_digests/CSHL_Shiran_B73/B73_454_VD.rwpm.bin";
        String BGIMo17VDfile = "Q:/SolexaAnal/IBM/virtual_digests/BGI_Mo17/Mo17_BGI_VD.rwpm.bin";
        String MasterVDoutfile = "Q:/SolexaAnal/IBM/virtual_digests/MasterVD.rwpm.bin";
        
        dep_ReadsWPhysicalMap rwpmMasterVD = new dep_ReadsWPhysicalMap(AGPv2VDfile, true, 15620352);

        dep_ReadsWPhysicalMap Mo17JGI454VD = new dep_ReadsWPhysicalMap(Mo17JGI454VDfile, true);
        for (int i = 0; i < Mo17JGI454VD.getTagCount(); i++) {
            if (rwpmMasterVD.addHaplotype(Mo17JGI454VD.getReadWithPosition(i)) < 0) {
                System.out.println("Ran out of room in rwpmMasterVD. Current size = " + rwpmMasterVD.getSize());
            }
        }
        Mo17JGI454VD = null;
        System.gc();

        dep_ReadsWPhysicalMap B73CSHL454VD = new dep_ReadsWPhysicalMap(B73CSHL454VDfile, true);
        for (int i = 0; i < B73CSHL454VD.getTagCount(); i++) {
            if (rwpmMasterVD.addHaplotype(B73CSHL454VD.getReadWithPosition(i)) < 0) {
                System.out.println("Ran out of room in rwpmMasterVD. Current size = " + rwpmMasterVD.getSize());
            }
        }
        B73CSHL454VD = null;
        System.gc();

        dep_ReadsWPhysicalMap BGIMo17VD = new dep_ReadsWPhysicalMap(BGIMo17VDfile, true);
        for (int i = 0; i < BGIMo17VD.getTagCount(); i++) {
            if (rwpmMasterVD.addHaplotype(BGIMo17VD.getReadWithPosition(i)) < 0) {
                System.out.println("Ran out of room in rwpmMasterVD. Current size = " + rwpmMasterVD.getSize());
            }
        }
        BGIMo17VD = null;
        System.gc();

        rwpmMasterVD.sortTable(true);
        rwpmMasterVD.writeCountFile(new File(MasterVDoutfile));
        rwpmMasterVD.printRows(10000);
    }

    public static void makeReadCountsFileForTwoIBMFlowCells() {
        String qseqDirIBM1 =           "/cbsufsrv3/data2/maizediv/illumina/434LFAAXX/qseq";
        String qseqKeyIBM1 =           "/cbsufsrv3/data2/maizediv/illumina/434LFAAXX/434LFAAXX_Multiplex_key.txt";
        String parsedTaxaDirIBM1 =     "/cbsufsrv3/data2/maizediv/illumina/434LFAAXX/taxa";
        String collapsedTaxaDirIBM1 =  "/cbsufsrv3/data2/maizediv/illumina/434LFAAXX/taxacollapse";
        String combinedReadsFileIBM1 = "/cbsufsrv3/data2/maizediv/illumina/434LFAAXX/counts/CombReads_IBM1_Min5_20100525.bin";

        String qseqDirIBM2 =           "/cbsufsrv3/data2/maizediv/illumina/434GFAAXX/qseq";
        String qseqKeyIBM2 =           "/cbsufsrv3/data2/maizediv/illumina/434GFAAXX/434GFAAXX_Multiplex_key.txt";
        String parsedTaxaDirIBM2 =     "/cbsufsrv3/data2/maizediv/illumina/434GFAAXX/taxa";
        String collapsedTaxaDirIBM2 =  "/cbsufsrv3/data2/maizediv/illumina/434GFAAXX/taxacollapse";
        String combinedReadsFileIBM2 = "/cbsufsrv3/data2/maizediv/illumina/434GFAAXX/counts/CombReads_IBM2_Min5_20100525.bin";

        String combinedReadsFileIBM =  "/cbsufsrv3/data2/maizediv/illumina/434GFAAXX/counts/CombReads_BothIBM_Min10_20100525.bin";

        // START WITH IBM2 (434GFAAXX)
        // Read and parse qseq or fastq file using low stringency Q score (maximal # of reads)
        System.out.println();
        System.out.println("Parsing the qseq files for IBM2 (434GFAAXX)");
        System.out.println("-------------------------------------------");
        ParseBarcodeFiles pbfIBM2=new ParseBarcodeFiles(qseqDirIBM2, qseqKeyIBM2, parsedTaxaDirIBM2, 0, false);
        pbfIBM2 = null;
        System.gc();

        // condense the taxa TagCounts files by sorting and collapsing identical reads
        System.out.println();
        System.out.println("Collapsing the ReadCounts files for each taxon in IBM2 (434GFAAXX)");
        System.out.println("------------------------------------------------------------------");
        TagCounts rcIBM2=new TagCounts(parsedTaxaDirIBM2, collapsedTaxaDirIBM2, 1, true, false, false);
        rcIBM2 = null;
        System.gc();

        // Fuse multiple taxa files into one, minimum frequency is 5, binary=true (reads that are seen repeatedly are hopefully real)
        System.out.println();
        System.out.println("Combining the ReadCounts files across all taxa in IBM2 (434GFAAXX)");
        System.out.println("------------------------------------------------------------------");
        CombineReadCounts crcIBM2=new CombineReadCounts(collapsedTaxaDirIBM2, combinedReadsFileIBM2, 5, true);
        crcIBM2 = null;
        System.gc();

        // REPEAT FOR IBM1 (434LFAAXX)
        // Read and parse qseq or fastq file using low stringency Q score (maximal # of reads)
        System.out.println();
        System.out.println("Parsing the qseq files for IBM1 (434LFAAXX)");
        System.out.println("-------------------------------------------");
        ParseBarcodeFiles pbfIBM1=new ParseBarcodeFiles(qseqDirIBM1, qseqKeyIBM1, parsedTaxaDirIBM1, 0, false);
        System.gc();

        // condense the taxa TagCounts files by sorting and collapsing identical reads
        System.out.println();
        System.out.println("Collapsing the ReadCounts files for each taxon in IBM1 (434LFAAXX)");
        System.out.println("------------------------------------------------------------------");
        TagCounts rcIBM1=new TagCounts(parsedTaxaDirIBM1, collapsedTaxaDirIBM1, 1, true, false, false);
        rcIBM1 = null;
        System.gc();

        // Fuse multiple taxa files into one, minimum frequency is 5, binary=true (reads that are seen repeatedly are hopefully real)
        System.out.println();
        System.out.println("Combining the ReadCounts files across all taxa in IBM1 (434LFAAXX)");
        System.out.println("------------------------------------------------------------------");
        CombineReadCounts crcIBM1=new CombineReadCounts(collapsedTaxaDirIBM1, combinedReadsFileIBM1, 5, true);
        crcIBM1 = null;
        System.gc();

        // COMBINE TOGETHER IBM1 & 1BM2
        System.out.println();
        System.out.println("Combining IBM1 & IBM2 (minCount of 10)");
        System.out.println("--------------------------------------");
        TagCounts crcIBM = new CombineReadCounts(combinedReadsFileIBM1, combinedReadsFileIBM2, combinedReadsFileIBM, 10, true);
    }

    public static void makeReadsByTaxaTwoIBMFlowCells() {
        String parsedTaxaDirIBM =     "/cbsufsrv3/data2/maizediv/illumina/IBM/taxa";
        String collapsedTaxaDirIBM =  "/usr/local/maizediv/illumina/IBM/taxacollapse";
        String combinedReadsFileIBM = "/usr/local/maizediv/illumina/IBM/counts/CombReads_BothIBM_Min10_20100525.bin";
        String rbtFileIBM =           "/usr/local/maizediv/illumina/IBM/counts/rbtIBM_Min10_20100827.bin";

        // condense the taxa TagCounts files by sorting and collapsing identical reads
        System.out.println();
        System.out.println("Collapsing the ReadCounts files for each taxon in IBM (2 flow cells)");
        System.out.println("-------------------------------------------------------------------");
        TagCounts rcIBM=new TagCounts(parsedTaxaDirIBM, collapsedTaxaDirIBM, 1, true, false, true); //binary=true,simpleFilter=false,combineIdenticalTaxa=true
        rcIBM = null;
        System.gc();

        CreateReadsByTaxa teoRBT=new CreateReadsByTaxa(combinedReadsFileIBM, collapsedTaxaDirIBM, rbtFileIBM, true);
    }

    public static void makePhysicalMapForTwoIBMFlowCells() {
        String combinedReadsFileIBM =  "/usr/local/maizediv/illumina/IBM/counts/CombReads_BothIBM_Min10_20100525.bin";
        String AGPv2VDfile =           "/usr/local/maizediv/genome/virtual_digest/B73refVirtualV2.rwpm.bin";
        String phyMappedReadsFileIBM = "/usr/local/maizediv/illumina/IBM/counts/phyMappedReadsIBMDiv20_20100827.bin";

        dep_ReadsWPhysicalMap rwpmIBMmin10=MapHaplotypes.blastUsingPhysicalMap(new dep_ReadsWPhysicalMap(AGPv2VDfile,true),
                  new dep_ReadsWPhysicalMap(new TagCounts(combinedReadsFileIBM, true)), 20);  // allow 20 mismatches
        rwpmIBMmin10.sortTable(false); // sort by position
        rwpmIBMmin10.writeCountFile(new File(phyMappedReadsFileIBM), Integer.MAX_VALUE, false, false, Float.NaN, true);
    }

/*    public static void mapTwoIBMFlowCellsVs55KFrame() {
//        String frameWorkGenMapFile =   "/usr/local/maizediv/illumina/IBM/counts/IBM_55K_08192010.hmp.txt";
        String frameWorkGenMapFile55K =   "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/ShiranVDs/IBM_55K_08192010.hmp.txt";
        String frameWorkGenMapFileGBS =   "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/434LFAAXX/anchor_map/IBM_GBS_framework_map_20100917.hmp.txt";
//        String rbtFileIBM =            "/usr/local/maizediv/illumina/IBM/counts/rbtIBM_Min10_20100827.bin";
        String rbtFileIBM =            "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/ShiranVDs/rbtIBM_Min10_20100827.bin";
//        String phyMappedReadsFileIBM = "/usr/local/maizediv/illumina/IBM/counts/phyMappedReadsIBMDiv20_20100827.bin";
        String phyMappedReadsFileIBM = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/ShiranVDs/phyMappedReadsIBMDiv20_20100827.bin";
//        String GeneticResultsFileIBM = "/usr/local/maizediv/illumina/IBM/counts/IBMgeneticResults_20100828.txt";
        String GeneticResultsFileIBM = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/ShiranVDs/IBMgeneticResults_20100828_tabs.txt";
        String AGPv1VDfile = "Q:/SolexaAnal/virtual_digests/AGPv1/B73AGPv1VD.rwpm.bin";
        String IBMAlleleInfoOutFile = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/ShiranVDs/IBMAlleleInfo_20100914.txt";
        String readsToKeepFile = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/Chr0/mappedReadsFromCtg697.txt";
        String filteredRBTFile = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/Chr0/rbtCtg545_haplo.txt";
        String chr0CtgHaplotypesFile = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/Chr0/Chr0CtgHaplotypes.txt";
        String chr0CtgHaplotypesResultsFile = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/Chr0/Chr0CtgHaplotypesGeneticResults20100922_GBSFrame2.txt";

        // genetically map every tag in IBM that shows up 10 or more times across the two flow cells
        Alignment[] gMap55K= ((CombineAlignment)ImportUtils.readFromHapmap(frameWorkGenMapFile55K)).getAlignments();
        MapHaplotypes.mapWorkingMapWithGenetic(gMap55K, new dep_ReadsWPhysicalMap(phyMappedReadsFileIBM,true),
                new TagsByTaxaByte(rbtFileIBM,true), 0.05, 10, 10, GeneticResultsFileIBM);

        // get the AGPv1 Chr0 position of the mapped tags.  This allows me to figure out which contig they belong to
        AlleleInfo ai = new AlleleInfo(GeneticResultsFileIBM, AGPv1VDfile, IBMAlleleInfoOutFile, 7);  // the 64 base tag of the B73 allele is in column 7 (0 based)

        // make a RBT text file for each ctg that contains only the consensus tags (these were determined manually in Excel)
        TagsByTaxaByte rbtIBM = new TagsByTaxaByte(rbtFileIBM, true);
        rbtIBM.filterForListOfReads(new File(readsToKeepFile), new File(filteredRBTFile), false);

        // map the Chr0 haplotypes (merged data across multiple, consensus tags) vs both the 55K and GBS framework maps
        Alignment[] gMapGBS= ((CombineAlignment)ImportUtils.readFromHapmap(frameWorkGenMapFileGBS)).getAlignments();
        dep_ReadsWPhysicalMap phyMappedReadsIBM = new dep_ReadsWPhysicalMap(phyMappedReadsFileIBM,true);
        TagsByTaxaByte chr0CtgRBT = new TagsByTaxaByte(chr0CtgHaplotypesFile,false);  // NOTE: this file must be sorted by tag for the genetic mapping to work properly
        for (int i = 0; i < chr0CtgRBT.getTagCount(); ++i) {
            System.out.println(BaseEncoder.getSequenceFromLong(chr0CtgRBT.getTag(i)));
            System.out.println("Index in RBT:" + chr0CtgRBT.getTagIndex(chr0CtgRBT.getTag(i)));
        }
        MapHaplotypes.mapWorkingMapWithGenetic(gMapGBS,phyMappedReadsIBM,chr0CtgRBT,0.2,10,10,chr0CtgHaplotypesResultsFile);
    }
*/

    public static void makeReadCountsTeosinte() {
        String qseqDirTeo =           "/usr/local/maizediv/illumina/teosinte/qseq";
        String qseqKeyTeo =           "/usr/local/maizediv/illumina/teosinte/teosinte_key.txt";
        String parsedTaxaDirTeo =     "/usr/local/maizediv/illumina/teosinte/taxa";
        String collapsedTaxaDirTeo =  "/usr/local/maizediv/illumina/teosinte/taxacollapse";
        String combinedReadsFileTeo = "/usr/local/maizediv/illumina/teosinte/counts/CombReadsTeoMin2_20100712.bin";
        String rbtFileTeo =           "/usr/local/maizediv/illumina/teosinte/counts/teoRBT_Min2_20100716.bin";
        String rbtTextFileTeo =       "/usr/local/maizediv/illumina/teosinte/counts/teoRBT_Min2_20100719.txt";

        // Read and parse qseq or fastq file using low stringency Q score (maximal # of reads)
        System.out.println();
        System.out.println("Parsing the qseq files for Teosinte");
        System.out.println("-----------------------------------");
        ParseBarcodeFiles pbfTeo=new ParseBarcodeFiles(qseqDirTeo, qseqKeyTeo, parsedTaxaDirTeo, 0, false);
        System.gc();

        // condense the taxa TagCounts files by sorting and collapsing identical reads
        System.out.println();
        System.out.println("Collapsing the ReadCounts files for each teosinte taxon");
        System.out.println("-------------------------------------------------------");
        TagCounts rcTeo=new TagCounts(parsedTaxaDirTeo, collapsedTaxaDirTeo, 1, true, false, false);
        rcTeo = null;
        System.gc();

        // Fuse multiple taxa files into one, minimum frequency is 2, binary=true (low min freq b/c BC2S3)
        System.out.println();
        System.out.println("Combining the ReadCounts files across all teosinte taxa");
        System.out.println("-------------------------------------------------------");
        CombineReadCounts crcTeo=new CombineReadCounts(collapsedTaxaDirTeo, combinedReadsFileTeo, 2, true);
        crcTeo = null;
        System.gc();

        CreateReadsByTaxa teoRBT=new CreateReadsByTaxa(combinedReadsFileTeo, collapsedTaxaDirTeo, rbtFileTeo, true);
    }

    public static void makeTeosinteGenoFile() {
        // input files
        String teoFrameworkMap = "Q:/SolexaAnal/Solexa_GBS/teosinte/Teo_BC2S3_framework_HapMap.txt";
        String AGPv2VDfile = "Q:/SolexaAnal/virtual_digests/AGPv2/B73AGPv2VD.rwpm.bin";  // although JD's framework is v1, AGPv2 should suffice
        String teoCombinedReadsFile = "Q:/SolexaAnal/Solexa_GBS/teosinte/CombReadsTeoMin2_20100712.bin";
        String teoRBTFile = "Q:/SolexaAnal/Solexa_GBS/teosinte/teoRBT_Min2_20100716.bin";

        // output files
        String teoPhyMappedReadsFile = "Q:/SolexaAnal/Solexa_GBS/teosinte/20100819/phyMappedReadsTeoDiv5_20100716.bin";
        String teoPhyMappedReadsTxtFile = "Q:/SolexaAnal/Solexa_GBS/teosinte/20100819/phyMappedReadsTeoDiv5_20100716.txt";
        String teoGenMappedReadsTxtFile = "Q:/SolexaAnal/Solexa_GBS/teosinte/20100819/phyGenMappedReadsTeoDiv5_20100719.txt";
        String teoGenMappedReadsFile = "Q:/SolexaAnal/Solexa_GBS/teosinte/20100819/phyGenMappedReadsTeoDiv5_20100720.bin";
        String teoGBSHapMapFileStem = "Q:/SolexaAnal/Solexa_GBS/teosinte/20100819/teo_GBS_biallelic_genos_20100730";

        dep_ReadsWPhysicalMap rwpmTeoPhyMapped=MapHaplotypes.blastUsingPhysicalMap(new dep_ReadsWPhysicalMap(AGPv2VDfile,true),
                  new dep_ReadsWPhysicalMap(new TagCounts(teoCombinedReadsFile, true)),5);  // allow 5 mismatches for a 1st pass
        rwpmTeoPhyMapped.writeCountFile(new File(teoPhyMappedReadsFile), Integer.MAX_VALUE, true, false, Float.NaN, true);
        rwpmTeoPhyMapped.sortTable(false); // sort by position

        TagsByTaxaByte teoRBT=new TagsByTaxaByte(teoRBTFile,FilePacking.Byte);
        rwpmTeoPhyMapped=MapHaplotypes.checkWorkingMapWithGeneticBC2(teoFrameworkMap, rwpmTeoPhyMapped, teoRBT, false, 0.01);
//        rwpmTeoPhyMapped.writeCountFile(new File(teoGenMappedReadsTxtFile), Integer.MAX_VALUE, true, false, Float.NaN, false);
        rwpmTeoPhyMapped.writeCountFile(new File(teoGenMappedReadsFile), Integer.MAX_VALUE, true, false, Float.NaN, true);
        dep_ReadsWPhysicalMap rwpmTeoGenPhyMapped = new dep_ReadsWPhysicalMap(teoGenMappedReadsFile,true);

        for(int i=1; i<=10; i++) {
            System.out.println("WORKING ON CHROMOSOME " + i);
            System.out.println("ERROR ConvertGBSToAlignment NEEDS TO BE REWORKED");
            Alignment a=null;
       //     Alignment a = new ConvertGBSToAlignment(teoRBT, rwpmTeoGenPhyMapped, 0.01, (byte)i);
            System.out.println("UnFiltered Alignment  Taxa:" + a.getSequenceCount() + " Sites:" + a.getSiteCount());
            int[] goodLowHetSites = AlignmentFilterByGBSUtils.getLowHetSNPs(a, true, 0.20, 5);
            a = FilterAlignment.getInstance(a, goodLowHetSites);
            MutableAlignmentForGBS mutAlign=new MutableAlignmentForGBS(a);
            a = null;
            System.gc();
            mutAlign.writeToHapmapBC2S3(false, false, teoGBSHapMapFileStem + ".chr" + i + ".CAfiltered", '\t', i);  // writes only the C/A markers to the file
            Alignment teoW22BC2S3 = ImportUtils.readFromHapmap(teoGBSHapMapFileStem + ".chr" + i + ".CAfiltered" + ".hmp.txt");
            System.out.println("Filtered Alignment  Taxa:" + teoW22BC2S3.getSequenceCount() + " Sites:" + teoW22BC2S3.getSiteCount());
            mutAlign = new MutableAlignmentForGBS(teoW22BC2S3);
            teoW22BC2S3 = null;
            mutAlign.removeDCOs(7);
            System.out.println("nDCOs on chr" + i + " = " + mutAlign.getnDCOs());
            mutAlign.callHetSegments(7);
            System.out.println("nDCOs on chr" + i + " = " + mutAlign.getnDCOs());
            mutAlign.writeToHapmapBC2S3(false, true, teoGBSHapMapFileStem + ".chr" + i + ".hetSegs", '\t', i);
            teoW22BC2S3 = ImportUtils.readFromHapmap(teoGBSHapMapFileStem + ".chr" + i + ".hetSegs" + ".hmp.txt");
            mutAlign = new MutableAlignmentForGBS(teoW22BC2S3);
            mutAlign.imputeMissingDataIncludingHets();
            mutAlign.writeToHapmapBC2S3(false, false, teoGBSHapMapFileStem + ".chr" + i + ".imputed", '\t', i);
        }
        for (int base = 0; base < 16; ++base) {
            System.out.println("GdpdmBLOBUtils.bases[" + base + "] is: " + (char) GdpdmBLOBUtils.bases[base]);
        }
    }

    public static void writeTeosinteAlleleInfoFile() {
        String AGPv2VDfile = "Q:/SolexaAnal/virtual_digests/AGPv2/B73AGPv2VD.rwpm.bin";  
        String teoRBTFile = "Q:/SolexaAnal/Solexa_GBS/teosinte/teoRBT_Min2_20100716.bin";
        String teoGenMappedReadsFile = "Q:/SolexaAnal/Solexa_GBS/teosinte/phyGenMappedReadsTeoDiv5_20100720.bin";
        String teoGBSHapMapFileStem = "Q:/SolexaAnal/Solexa_GBS/teosinte/20100819/teo_GBS_biallelic_genos_20100819";
        String AGPv1VDfile = "Q:/SolexaAnal/virtual_digests/AGPv1/B73AGPv1VD.rwpm.bin";
        String teoAlleleInfoInFile = "Q:/SolexaAnal/Solexa_GBS/teosinte/20100819/teo_GBS_biallelic_genos_20100819.alleleInfo.txt";
        String teoAlleleInfoOutFile = "Q:/SolexaAnal/Solexa_GBS/teosinte/20100819/teo_GBS_biallelic_genos_20100819.alleleInfo.withAGPv1.txt";
        String chr0AlleleInfoInFile = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/434LFAAXX/IBM_GBSwQualReads_100513b_chr0.txt";
        String chr0AlleleInfoOutFile = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/434LFAAXX/IBM_GBSwQualReads_100513b_chr0.withAGPv1.M20.txt";

        TagsByTaxaByte teoRBT=new TagsByTaxaByte(teoRBTFile,FilePacking.Byte);
        dep_ReadsWPhysicalMap rwpmTeoGenPhyMapped = new dep_ReadsWPhysicalMap(teoGenMappedReadsFile,true);
        dep_ReadsWPhysicalMap AGPv2VD = new dep_ReadsWPhysicalMap(AGPv2VDfile,true);
        AGPv2VD.sortTable(false);  // sort by position

        for(int i=1; i<=10; i++) {
            System.out.println("WORKING ON CHROMOSOME " + i);
            System.out.println("ERROR ConvertGBSToAlignment NEEDS TO BE REWORKED");
//            Alignment a = new ConvertGBSToAlignment(teoRBT, AGPv2VD,
//                    rwpmTeoGenPhyMapped, 0.01, (byte)i, teoGBSHapMapFileStem+".chr"+i+".alleleInfo.txt");
        }

        AlleleInfo ai = new AlleleInfo(teoAlleleInfoInFile, AGPv1VDfile, teoAlleleInfoOutFile, 11);  // the 64 base tag of the B73 allele is in column 11 (0 based)
    }

    public static void alignB73Htrhm() {
        String flowcell = "42A87AAXX";
        String DirStem = "Q:/SolexaAnal/Solexa_NGG";
        String qseqKeyFile = DirStem + "/" + flowcell + "/" + flowcell + "_Multiplex_key.txt";
        String qseqDir = DirStem + "/" + flowcell + "/qseq";
        String parsedTaxaDir = DirStem + "/" + flowcell + "/qseq/taxa";
        String collapsedTaxaDir = DirStem + "/" + flowcell + "/qseq/taxacollapse";
        String B73HtrhmReadsFile = DirStem + "/" + flowcell + "/qseq/taxacollapse/B73Htrhm_" + flowcell + "_6.cnt";
        String B73AGPv1VDfile = "Q:/SolexaAnal/IBM/virtual_digests/AGPv1/B73AGPv1VD.rwpm.bin";
        String B73HtrhmRwpmFile = DirStem + "/" + flowcell + "/qseq/counts/B73Htrhm.Q10.M5.rwpm.txt";

        // Read and parse qseq or fastq file using Q score cutoff of 10
        System.out.println("Parsing the qseq files for " + flowcell + " lane 6");
        System.out.println("-------------------------------------------");
        ParseBarcodeFiles pbf=new ParseBarcodeFiles(qseqDir, qseqKeyFile, parsedTaxaDir, 10, false);
        pbf = null;
        System.gc();

        // condense the taxa TagCounts files by sorting and collapsing identical reads
        System.out.println();
        System.out.println("Collapsing the ReadCounts files for each taxon in " + flowcell + " lane 6");
        System.out.println("------------------------------------------------------------------");
        TagCounts rc=new TagCounts(parsedTaxaDir, collapsedTaxaDir, 1, true, false, false);
        rc = null;
        System.gc();

        // open the B73Htrhm reads and align them against B73 AGPv1 with no mismatch
        System.out.println();
        System.out.println("Aligning the ReadCounts from B73Htrhm vs AGPv1 (<6 mismatches)");
        System.out.println("--------------------------------------------------------------");
        TagCounts B73HtrhmReadCounts = new TagCounts(B73HtrhmReadsFile,true);
        dep_ReadsWPhysicalMap B73HtrhmRwpm=MapHaplotypes.blastUsingPhysicalMap(new dep_ReadsWPhysicalMap(B73AGPv1VDfile,true),
                  new dep_ReadsWPhysicalMap(B73HtrhmReadCounts),5);
        B73HtrhmRwpm.writeCountFile(new File(B73HtrhmRwpmFile), false);
    }

//    public static void analyzeIBMforGBSmethodsPaper() {
//        String combinedReadsFileIBM1 = "/cbsufsrv3/data2/maizediv/illumina/434LFAAXX/counts/CombReads_IBM1_Min5_20100525.bin";  // min Q score of 0
//        String AGPv1VDfile = "Q:/SolexaAnal/virtual_digests/AGPv1/B73AGPv1VD.rwpm.bin";
//        String IBMrwpmM0File = "/cbsufsrv3/data2/maizediv/illumina/434LFAAXX/counts/IBM1perfectMatches.rwpm.txt";
//        String IBMrwpmM5File = "/cbsufsrv3/data2/maizediv/illumina/434LFAAXX/counts/IBM1lt5misMatches.rwpm.txt";
////        String AGPv2VDfile = "Q:/SolexaAnal/virtual_digests/AGPv1/B73AGPv2VD.rwpm.bin";
//
//        CompareReadDistribution crd1=new CompareReadDistribution(CompareReadDistribution.Analysis.EvalVirtualDigest, AGPv1VDfile, null);
//        CompareReadDistribution crd2=new CompareReadDistribution(CompareReadDistribution.Analysis.EvalVirtualDigest, AGPv1VDfile, combinedReadsFileIBM1);
//
//        TagCounts IBMReadCounts = new TagCounts(combinedReadsFileIBM1,true);
//        dep_ReadsWPhysicalMap IBMrwpm=MapHaplotypes.blastUsingPhysicalMap(new dep_ReadsWPhysicalMap(AGPv1VDfile,true), new dep_ReadsWPhysicalMap(IBMReadCounts),5);
//        IBMrwpm.writeCountFile(new File(IBMrwpmM5File), false);
//    }

    public static void testDuplicateTaxon() {
        String qseqDirIBM =           "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/434LFAAXX/qseq";
        String origKeyIBM =           "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/434LFAAXX/duplicate_taxon_test/434LFAAXX_original_key.txt";
        String duplKeyIBM =           "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/434LFAAXX/duplicate_taxon_test/434LFAAXX_duplicates_key.txt";
        String parsedTaxaDirOrig =    "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/434LFAAXX/duplicate_taxon_test/original";
        String collapsedTaxaDirOrig = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/434LFAAXX/duplicate_taxon_test/orig_collapsed";
        String parsedTaxaDirDupl =    "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/434LFAAXX/duplicate_taxon_test/with_duplicates";
        String collapsedTaxaDirDupl = "C:/Documents and Settings/jcg233/My Documents/Bioinformatics/NextGen/434LFAAXX/duplicate_taxon_test/dupl_collapsed";

//        System.out.println();
//        System.out.println("Parsing the qseq files for IBM (434LFAAXX): with DUPLICATES");
//        System.out.println("-----------------------------------------------------------");
//        ParseBarcodeFiles pbfIBMdupl=new ParseBarcodeFiles(qseqDirIBM, duplKeyIBM, parsedTaxaDirDupl, 10, false);
//        pbfIBMdupl = null;
//        System.gc();

        TagCounts rcIBMdupl=new TagCounts(parsedTaxaDirDupl, collapsedTaxaDirDupl, 1, true, false, true);
    }
}

