/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.maizegenetics.gbs.pipeline;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map.Entry;
import java.util.TreeMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import net.maizegenetics.gbs.maps.TagsOnPhysicalMap;
import net.maizegenetics.gbs.tagdist.MutableSimpleAlignment;
import net.maizegenetics.gbs.tagdist.TagsByTaxa;
import net.maizegenetics.gbs.tagdist.TagsByTaxaBitFileMap;
import net.maizegenetics.genome.BaseEncoder;
import net.maizegenetics.pal.alignment.Alignment;
import net.maizegenetics.pal.alignment.AnnotatedAlignmentUtils;
import net.maizegenetics.pal.alignment.ExportUtils;
import net.maizegenetics.pal.alignment.Locus;
import net.maizegenetics.pal.alignment.SimpleAlignment;
import net.maizegenetics.pal.datatype.DataType;
import net.maizegenetics.pal.datatype.IUPACNucleotides;
import net.maizegenetics.pal.ids.SimpleIdGroup;
import org.biojava3.alignment.Alignments;
import org.biojava3.alignment.template.Profile;
import org.biojava3.core.sequence.DNASequence;
import org.biojava3.core.sequence.compound.AmbiguityDNACompoundSet;
import org.biojava3.core.sequence.compound.NucleotideCompound;
import org.biojava3.core.util.ConcurrencyTools;

/**
 *
 * @author edbuckler
 */
public class TagsToSNPByAlignmentMT {
    static int minTaxaCnt=0;
    static int maxSize=600000;

    public TagsToSNPByAlignmentMT(TagsOnPhysicalMap theTOPM, TagsByTaxa theTBT, MutableSimpleAlignment theMSA, String outHapMap, int targetChromo) {
        final int cores=Runtime.getRuntime().availableProcessors();

        System.out.println("TagsToSNPByAlignmentMT processors available:"+cores);
        ExecutorService pool = Executors.newCachedThreadPool();
        ThreadPoolExecutor tpe=(ThreadPoolExecutor)pool;
        TreeMap<Integer, String> ts = new TreeMap<Integer, String>();
       int lastIndex=theTOPM.getReadIndexForPositionIndex(0);
       int[] currPos=theTOPM.getPositionArray(lastIndex);
       if(currPos[0]>0) {ts.put(0,BaseEncoder.getSequenceFromLong(theTOPM.getTag(lastIndex)));}
       else currPos=null;
       int countSNPs=0, countLoci=0;
       long time=System.currentTimeMillis();
       ConcurrencyTools.setThreadPool(tpe);
        System.out.println("Max Pool Size "+tpe.getMaximumPoolSize());
          System.out.println("Core Pool Size "+tpe.getCorePoolSize());
       int pauses=0;
       for (int i = 0; (i < theTOPM.getSize())&&(countSNPs<maxSize); i++) {
           int ri=theTOPM.getReadIndexForPositionIndex(i);
           if(theTOPM.getChromosome(ri)!=targetChromo) continue;
           if(Arrays.equals(currPos, theTOPM.getPositionArray(ri))) {
               long[] tag=theTOPM.getTag(ri);
               int hit=theTBT.getTagIndex(tag);
               int cnt=(hit>-1)?theTBT.getNumberOfTaxaWithTag(hit):-1;
               //String trimmedSeq=BaseEncoder.getSequenceFromLong(tag).substring(0, theTOPM.getTagLength(ri));
               String trimmedSeq=BaseEncoder.removePolyAFromEnd(BaseEncoder.getSequenceFromLong(tag));
               if(cnt>minTaxaCnt) ts.put(hit,trimmedSeq);
              // System.out.println(Arrays.toString(currPos)+":"+BaseEncoder.getSequenceFromLong(theTOPM.getTag(ri)));
           } else {
               if(ts.size()>1) {
                   SNPsFromSequenceAlignment a=new SNPsFromSequenceAlignment(ts, theTBT,currPos[0], currPos[1], currPos[2], theMSA);
                   a.setName("Locus"+countLoci);
                   while(tpe.getActiveCount()>(cores*2)) {
                    //   try{Thread.yield(); pauses++;} catch (Exception e) {e.printStackTrace();}
                       try{Thread.sleep(0,100000); pauses++;} catch (Exception e) {e.printStackTrace();}

                   }
                   tpe.submit(a);
                   countLoci++;
                   if(theMSA.getSiteCount()%100==0) {
                       double rate=(double)theMSA.getSiteCount()/(double)(System.currentTimeMillis()-time);
                       System.out.printf("Chr:%d Pos:%d Loci=%d SNPs=%d rate=%g SNP/millisec %d %n",currPos[0], currPos[2], countLoci, theMSA.getSiteCount(), rate, tpe.getActiveCount());
                       //System.out.println(theMSA.toString());
                   }
               }
               //ts.clear();
               ts = new TreeMap<Integer, String>();
               currPos=theTOPM.getPositionArray(ri);
               if(currPos[0]>0) {
                   long[] tag=theTOPM.getTag(ri);
                    int hit=theTBT.getTagIndex(tag);
                    int cnt=(hit>-1)?theTBT.getNumberOfTaxaWithTag(hit):-1;
                    if(cnt>minTaxaCnt) ts.put(hit,BaseEncoder.getSequenceFromLong(tag));
               //    System.out.println(Arrays.toString(currPos)+":"+BaseEncoder.getSequenceFromLong(theTOPM.getTag(ri)));
               } else currPos=null;
           }
           //if(theTOPM.getPositionArray(ri))

       }
        System.out.println("Total Pauses or Yields:"+pauses);
       System.out.println("Main ThreadsCnt:"+Thread.activeCount()+" AlignmentThreadsCnt:"+ConcurrencyTools.getThreadPool().getActiveCount());
        try {
                // Wait a while for existing tasks to terminate
             if (!pool.awaitTermination(5, TimeUnit.SECONDS)) {
               pool.shutdownNow(); // Cancel currently executing tasks
               // Wait a while for tasks to respond to being cancelled
               if (!pool.awaitTermination(5, TimeUnit.SECONDS)) {System.err.println("Pool did not terminate");}
               else {System.out.println("Pool did terminate");}
             }
           } catch (InterruptedException ie) {
               System.err.println("Pool did not terminate");
             // (Re-)Cancel if current thread also interrupted
             pool.shutdownNow();
             // Preserve interrupt status
             Thread.currentThread().interrupt();
        }
      System.out.println("TC:"+Thread.activeCount()+" BJC"+ConcurrencyTools.getThreadPool().getActiveCount());
       ConcurrencyTools.shutdown();
       System.out.println("Completed shutdown:"+theMSA.getSiteCount());
       theMSA.sortSiteByPhysicalPosition();
       ExportUtils.writeToHapmap(theMSA, false, outHapMap, '\t');
       System.out.println("Wrote to hapmap:"+outHapMap);
        System.out.println("TC:"+Thread.activeCount());
    }

    

     public static void main(String[] args) {
        System.out.println("Starting TagsToSNPByAlignmentMT");
        String tagMapFileS="/Users/edbuckler/SolexaAnal/GBS/reftags/14FCGBS.tg.ndup.bin";
 //       String tagsByTaxaS="/Users/edbuckler/SolexaAnal/GBS/test/bitIBM110210.dist.txt";
  //      String tagsByTaxaS="/Users/edbuckler/SolexaAnal/GBS/test/HiSeq282_110214.dist.txt";
        String tagsByTaxaS="/Users/edbuckler/SolexaAnal/GBS/dist/NAMsort_110303.bibin";
     //   String tagsByTaxaS="/Users/edbuckler/SolexaAnal/GBS/test/IBM110210.dist.txt";
    //    String outHapMap="/Users/edbuckler/SolexaAnal/GBS/test/HiSeq282wHet_110215.hmp.txt";
        String outHapMap="/Users/edbuckler/SolexaAnal/GBS/test/NAMwHet_110315mt.hmp.txt";

       TagsOnPhysicalMap theTOPM=new TagsOnPhysicalMap(tagMapFileS,true);  //Reads tag map file into an object
       //TagsByTaxa theTBT=new TagsByTaxaBit(tagsByTaxaS,FilePacking.Bit);
 //      TagsByTaxa theTBT=new TagsByTaxaBit(tagsByTaxaS,FilePacking.Text);
       TagsByTaxa theTBT=new TagsByTaxaBitFileMap(tagsByTaxaS);
       theTOPM.sortTable(true);
       theTOPM.printRows(5, true, true);
    //   ArrayList<String> ts=new ArrayList<String>();
       for (int i = 1; i < 11; i++) {
             String out=outHapMap.replaceFirst(".hmp.", ".c"+i+".hmp.");
             MutableSimpleAlignment theMSA=createMutableAlignment(theTBT, maxSize+100);
             TagsToSNPByAlignmentMT theTSBAMT=new TagsToSNPByAlignmentMT(theTOPM, theTBT, theMSA, out,i);
         }
       
       
    }



    private static MutableSimpleAlignment createMutableAlignment(TagsByTaxa theTBT, int maxSites) {
        Locus[] theL=new Locus[11];
        for (int i = 0; i < theL.length; i++) {
            theL[i]=new Locus(""+i, ""+i, -1, -1, null, null);
        }
        MutableSimpleAlignment theMSA=new MutableSimpleAlignment(theTBT.getTaxaNames(),maxSites, theL);
        return theMSA;
    }

    private synchronized void addSiteToMutableAlignment(TagsByTaxa theTBT, int chromosome, int strand,
            int startPos, Alignment tagAlignment, MutableSimpleAlignment theMSA) {
//        System.out.printf("%d %d %d %n",chromosome, strand, startPos);
//        System.out.println(tagAlignment.toString());
//        System.out.println("PosInLocus:"+tagAlignment.getPositionInLocus(0));
        for (int s = 0; s < tagAlignment.getSiteCount(); s++) {
            int currSite=theMSA.getNextFreeSite();
            theMSA.setLocusOfSite(currSite, (byte)chromosome);  //this is a cheap trick
            int position=(strand>0)?(startPos+tagAlignment.getPositionInLocus(s)):(startPos-tagAlignment.getPositionInLocus(s));
           // if(position==15071030) System.out.println(tagAlignment.toString());
            theMSA.setPositionOfSite(currSite, position);
            theMSA.setStrandOfSite(currSite, (byte)strand);
            for (int tg = 0; tg < tagAlignment.getSequenceCount(); tg++) {
                int tagIndex=Integer.parseInt(tagAlignment.getTaxaName(tg));
                byte currBase=tagAlignment.getBase(tg, s);
//                System.out.println("Allele: "+currBase+" :"+(char)currBase);
                for (int tx = 0; tx < theTBT.getTaxaCount(); tx++) {
                    if(theTBT.getReadCountForTagTaxon(tagIndex, tx)>0) {
                        byte cb=theMSA.getBase(tx, currSite);
                        if(cb==DataType.UNKNOWN_BYTE) theMSA.setBase(tx, currSite, currBase);
                        else {
                            byte[] snpValue={cb,currBase};
 //                           System.out.println("HetSite:"+(char)cb+":"+(char)currBase+":"+(char)IUPACNucleotides.getDegerateSNPByteFromTwoSNPs(snpValue));
                            theMSA.setBase(tx, currSite, IUPACNucleotides.getDegerateSNPByteFromTwoSNPs(snpValue));
                        }
 //                       System.out.printf("SetAllele: %d %d %d %n",tx, currSite, currBase);
                    }
                }

            }

        }

    }



    private class SNPsFromSequenceAlignment extends Thread {
        TreeMap<Integer, String> tagSeqMap;
        TagsByTaxa theTBT;
        int chromosome, strand, startPos;
        Alignment tagAlignment=null;
        MutableSimpleAlignment theMSA;

        public SNPsFromSequenceAlignment(TreeMap<Integer, String> tagSeqMap, TagsByTaxa theTBT, int chromosome, int strand,
            int startPos, MutableSimpleAlignment theMSA) {
            this.tagSeqMap=tagSeqMap;
            this.theTBT=theTBT;
            this.chromosome=chromosome;
            this.strand=strand;
            this.startPos=startPos;
            this.theMSA=theMSA;
        }


//    public String getName() {
//        return "ASDFDS";
//    }

    public void run()  {
        List<DNASequence> lst = new ArrayList<DNASequence>();
        if(tagSeqMap.size()>20) return;
        for (Entry<Integer,String> id : tagSeqMap.entrySet()) {
            DNASequence ds=new DNASequence(id.getValue());
            ds.setOriginalHeader(id.getKey().toString());
            ds.setCompoundSet(AmbiguityDNACompoundSet.getDNACompoundSet());
            lst.add(ds);
        }
        Profile<DNASequence, NucleotideCompound> profile = Alignments.getMultipleSequenceAlignment(lst);
//        System.out.printf("Clustalw:%n%s%n", profile);
        String[] aseqs=new String[tagSeqMap.size()];
        String[] names=new String[tagSeqMap.size()];
        for (int i = 1; i <= aseqs.length; i++) {
            aseqs[i-1]=profile.getAlignedSequence(i).getSequenceAsString();
            names[i-1]=profile.getAlignedSequence(i).getOriginalSequence().getOriginalHeader();
        }
        profile=null;
        Alignment aa=SimpleAlignment.getInstance(new SimpleIdGroup(names),aseqs, new IUPACNucleotides());
//        System.out.println(aa.toString());
        Alignment faa=AnnotatedAlignmentUtils.removeConstantSitesIgnoreGapsMissing(aa);
//        System.out.println(faa.toString());
//        Alignment iaa=AnnotatedAlignmentUtils.extractIndels(aa, true);
//        System.out.println(iaa.toString());
        if(faa.getSiteCount()>5) return;
        addSiteToMutableAlignment(theTBT, chromosome, strand, startPos, faa,  theMSA);
        
    }

    }



}
