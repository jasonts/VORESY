/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.maizegenetics.gbs.pipeline;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Arrays;
import net.maizegenetics.gbs.homology.ParseBarcodeRead;
import net.maizegenetics.gbs.homology.ReadBarcodeResult;
import net.maizegenetics.gbs.maps.TagsOnPhysicalMap;
import net.maizegenetics.gbs.maps.TagsOnPhysicalMapCBSUAdapter;
import net.maizegenetics.gbs.tagdist.MutableSimpleAlignment;
import net.maizegenetics.gbs.tagdist.TagsByTaxa;
import net.maizegenetics.gbs.tagdist.TagsByTaxa.FilePacking;
import net.maizegenetics.gbs.tagdist.TagsByTaxaBit;
import net.maizegenetics.pal.alignment.Alignment;
import net.maizegenetics.pal.alignment.ExportUtils;
import net.maizegenetics.pal.alignment.FilterAlignment;
import net.maizegenetics.pal.alignment.ImportUtils;
import net.maizegenetics.pal.alignment.Pack1Alignment;
import net.maizegenetics.pal.ids.IdGroup;
import net.maizegenetics.pal.ids.IdGroupUtils;
import net.maizegenetics.util.DirectoryCrawler;
/**
 *
 * @author james
 */
public class QseqToHapmapProduction {

    private QseqToHapmapProduction() {
    }

    public static void main(String[] args) {
//	String qseqDirectory = new String("/media/CA568FCE568FB9A9/NAM");
//        String keyFileS = new String("/home/jvh39/Documents/code/gbs_pipeline/NAM_IBM_MDP_Ames_key_20110310.txt");
//	String tagMapFileS = new String("/home/jvh39/Documents/code/gbs_pipeline/14FCGBS.tg.ndup.bin");
        String qseqDirectory = new String("/Volumes/ESB_GBS1/qseq/NAM");
        String keyFileS = new String("/Volumes/ESB_GBS1/qseq/NAM_IBM_MDP_Ames_key_20110310.txt");
	String tagMapFileS = new String("/Users/edbuckler/SolexaAnal/GBS/reftags/14FCGBS.tg.ndup.bin");
        String outReadByTaxaS = new String("/Users/edbuckler/SolexaAnal/GBS/test/NAM110315x.tbt.txt"); //Put output file in same directory as input, use first input name, and append ".result" to it
	File[] testFiles = DirectoryCrawler.listFiles(".*qseq.txt", new File(qseqDirectory));
        String[] qseqFileS = new String[testFiles.length];
	for(int i=0; i<testFiles.length; i++){
            qseqFileS[i] = testFiles[i].getAbsolutePath(); //Put names of found files into array
            System.out.println(qseqFileS[i]);
        }

//        System.exit(0);

	//outReadByTaxaS = new String(qseqFileS[0]+".result"); //Put output file in same directory as input, use first input name, and append ".result" to it

        testBasicPipeline(keyFileS, qseqFileS, tagMapFileS, outReadByTaxaS); //Feed all data into function
    }
	/***  NOTE: I commented out the previous main() method (below) to convert some files. -JH ***
	System.out.println("Running main method in QseqToHapmapProduction");
//        TagsByTaxaBit test=new TagsByTaxaBit();
//        testBasicPipeline(null,null,null,null);

        removeLowQualitySite(1);
          removeByLD(1);
//        fuseHapMapWithMultipleChromosomes();

//	testTAGSCBSU();
//        removeDuplicateTagsOnMap();
//	tagmapTextToBinary();
//	readTextFile(new File("c:/sample_tags.txt"));
	System.exit(0);
//	String infile="C:/Documents and Settings/james/My Documents/code/GBS_pipline_test_data.txt";
        String infile="/Users/edbuckler/SolexaAnal/GBS/GBS_pipline_test_data.txt";
	TagsOnPhysicalMap theTOPM=new TagsOnPhysicalMap(infile,false);
        for (int i = 0; i < 5; i++) {
            System.out.println(theTOPM.getTag(i)[0]+":"+theTOPM.printRow(i));
        }
        theTOPM.sortTable(true);
        for (int i = 0; i < 5; i++) {
            System.out.println(theTOPM.printRow(i));
        }
        String outfile="/Users/edbuckler/SolexaAnal/GBS/GBS_pipline_test_data.tpm.bin";
        theTOPM.writeBinaryFile(new File(outfile), 0, true, true, 0, true);
        theTOPM=new TagsOnPhysicalMap(outfile,true);
        for (int i = 0; i < 5; i++) {
            System.out.println(theTOPM.printRow(i));
        }
        outfile="/Users/edbuckler/SolexaAnal/GBS/GBS_pipline_test_data2.txt";
        theTOPM.writeTextFile(new File(outfile));
	//ParseBarcodeRead thePBD=new ParseBarcodeRead(keyFile, fastq, flowcell, lane);

	//TagsByTaxa theTBT=new TagsByTaxaByte(theTOPM.getTags(),new byte[numberOfTags][numberOfTaxa], taxaNames));
	//copy methods from ParseBarcodeFiles to this class

    }
    */

   public static void tagmapTextToBinary() {
	//String infile="c:/output9m.txt";
        //String outfile="c:/output_binary.dat";
        String infile="/Users/edbuckler/SolexaAnal/GBS/test/14FCGBS.tg.txt";
        String outfile="/Users/edbuckler/SolexaAnal/GBS/test/14FCGBS.tg.bin";
	TagsOnPhysicalMap theTOPM=new TagsOnPhysicalMap(infile,false);
        theTOPM.sortTable(true);
	System.out.println(theTOPM.getTagCount());
	theTOPM.writeBinaryFile(new File(outfile));
        theTOPM.writeTextFile(new File("/Users/edbuckler/SolexaAnal/GBS/test/14FCGBS.tg.sort.txt"));
    }

    public static void testTAGSCBSU() {
//	String infile="c:/sample_tags.txt";
        String infile="/Users/edbuckler/SolexaAnal/GBS/test/14FCGBS.out.txt";
        String outfile="/Users/edbuckler/SolexaAnal/GBS/test/14FCGBS.tg.txt";
	TagsOnPhysicalMapCBSUAdapter theTOPM=new TagsOnPhysicalMapCBSUAdapter(infile);

	System.out.println(theTOPM.getTagCount());
	theTOPM.writeTextFile(new File(outfile));
    }

    public static void removeDuplicateTagsOnMap() {
//	String infile="c:/sample_tags.txt";
        String infile="/Users/edbuckler/SolexaAnal/GBS/reftags/14FCGBS.tg.txt";
        String outfile="/Users/edbuckler/SolexaAnal/GBS/test/14FCGBS.tg.ndup.txt";
	TagsOnPhysicalMap theTOPM=new TagsOnPhysicalMap(infile,false);
        TagsOnPhysicalMap theTOPMNoDup=new TagsOnPhysicalMap(theTOPM,true);

	System.out.println(theTOPMNoDup.getTagCount());
	theTOPMNoDup.writeTextFile(new File(outfile));
        theTOPMNoDup.writeBinaryFile(new File(outfile.replace(".txt", ".bin")));
    }

    /**@param keyFileS A key file (list of populations by barcode).
     * @param qseqFileS qseq files (Illumina-created files with raw read sequence, quality score, machine name, etc.)
     * @param tagMapFileS A tag map file (reads, trimmed to cut sites, with their genome coordinates).
     * @param outReadByTaxaS A tag-by-taxa file (read sequence and presence/absence in one or more taxa).*/
    public static void testBasicPipeline(String keyFileS, String[] qseqFileS, String tagMapFileS, String outReadByTaxaS) {
	/*** NOTE: I commented out the previous lines (below) to convert some files. -JH ***
     //   keyFileS="/Users/edbuckler/SolexaAnal/NGG_IBM/434LFAAXX/434LFAAXX.key.txt";
        keyFileS="/Users/edbuckler/SolexaAnal/GBS/NAM_IBM_MDP_key.txt";
//        String[] qseqFileS={"/Users/edbuckler/SolexaAnal/GBS/8042MABXX/10237245_8042MABXX_s_2_qseq.txt",
//            "/Users/edbuckler/SolexaAnal/GBS/8042MABXX/10237245_8042MABXX_s_3_qseq.txt",
//            "/Users/edbuckler/SolexaAnal/GBS/8042MABXX/10237245_8042MABXX_s_4_qseq.txt"
//        };
        String[] qseqFileS={"/Users/edbuckler/SolexaAnal/NGG_IBM/434LFAAXX/qseq/434LFAAXX_2_qseq.txt"};
//        qseqFileS="/Users/edbuckler/SolexaAnal/GBS/70980AAXX/10232795_70980AAXX_s_1_qseq.txt";
     //   tagMapFileS="/Users/edbuckler/SolexaAnal/GBS/NAMtagmap110113sort.tg.bin";
     //   tagMapFileS="/Users/edbuckler/SolexaAnal/GBS/reftags/14FCGBS.tg.bin";
        tagMapFileS="/Users/edbuckler/SolexaAnal/GBS/reftags/14FCGBS.tg.ndup.bin";
        outReadByTaxaS="/Users/edbuckler/SolexaAnal/GBS/test/ibm110114.rbt.bin";
*/
        TagsOnPhysicalMap theTOPM=new TagsOnPhysicalMap(tagMapFileS,true);  //Reads tag map file into an object
        theTOPM.sortTable(true);
        theTOPM.printRows(500, true, true);
        int uniqueCnt=0;
        for (int i = 0; i < theTOPM.getSize()-1; i++) {
            if(!Arrays.equals(theTOPM.getTag(i), theTOPM.getTag(i+1))) uniqueCnt++;
        }
        System.out.println("The Physical Map Files has UniqueTags:"+uniqueCnt+" TotalLocations:"+theTOPM.getSize());
        TagsByTaxa theTBT=null;
        int goodBarcodedReads=0, allReads=0, goodMatched=0;
        for(int flowNum=0; flowNum<qseqFileS.length; flowNum++) {
            System.out.println("Lane qseq: "+qseqFileS[flowNum]);
            File qseqFile=new File(qseqFileS[flowNum]);
            String[] np=qseqFile.getName().split("_");
            if((np.length<3)&&(np.length>5)) {
                System.out.println("Error in parsing file name (e.g. flowcell_lane_qseq.txt):"+qseqFileS[flowNum]);
                System.out.println("Error in parsing file name (e.g. code_flowcell_s_lane_qseq.txt):"+qseqFileS[flowNum]);
                return;
            }
            ParseBarcodeRead thePBR;
            if(np.length==3) {thePBR=new ParseBarcodeRead(keyFileS, 0, true, np[0], np[1]);}
            else if(np.length==5) {thePBR=new ParseBarcodeRead(keyFileS, 0, true, np[1], np[3]);}
            else {thePBR=new ParseBarcodeRead(keyFileS, 0, true, np[0], np[2]);}
            System.out.println("Total barcodes found in flowcell:"+thePBR.getBarCodeCount());
            String[] taxaNames=new String[thePBR.getBarCodeCount()];
            for (int i = 0; i < taxaNames.length; i++) {
                taxaNames[i]=thePBR.getTheBarcodes(i).getTaxaName();
            }
    //        TagsByTaxa theTBT=new TagsByTaxaByte(taxaNames,theTOPM);
            if(flowNum==0) {theTBT=new TagsByTaxaBit(taxaNames,theTOPM);}
            else {theTBT.addTaxa(taxaNames);}
            int max=200000000;
            String temp="";
            goodBarcodedReads=0; allReads=0; goodMatched=0;
            try{
                System.out.println("qseq File = " + qseqFileS[flowNum]);
                BufferedReader br=new BufferedReader(new FileReader(qseqFileS[flowNum]),65536);
                String sl, qualS="";
                while (((temp = br.readLine()) != null)&&(goodBarcodedReads<max)) {
                    String[] jj=temp.split("\t");
                    allReads++;
                    if(allReads%100000==0) System.out.println("Total Reads:"+allReads+" goodReads:"+goodBarcodedReads+" goodMatched:"+goodMatched);
                    sl=jj[8];
                    qualS=jj[9];
                    ReadBarcodeResult rr=thePBR.divideSolexaFileToTaxaCountList(sl, qualS, false, 0);
                    if(rr!=null) {
                        goodBarcodedReads++;
                        int t=theTBT.getIndexOfTaxaName(rr.getTaxonName());
                        int h=theTBT.getTagIndex(rr.getRead());
                        if(h>-1) {
                            theTBT.addReadsToTagTaxon(h, t, 1);
                            goodMatched++;
                        }
                    }

                }
                br.close();

            }
            catch(Exception e) {
                System.out.println("Catch testBasicPipeline c="+goodBarcodedReads+" e="+e);
                System.out.println(temp);
                e.printStackTrace();
            }
            if(flowNum%10==0) theTBT.writeDistFile(new File(outReadByTaxaS.replace(".tbt.","."+flowNum+".tbt.")),FilePacking.Bit,5);
        }
       theTBT.writeDistFile(new File(outReadByTaxaS),FilePacking.Text,5);
       System.out.println("Count of Tags="+goodBarcodedReads);

    }

    public static void removeLowQualitySite(int chr) {
        double minPresense=0.1;
        double minMAF=0.05;
        double maxHeterozygosity=0.02;
        String infileHMP="/Users/edbuckler/SolexaAnal/GBS/test/ch"+chr+"_NAMwHet_110303.hmp.txt";
        String outfileHMP="/Users/edbuckler/SolexaAnal/GBS/test/ch"+chr+"_NAMwLowHetF10_110303.hmp.txt";
        System.out.println("Reading: "+infileHMP);
        Alignment a=ImportUtils.readFromHapmap(infileHMP);
        System.out.println("UnFiltered Alignment  Taxa:" + a.getSequenceCount() + " Sites:" + a.getSiteCount());
        int minCount=(int)Math.round(a.getSequenceCount()*minPresense);
        int[] goodLowHetSites = AlignmentFilterByGBSUtils.getLowHetSNPs(a, false, maxHeterozygosity, minCount);
        String[] taxaFilter={"BLANK"};
        IdGroup keepTaxa=AlignmentFilterByGBSUtils.getFilteredIdGroupByName(a.getIdGroup(), taxaFilter, false);
        a = FilterAlignment.getInstance(a, goodLowHetSites);
        System.out.println("SiteFiltered Alignment  Taxa:" + a.getSequenceCount() + " Sites:" + a.getSiteCount());
        a = FilterAlignment.getInstance(a, keepTaxa);
        System.out.println("SiteFiltered Alignment  Taxa:" + a.getSequenceCount() + " Sites:" + a.getSiteCount());
        ExportUtils.writeToHapmap(a, false, outfileHMP, '\t');
        Alignment aa=ImportUtils.readFromHapmap(outfileHMP);
        ExportUtils.writeToGZIP(aa, outfileHMP.replace(".txt", ""));
    }

    public static void fuseHapMapWithMultipleChromosomes() {
        String[] infileHMP={"/Users/edbuckler/SolexaAnal/SNP55K/SNP55K_maize282_AGPv1_origStrand_20100513.hmp.txt",
            "/Users/edbuckler/SolexaAnal/GBS/test/HiSeq282wLowHet_110215.hmp.txt"};
        byte[] infilePrefix={(byte)'A',(byte)'G'};
        String outfileHMP="/Users/edbuckler/SolexaAnal/GBS/test/HS55K_110215.hmp.txt";
        Alignment[] a=new Alignment[infileHMP.length];
        IdGroup commonIDs=null;
        int totalSites=0;
        for (int i = 0; i < a.length; i++) {
            System.out.println("Reading:"+infileHMP[i]);
            a[i]=ImportUtils.readFromHapmap(infileHMP[i]);
            if(i==0) {commonIDs=a[i].getIdGroup();}
            else {commonIDs=IdGroupUtils.getCommonIds(commonIDs, a[i].getIdGroup());}
            totalSites+=a[i].getSiteCount();
        }

        MutableSimpleAlignment theMSA=new MutableSimpleAlignment(commonIDs, totalSites, a[0].getLoci());
        int currSite=0;
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].getSiteCount(); j++) {
                theMSA.setLocusOfSite(currSite, a[i].getLocusName(j));  
                theMSA.setPositionOfSite(currSite, a[i].getPositionInLocus(j));
                theMSA.setSitePrefix(currSite, infilePrefix[i]);
            //    theMSA.setStrandOfSite(currSite, (byte)(a[i].isPositiveStrand(j)==0));
                currSite++;
            }
        }
        for (int t = 0; t < theMSA.getSequenceCount(); t++) {
            currSite=0;
            for (int i = 0; i < a.length; i++) {
                int aID=a[i].getIdGroup().whichIdNumber(theMSA.getTaxaName(t));
                for (int j = 0; j < a[i].getSiteCount(); j++) {
                    theMSA.setBase(t, currSite, a[i].getBase(aID, j));
                    currSite++;
                }
            }
        }
        theMSA.sortSiteByPhysicalPosition();
        ExportUtils.writeToHapmap(theMSA, false, outfileHMP, '\t');
    }

    public static void removeByLD(int chr) {
       // String infileHMP="/Users/edbuckler/SolexaAnal/GBS/test/10_HS55K_110215.hmp.txt";
      //  String outfileHMP="/Users/edbuckler/SolexaAnal/GBS/test/HiSeq282wLowHet_110215.hmp.txt";
        String infileHMP="/Users/edbuckler/SolexaAnal/GBS/test/ch"+chr+"_NAMwLowHetF10_110303.hmp.txt";
        String outfileHMP="/Users/edbuckler/SolexaAnal/GBS/test/ch"+chr+"_NAMwLowHetF10LD_110303.hmp.txt";
        System.out.println("Reading: "+infileHMP);
        Alignment a=ImportUtils.readFromHapmap(infileHMP);
        System.out.println("SiteFiltered Alignment  Taxa:" + a.getSequenceCount() + " Sites:" + a.getSiteCount());
        System.out.println("Starting LD calculations");
        int[] gs=AlignmentFilterByGBSUtils.getGoodSitesByLD(a, 0.5, 0.01, 100, 100, 20, true);
        a = FilterAlignment.getInstance(a, gs);
        System.out.println("SiteFiltered Alignment  Taxa:" + a.getSequenceCount() + " Sites:" + a.getSiteCount());
        ExportUtils.writeToHapmap(a, false, outfileHMP, '\t');
    }

    public static void readTextFile(File inFile) {

	System.out.println("Reading tag alignment from:" + inFile.toString());
	String currentLine;
	String mdField = "";
	String cigarString = "";
	String tagSequence = ""; //Sequence of tag (unique read), stored in two long integers.
	String[][] variants;
//	byte tagLength = 64; //Length of tag sequence.
//	byte mappings; //Number of total locations to which the tag maps.
//	byte chromosome; //Chromosome to which the tag maps.
//	boolean strand; //Strand to which the tag maps: false for negative, true for positive.
//	int start;  //Start coordinate of mapping on the reference sequence.
//	int end;   //Start coordinate of mapping on the reference sequence.
//	byte variants; //Total number of bases in tag that differ from reference.
//	byte maxVariants = 4; //MAXIMUM number of variants that can be stored.
//
//	//Position, in read, of base that differs from reference.
//	//Contains one element for each possible variant.
//	byte[] variantOffset = new byte[maxVariants];
//
//	//Type of polymorphism in read, given by the following 4x4 table:
//	//   A    C     G    T
//	//   _________________
//	// A|-127 1     2    3
//	// C|4    -127  5    6
//	// G|7    8     -127 9
//	// T|10   11    12   -127
//	byte[] variantType = new byte[maxVariants];
//
//	byte dcoP; //P-value from test I'm not familiar with
//	byte mapP; //P-value from test I'm not familiar with
//
	try {
	    BufferedReader br = new BufferedReader(new FileReader(inFile), 65536);
	    while((currentLine = br.readLine()) != null){   //Loop through lines of file
		System.out.println("Checking: "+currentLine);
		variants = getVariants(currentLine);
		if(variants != null){
		    for (int j=0; j < variants[0].length; j++){
			System.out.println("Ref haplotype: "+ variants[0][j] + " Tag Haplotype: " + variants[1][j] + " haplotype position: " + variants[2][j]);
		    }
//		    System.out.println(variants[0].toString());
//		    System.out.println(variants[1].toString());
//		    System.out.println(variants[2].toString());
		}
	    }
	    br.close();
//	    int taxaNum = Integer.parseInt(inputLine[0]);
//	    int tagNum = Integer.parseInt(inputLine[1]);
//	    String[] taxaNames = new String[taxaNum];
//	    long[][] tags = new long[2][tagNum];
//	    byte[][] tagDist = new byte[tagNum][taxaNum];
//
//	    inputLine = br.readLine().split("\t");
//	    for (int t = 0; t < taxaNum; t++) {
//		taxaNames[t] = inputLine[t+1];  // blank cell before the taxa list
//	    }
//	    for (int i = 0; i < tagNum; i++) {
//		inputLine = br.readLine().split("\t");
//		tags[0][i] = haplo[0];
//		tags[1][i] = haplo[1];
//		for (int t = 0; t < taxaNum; t++) {
//		    tagDist[i][t] = Byte.valueOf(inputLine[t+1]);
//		}
//		hapsOutput++;
//	    }
	} catch (Exception e) {
	    System.out.println("Catch in reading alignment file e=" + e);
	}

//	    System.out.println("Number of Taxa in file:" + taxaNum);
//	    System.out.println("Number of Haplotypes in file:" + hapsOutput);
    }

  
    public static String[][] getVariants(String inputLine){
	String tagSequence = null;
	String cigarString = null;
	String mdField = null;
	String[] inputLineFields = inputLine.split("\t");
	String[][] mdFieldVariants;
	String[][] cigarStringVariants;
	int recordedVariantCount;
	int totalVariantCount = 0;

	for(int i=0; i < inputLineFields.length; i++){	//Loop through columns of each input line
	    if(inputLineFields[i].matches("MD.*")){mdField = inputLineFields[i].substring(5);} //Get MD Field
	    if(i == 5){tagSequence = inputLineFields[i];} //Get tag sequence
	    if(i == 4){cigarString = inputLineFields[i];} //Get CIGAR string
	}

	mdFieldVariants = parseMDField(mdField, tagSequence);		//Retrieve variants from MD field and CIGAR string.  If there were no variants,
	cigarStringVariants = parseCIGAR(cigarString, tagSequence);	//these methods will return NULL.  So this is checked before concatenating the arrays.

	if(mdFieldVariants != null){totalVariantCount += mdFieldVariants[0].length;}
	if(cigarStringVariants != null){totalVariantCount += cigarStringVariants[0].length;}

	String[][] totalVariants = new String[3][totalVariantCount];	//Make new array to hold all variants
	for(int i=0; i<3; i++){	//Loop through rows
	    recordedVariantCount = 0; //How many variants have been transferred into each row
	    while(recordedVariantCount < totalVariantCount){ //Loop through columns
		if(mdFieldVariants != null){
		    for(int j=0; j<mdFieldVariants[0].length; j++){	    //Fill with variants from md Field
			totalVariants[i][j] = mdFieldVariants[i][j];
			recordedVariantCount++;
		    }
		}
		
		if(cigarStringVariants !=null){
		    for(int j=0; j<cigarStringVariants[0].length; j++){    //Fill with variants from CIGAR string
			totalVariants[i][j+recordedVariantCount] = cigarStringVariants[i][j];
			recordedVariantCount++;
		    }
		}
	    }
	}
	if(mdFieldVariants == null && cigarStringVariants == null){
	    return null;
	}else{
	    return totalVariants;
	}
    }

    /*Searches a CIGAR string for insertions in the
     * reference sequence.
     * @param cigarString The text of the CIGAR string.
     * @param tagSequence The sequence of the CIGAR string's corresponding tag.
     * @return variant A 3x(number of variants) array containging:<br>
     * [0]The character "+"
     * [1]The character "-"
     * [2]The position of the reference insertion relative to the tag.*/
     public static String[][] parseCIGAR(String cigarString, String tagSequence){
	byte cigarStringPosition;
	String currentCharacter;
	String matchingBaseCount = "";
	int tagSequencePosition = 0;
	String refHaplotype = "";
	String tagHaplotype = "";
	String[] variantPosition = new String[64];
	int variantCount = 0;

	try{
	    for(cigarStringPosition = 0; cigarStringPosition < cigarString.length(); cigarStringPosition++){ //Loop through CIGAR string
		currentCharacter = cigarString.substring(cigarStringPosition, cigarStringPosition+1);
		if(currentCharacter.matches("[0-9]")){
			matchingBaseCount = matchingBaseCount.concat(currentCharacter); //Concatenate digits of number
		}
		if(currentCharacter.matches("[A-Za-z]")){
		    tagSequencePosition += Integer.parseInt(matchingBaseCount);
		    matchingBaseCount = "";
		    if(currentCharacter.matches("[I]")){ //An "I" indicates a deletion
			refHaplotype = refHaplotype.concat("+");
			tagHaplotype = tagHaplotype.concat("-");
			variantPosition[variantCount] = Integer.toString(tagSequencePosition);
			variantCount++;
		    }
		}
	    }
	}catch(Exception e){
	    System.out.println("There was an exception in parseCIGAR: "+e);
	}

	//Construct array of return values
	String[][] returnValue = new String[3][variantCount];
	if(variantCount == 0){	//If there are no variants, return NULL
	    returnValue = null;
	}else{
	    for(int i=0; i < variantCount; i++){
		returnValue[0][i] = refHaplotype.substring(i, i+1);
		returnValue[1][i] = tagHaplotype.substring(i, i+1);
		returnValue[2][i] = variantPosition[i];
	    }
	}
	return returnValue;
    }

    /*Decodes the MD: field in a SAM file to determine the location of
     * polymorphisms and whether they are mismatches or deletions from the
     * reference sequence.
     *@param mdField The text of the MD: field, NOT including the MD:Z: prefix!
     *@param tagSequence The sequence of the tag corresponding to mdField.
     *@return variant A 3x(number of variants) array containing:<br>
     *[0] Reference haplotype<br>
     *[1] Tag haplotype<br>
     *[2] Position in tag<br>
     * If there are no polymorphisms in the alignment, the method returns NULL.
     */
    public static String[][] parseMDField(String mdField, String tagSequence){

	String matchingBaseCount = "";
	byte tagSequencePosition = 0;  //pointer to loop through tag sequence
	byte mdFieldPosition;
	boolean deletion = false; //True if a letter indicates a deletion rather than a substitution
	byte deletionLength = 0;
	int variantCount = 0; //Number of variants found in current tag
	String tagHaplotype = "";
	String refHaplotype = "";
	String[] variantPosition = new String[tagSequence.length()]; //There can't be more polymorphisms than bases

	try{
	    for(mdFieldPosition = 0; mdFieldPosition < mdField.length(); mdFieldPosition++){ //Loop through MD field
		if(mdField.substring(mdFieldPosition, mdFieldPosition+1).equals("^")){deletion = true;} //A caret indicates a deletion

		if(mdField.substring(mdFieldPosition, mdFieldPosition+1).matches("[AGCTagct]")){ //A letter indicates a polymorphism
		    tagSequencePosition += Integer.parseInt(matchingBaseCount); //If we came here from a number, move tag pointer
		    matchingBaseCount = ""; //...then reset.

		    if(deletion){
			deletionLength++; //
		    }else{
    //		    System.out.println(mdField.substring(mdFieldPosition, mdFieldPosition+1));
			refHaplotype = refHaplotype.concat(mdField.substring(mdFieldPosition, mdFieldPosition+1)); //Record ref haplotype
			tagHaplotype = tagHaplotype.concat(tagSequence.substring(tagSequencePosition,tagSequencePosition+1)); //Record tag haplotype
			variantPosition[variantCount] = Integer.toString(tagSequencePosition); //Record position in tag
			variantCount++;
			tagSequencePosition++;	//Keep moving tag pointer only if we are not in a deletion
		    }
		}

		if(mdField.substring(mdFieldPosition, mdFieldPosition+1).matches("[0-9]")){
		    if(deletion){
			refHaplotype = refHaplotype.concat("-"); //A number during a deletion indicates a deletion from the reference...
			tagHaplotype = tagHaplotype.concat("+"); //...Or alternatively, an insertion in the tag
			variantPosition[variantCount] = Integer.toString(tagSequencePosition);
			variantCount++;
			deletionLength = 0;
			deletion = false;
		}
		matchingBaseCount = matchingBaseCount.concat(mdField.substring(mdFieldPosition, mdFieldPosition+1)); //Concatenate digits of number
		}
	    }
	}catch(Exception e){
	    System.out.println("There was an exception in parseMDField: "+e);
	}
	//Construct array of return values
	String[][] returnValue = new String[3][variantCount];
	if(variantCount == 0){	//If there are no variants, return NULL
	    returnValue = null;
	}else{
	    for(int i=0; i<variantCount; i++){
		returnValue[0][i] = refHaplotype.substring(i, i+1);
		returnValue[1][i] = tagHaplotype.substring(i, i+1);
		returnValue[2][i] = variantPosition[i];
	    }
	}
        return returnValue;
    }
}
