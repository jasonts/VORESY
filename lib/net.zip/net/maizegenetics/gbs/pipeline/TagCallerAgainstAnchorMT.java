/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.maizegenetics.gbs.pipeline;

import cern.jet.random.Binomial;
import edu.cornell.lassp.houle.RngPack.RandomJava;
import net.maizegenetics.genome.solexa.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.Random;
import net.maizegenetics.gbs.maps.TagsOnPhysicalMap;
import net.maizegenetics.gbs.tagdist.OpenBitSet;
import net.maizegenetics.gbs.tagdist.TagsByTaxa;
import net.maizegenetics.gbs.tagdist.TagsByTaxa.FilePacking;
import net.maizegenetics.gbs.tagdist.TagsByTaxaBit;
import net.maizegenetics.gbs.tagdist.TagsByTaxaBitFileMap;
import net.maizegenetics.gbs.util.SBitAlignment;
import net.maizegenetics.pal.alignment.Alignment;
import net.maizegenetics.pal.alignment.ImportUtils;
import net.maizegenetics.pal.ids.IdGroup;

/**
 *
 * @author edbuckler
 */
public class TagCallerAgainstAnchorMT {
    static int minFreq=1;
    static int minComp=10;
    static double ldThreshold=0.000001;
    static boolean requireNCO=false;
    
    TagsByTaxa theTBT=null;
    TagsOnPhysicalMap theTOPM=null;
    File outfileSiteAttributes;
    int ldPermutation=1;
    boolean isUsingContigency=true;
    int[] tbt2anchRedirect;
    SBitAlignment[] theAnchorChrInBits;

    IdGroup anchorIdGroup;


    public TagCallerAgainstAnchorMT(String tagsByTaxaFileName, String anchorFileName, 
            String blastMapFile, String outfileGoodSitesName) {
        outfileSiteAttributes=new File(outfileGoodSitesName);
        loadAnchorMaps(anchorFileName);
        anchorIdGroup=theAnchorChrInBits[0].getIdGroup();
        System.out.println("Alignment Loaded:"+anchorFileName);
        System.out.println("Read TagsByTaxa:"+tagsByTaxaFileName);
        if(!tagsByTaxaFileName.contains("bibin")) {theTBT=new TagsByTaxaBit(tagsByTaxaFileName, FilePacking.Text);}
        else {theTBT=new TagsByTaxaBitFileMap(tagsByTaxaFileName);}
        String[] taxaNames=theTBT.getTaxaNames();
        int taxaCnt=taxaNames.length;
        tbt2anchRedirect = new int[theTBT.getTaxaNames().length];
        for (int t = 0; t < taxaCnt; t++) {
            tbt2anchRedirect[t] = anchorIdGroup.whichIdNumber(taxaNames[t]);
        }
       // permuteTaxa();
        if(blastMapFile!=null) theTOPM=new TagsOnPhysicalMap(blastMapFile,true);
        run();

    }

    private void permuteTaxa() {
        Random rnd=new Random();
        for (int t = 0; t < tbt2anchRedirect.length; t++) {
            int rt=rnd.nextInt(tbt2anchRedirect.length);
            int temp=tbt2anchRedirect[t];
            tbt2anchRedirect[t]=tbt2anchRedirect[rt];
            tbt2anchRedirect[rt]=temp;
        }
    }

    private void loadAnchorMaps(String anchorFileName) {
        if(anchorFileName.contains("*")) {
            int chrN=6;
            theAnchorChrInBits=new SBitAlignment[chrN];
            for (int i = 0; i < chrN; i++) {
                String file=anchorFileName.replace("*",""+(i+1));
                System.out.println("Reading:"+file);
                Alignment a = ImportUtils.readFromHapmap(file,""+(i+1));
                theAnchorChrInBits[i] = new SBitAlignment(a);
                System.out.printf("Chr %s Sites %d Taxa %d %n", theAnchorChrInBits[i].getLocus(0),
                        theAnchorChrInBits[i].getSiteCount(),theAnchorChrInBits[i].getSequenceCount());
            }
        } else {
            Alignment[] a = ImportUtils.readFromHapmap(anchorFileName).getAlignments();
            theAnchorChrInBits=new SBitAlignment[a.length];
            for (int i = 0; i < a.length; i++) {
                theAnchorChrInBits[i] = new SBitAlignment(a[i]);
    //            System.out.printf("Chr %d Sites %d Taxa %d %n", theAnchorChrInBits[i].getChr(),
    //                    theAnchorChrInBits[i].getNumSites(),theAnchorChrInBits[i].getNumTaxa());
                System.out.printf("Chr %s Sites %d Taxa %d %n", theAnchorChrInBits[i].getLocus(0),
                        theAnchorChrInBits[i].getSiteCount(),theAnchorChrInBits[i].getSequenceCount());
            }
        }
    }

    void run() {
        if(theTBT==null) return;
        if(theAnchorChrInBits==null) return;
        System.out.println("Starting TagCallerAgainstAnchor on:");
        try {
            BufferedWriter fileOutSiteAttr = new BufferedWriter(new FileWriter(outfileSiteAttributes), 100000);
            String row = null;
            int rawCount = 0,
            countGreaterThanMinTaxaWithSNP = 0,
            countGreaterThanMinLogPValue = 0;           
            long starttime = System.currentTimeMillis();            
            fileOutSiteAttr.write(SNPDistV2.toStringAttributesHeader());
            fileOutSiteAttr.write("TestTag\tBlastChr\tBlastPos\tLDChr\tLDSite\tLDPos\tBinomP\tSigTests\tTagTaxaCnt\n");
            int errorCnt=0;
            System.out.println("TestTag\tBlastChr\tBlastPos\tLDChr\tLDSite\tLDPos\tBinomP\tSigTests\tTagTaxaCnt");
            for (int i = 0; i < theTBT.getTagCount(); i++) {
                if(i%100==0) System.out.println("Test Site:"+i+" of "+theTBT.getTagCount());
                if(theTBT.getNumberOfTaxaWithTag(i)<5) continue;
                double[] bestR={-1,-1,-1, 1, -1};
                int blastChr=-1, blastPos=-1;
                if(theTOPM!=null) {
                    int index=theTOPM.getTagIndex(theTBT.getTag(i));
                    if(index>-1) {
                        blastChr=theTOPM.getChromosome(index);
                        blastPos=theTOPM.getPositionMin(index);
                    }
                }
                long[] testTag=getTagsInBits(theTBT,i,tbt2anchRedirect,anchorIdGroup.getIdCount());
                double[][] theResults=new double[theAnchorChrInBits.length][];
                ScanChromosomeMTR[] threads = new ScanChromosomeMTR[theAnchorChrInBits.length];
                for (int cn=0; cn<theAnchorChrInBits.length; cn++) {
                    threads[cn] = new ScanChromosomeMTR(theAnchorChrInBits[cn],testTag, cn, theResults);
                    threads[cn].start();
                }
                for (int t=0; t<theAnchorChrInBits.length; t++) {
                    try {threads[t].join();}
                    catch (Exception e) {e.printStackTrace();}
                }
                for (int cn = 0; cn < theAnchorChrInBits.length; cn++) {
                    double[] r=theResults[cn];
                    if(r[3]<bestR[3]) bestR=r.clone();
                }
                double rate=(double)i/(double)(System.currentTimeMillis()-starttime);
                String s=String.format("%d %d %d %d %d %d %g %d %d %n",i,blastChr, blastPos,
                        (int)bestR[0],(int)bestR[1],(int)bestR[2],bestR[3], (int)bestR[4], theTBT.getNumberOfTaxaWithTag(i));
                if(bestR[3]<0.000001) {System.out.print(rate+"\t");System.out.print(s);}
                fileOutSiteAttr.write(s);
            }
            fileOutSiteAttr.close();
            System.out.println("SNP number:" + rawCount +
                                " count over taxa threshold+:" + countGreaterThanMinTaxaWithSNP +
                                " count over logp threshold:" + countGreaterThanMinLogPValue);
            System.out.println( " finished!");
        } catch (Exception e) {
            System.err.println("File IO in TagCallerAgainstAnchor: " + e);
            e.printStackTrace();
        }
    }


    private class ScanChromosomeMTR extends Thread {
        SBitAlignment refAlignment;
        OpenBitSet obsymj;
        Binomial binomFunc=new Binomial(5, 0.5, new RandomJava());
        int resultIndex;
        double[][] resultReport;

        public ScanChromosomeMTR(SBitAlignment refAlignment, long[] ymj, int resultIndex, double[][] resultReport) {
            this.refAlignment=refAlignment;
            obsymj=new OpenBitSet(ymj,ymj.length);
            this.resultIndex=resultIndex;
            this.resultReport=resultReport;
        }

        public void run() {
            //in the future this may call other threads to split the effort up more
            long tests=0;
            int bestSite=-1, countSig=0;
            double bestP=2;
            for (int i = 0; i < refAlignment.getSiteCount(); i++) {
             //   if(i%10000==0) System.out.println("scanChromosome chr:"+refAlignment.getChr()+"+site:"+i+" with Chr:"+refAlignment.getChr()+" test:"+tests);
                OpenBitSet mj=refAlignment.getSiteBitsNoClone(i, 0);
                OpenBitSet mn=refAlignment.getSiteBitsNoClone(i, 1);
                if(mn.lastCalculatedCardinality()>4) {
                    double p=testSites(obsymj, mj, mn, binomFunc);
                    if(p<bestP) {bestP=p; bestSite=i;}
                    if(p<0.0001) countSig++;
                }
                tests++;
            }
            int chr=Integer.parseInt(refAlignment.getLocus(bestSite).getChromosomeName());
            double[] result={chr, bestSite, refAlignment.getPositionInLocus(bestSite),bestP, countSig};
          //  if(bestP<0.000001) System.out.println(Arrays.toString(result));
            resultReport[resultIndex]=result;
        }

    }


    private static double testSites(OpenBitSet ymj, OpenBitSet xmj, OpenBitSet xmn, Binomial binomFunc) {
        double result=1;
        int mn=0, tag_mn=0, mj=0, tag_mj=0;
        tag_mn=(int)OpenBitSet.intersectionCount(ymj, xmn);
        tag_mj=(int)OpenBitSet.intersectionCount(ymj,xmj);
        mn=(int)xmn.lastCalculatedCardinality();
        mj=(int)xmj.lastCalculatedCardinality();

        int sumAnc = mn + mj;
        int sumTag = tag_mn + tag_mj;
        if(sumTag<4) return result;
        double tag_rat=(tag_mn<tag_mj)?(double)tag_mn/(double)tag_mj:(double)tag_mj/(double)tag_mn;
        if(tag_rat>0.2) return result;
        double minorProb = (tag_mn<tag_mj)?(double)mn/(double)sumAnc:(double)mj/(double)sumAnc;
        binomFunc.setNandP(sumTag,minorProb);
        try {
            result = (tag_mn<tag_mj)?binomFunc.cdf(tag_mn):binomFunc.cdf(tag_mj);
  //          if(result<0.00001) System.out.printf("TS: %d %d %d %d %g %g %n",tag_mn, tag_mj, mn, mj, result, tag_rat);
        } catch (Exception e) {
            System.err.println("Error in the BinomialDistributionImpl");
        }
      //   System.out.printf("%d %d %d %d %g %n",c00,c01,c10,c11, fishersExact.getTwoTailedP(c00, c01, c10, c11));
        return result;
     }


     public long[] getTagsInBits(TagsByTaxa aTBT, int tagIndex, int[] reDirect, int anchorTaxa) {
        int lgPerSite = (anchorTaxa / 64) + 1;
        long[] seq = new long[lgPerSite];
        for (int j = 0; j < aTBT.getTaxaCount(); j++) {
            if(reDirect[j]<0) continue;
            int index=reDirect[j]/64;
            int offset=reDirect[j]%64;
            if (aTBT.getReadCountForTagTaxon(tagIndex, j)>0) {  //reference alleles
                seq[index]=seq[index]|(1L<<offset);
            }
        }
        return seq;
    }


     public static void main(String[] args) {
	System.out.println("Running main method in TagCallerAgainstAnchorMT");
        String blastMapFile="/Users/edbuckler/SolexaAnal/GBS/reftags/14FCGBS.tg.ndup.bin";
//        String anchorMapFile="/Users/edbuckler/SolexaAnal/GBS/hmp/HS55K_110215.hmp.txt";
        String anchorMapFile="/Users/edbuckler/SolexaAnal/GBS/hmp/HiSeq_55K282_110221.imp.hmp.txt";
//        String anchorMapFile="/Users/edbuckler/SolexaAnal/GBS/hmp/ch*_NAMwLowHetF10LD_110303imp.hmp.txt";
  //      String tagsByTaxaFile="/Users/edbuckler/SolexaAnal/GBS/dist/HiSeq282_110214.dist.txt";
    //    String tagsByTaxaFile="/Users/edbuckler/SolexaAnal/GBS/dist/NAMsort_110303.bibin";
        String tagsByTaxaFile="/Users/edbuckler/SolexaAnal/GBS/dist/h10000HiSeq282_110214.dist.txt";
        String outfile="/Users/edbuckler/SolexaAnal/GBS/test/282RandImpAnchor1103121.txt";
        TagCallerAgainstAnchorMT tcaa=new TagCallerAgainstAnchorMT(tagsByTaxaFile, anchorMapFile, blastMapFile, outfile);

    }



}
