/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.maizegenetics.gbs.maps;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.File;
import java.io.IOException;
import net.maizegenetics.genome.BaseEncoder;
import java.lang.Math;
import java.util.Arrays;
import net.maizegenetics.gbs.homology.ParseBarcodeRead;
/**
 * This class can read in a CBSU TagMapFile into the gbs.TagsOnPhysicalMap data
 * structure.
 *
 * @author harriman
 *
 */
public class TagsOnPhysicalMapCBSUAdapter extends TagsOnPhysicalMap {
    boolean cleanCutSites=true;

    public TagsOnPhysicalMapCBSUAdapter(String infile) {
        int columns=-1;
        try {
	    BufferedReader br = new BufferedReader(new FileReader(infile), 65536);
            columns=br.readLine().split("\t").length;
            br.close();
        } catch (IOException e) {
	    System.out.println("Catch in reading alignment file: " + e);
	}
        if(columns==8) {
            readCBSUFileV2(new File(infile));
        } else {
            readCBSUFile(new File(infile));
        }
    }
 
    public void readCBSUFile(File inFile){
	System.out.println("Reading tag alignment from:" + inFile.toString());
	String[] inputLine;
	String[] bestHitsColumn = new String[3];    //Contents of "Best hits" column in CBSU file
	String[] divergenceColumn = new String[3];    //Contents of "#mismatches" column in CBSU file
	try {
	    BufferedReader br = new BufferedReader(new FileReader(inFile), 65536);
	    BufferedReader lineCounter = new BufferedReader(new FileReader(inFile), 65536);
	    tagNum = 0;

	    while(lineCounter.readLine()!=null){tagNum++;}  //Loop through file, count number of lines and then close
	    lineCounter.close();

	    tagLengthInLong = 2;
            maxVariants = 4;
	    initMatrices(tagNum);

	    for (int row = 0; row < tagNum; row++) { //Fill byte arrays

	        inputLine = br.readLine().split("\t");
		for(int samTag = 0; samTag < inputLine.length; samTag++){ //Loop through all columns of the current line
		    if(inputLine[samTag].regionMatches(0, "X0", 0, 2)){	//If the first 2 characters are "X0" (SAM format for best hits), store this as the best hits column.
			bestHitsColumn = inputLine[samTag].split(":");
		    }else{bestHitsColumn[2] = "0";}
		    if(inputLine[samTag].regionMatches(0, "XM", 0, 2)){	//If the first 2 characters are "XM" (SAM format for # mismatches), store this as the divergence column.
			divergenceColumn = inputLine[samTag].split(":");
		    }else{divergenceColumn[2] = "0";}
		}

		multimaps[row] = (byte)Math.min(Integer.parseInt(bestHitsColumn[2]),Byte.MIN_VALUE);  // Whichever is less, the number of best hits or 127, since we only have a byte to work with.
		divergence[row] = (byte)Math.min(Integer.parseInt(divergenceColumn[2]),Byte.MIN_VALUE);
		long[] tagSequence = new long[2];
		tagSequence = BaseEncoder.getLongArrayFromSeq(inputLine[5]);
		tagLength[row] = (byte)inputLine[5].length(); //Length (int cast as byte)
		tags[0][row] = tagSequence[0];  //Sequence
		tags[1][row] = tagSequence[1]; 
		chromosome[row] = (byte)Integer.parseInt(inputLine[2]);    //Chromosome Number

		if(Integer.parseInt(inputLine[1]) == 0){ //Strand
		    strand[row] = 1;  //Forward strand
		}else if(Integer.parseInt(inputLine[1])==16){
		    strand[row] = 0;  //Reverse strand
		}else{
		    strand[row] = Byte.MIN_VALUE; //Unknown
		}

		positionMin[row] = Integer.parseInt(inputLine[3]);  //Start
		positionMax[row] = positionMin[row]+tagLength[row];  //End

                for (int j = 0; j < maxVariants; j++) {
                    variantPosOff[j][row]=Byte.MIN_VALUE;
                    variantDef[j][row]=Byte.MIN_VALUE;
                }

		dcoP[row]= Byte.MIN_VALUE;
		mapP[row]= Byte.MIN_VALUE;
                if(false) {
                    System.out.println(inputLine);
                    System.out.println(this.printRow(row));
                }
	    }
	    br.close();
	} catch (Exception e) {
	    System.out.println("Catch in reading alignment file: " + e);
	}
}

    public void readCBSUFileV2(File inFile){
	System.out.println("Reading tag alignment from:" + inFile.toString());
	String[] inputLine={"Not","Started"};

	//String[] bestHitsColumn = new String[3];    //Contents of "Best hits" column in CBSU file
	//String[] divergenceColumn = new String[3];    //Contents of "#mismatches" column in CBSU file
	try {
	    BufferedReader br = new BufferedReader(new FileReader(inFile), 65536);
	    BufferedReader lineCounter = new BufferedReader(new FileReader(inFile), 65536);
	    tagNum = 0;

	    while(lineCounter.readLine()!=null){tagNum++;}  //Loop through file, count number of lines and then close
	    lineCounter.close();
            System.out.println("Tags in file:"+tagNum);
	    tagLengthInLong = 2;
            maxVariants = 4;
	    initMatrices(tagNum);

	    for (int row = 0; row < tagNum; row++) { //Fill byte arrays

	        inputLine = br.readLine().split("\t");
//		for(int samTag = 0; samTag < inputLine.length; samTag++){ //Loop through all columns of the current line
//		    if(inputLine[samTag].regionMatches(0, "X0", 0, 2)){	//If the first 2 characters are "X0" (SAM format for best hits), store this as the best hits column.
//			bestHitsColumn = inputLine[samTag].split(":");
//		    }else{bestHitsColumn[2] = "0";}
//		    if(inputLine[samTag].regionMatches(0, "XM", 0, 2)){	//If the first 2 characters are "XM" (SAM format for # mismatches), store this as the divergence column.
//			divergenceColumn = inputLine[samTag].split(":");
//		    }else{divergenceColumn[2] = "0";}
//		}

		multimaps[row] = parseByteWMissing(inputLine[6]);  // Whichever is less, the number of best hits or 127, since we only have a byte to work with.
		//divergence[row] = (byte)Math.min(Integer.parseInt(divergenceColumn[2]),127);
                divergence[row]=Byte.MIN_VALUE;
		String tagS=inputLine[7];
                if(cleanCutSites){
		    String[] tagProcessingResults = ParseBarcodeRead.removeSeqAfterSecondCutSite(tagS);
		    tagS=tagProcessingResults[3]; //Tag, cut site processed, padded with poly-A
		}
                long[] tagSequence = new long[2];
		tagSequence = BaseEncoder.getLongArrayFromSeq(tagS);
		tagLength[row] = (byte)inputLine[7].length(); //Length (int cast as byte)
		tags[0][row] = tagSequence[0];  //Sequence
		tags[1][row] = tagSequence[1];
                chromosome[row] = parseByteWMissing(inputLine[2]);   //Chromosome Number

		if(inputLine[1].equals("+")){ //Strand
		    strand[row] = 1;  //Forward strand
		}else if(inputLine[1].equals("-")){
		    strand[row] = 0;  //Reverse strand
		}else{
		    strand[row] = Byte.MIN_VALUE; //Unknown
		}

		if(isInteger(inputLine[3])) {
                    positionMin[row] = Integer.parseInt(inputLine[3]);
                    positionMax[row] = positionMin[row]+tagLength[row];  //End
                } else {
                    positionMin[row] = Integer.MIN_VALUE;
                    positionMax[row] = Integer.MIN_VALUE;  //End
                }


                for (int j = 0; j < maxVariants; j++) {
                    variantPosOff[j][row]=Byte.MIN_VALUE;
                    variantDef[j][row]=Byte.MIN_VALUE;
                }

		dcoP[row]= Byte.MIN_VALUE;
		mapP[row]= Byte.MIN_VALUE;
                if(false) {
                    System.out.println(Arrays.toString(inputLine));
                    System.out.println(this.printRow(row));
                }
	    }
	    br.close();
	} catch (Exception e) {
	    System.out.println("Catch in reading alignment file: " + e);
             System.out.println(Arrays.toString(inputLine));
	}
    }




    boolean isInteger(String s) {
        try{Integer.parseInt(s);}
        catch(NumberFormatException nf) {
            return false;
        }
        return true;
    }


}