package net.maizegenetics.gbs.maps;

import cern.colt.GenericSorting;
import cern.colt.Swapper;
import cern.colt.function.IntComparator;
import net.maizegenetics.gbs.tagdist.Tags;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.Arrays;
import net.maizegenetics.gbs.tagdist.AbstractTags;
import net.maizegenetics.genome.BaseEncoder;

/**
 * Holds tag data compressed in long and a physical position.  
 * This can have two variations either include redundant positions or only unique positions.
 * If redundant than tags that map to multiple regions should be placed adjacently
 *
 * Default 40 bytes per position.  If we have 10,000,000 million positions then this will be at 400M byte data structure.
 *
 * User: ed
 * Date: Jan 26, 2008
 * Time: 8:12:12 AM
 * To change this template use File | Settings | File Templates.
 */
public class TagsOnPhysicalMap extends AbstractTags {
 //  private dep_ReadWithPositionInfo[] shp;
    private int currentSize=0, maxSize=0;
    int maxVariants=4;
    byte[] multimaps;  //number of locations this readSet maps to, unknown Byte.MIN_VALUE
    byte[] chromosome; // 1 byte
    byte[] strand; //'+', '-',"?" //1 byte
    int[] positionMin, positionMax;  //8 byte
    byte[] divergence;  //number of diverging bp from reference, unknown Byte.MIN_VALUE
    byte[][] variantPosOff;  //offset from position minimum, maximum number of variants is defined above - 4 bytes
    byte[][] variantDef; //allele state - A, C, G, T or some indel definition - 4 bytes
    byte[] dcoP, mapP;  //Round(Log2(P)), unknown Byte.MIN_VALUE
            //if these disagree with the location, then set the p to negative
    

    int[] indicesOfSortByPosition;


    public int tagNum = 0;

    //40 bytes per position.  If we have 10,000,000 millions then this will be at 400M byte data structure.

    boolean redundantTags=true;
    

    public TagsOnPhysicalMap() {

    }

    public TagsOnPhysicalMap(String inFile, boolean binary) {
        if(binary) {
            readBinaryFile(new File(inFile));
            currentSize=tagNum;
        } else {
	    readTextFile(new File(inFile));
	}
        initPhysicalSort();
    }
    
    public TagsOnPhysicalMap(int rows) {
        initMatrices(rows);
    }

    public TagsOnPhysicalMap(Tags readList) {
        initMatrices(readList.getTagCount());
        for (int i = 0; i < readList.getTagCount(); i++) {
           // addTag(readList.getTag(i));
        }
    }

    public TagsOnPhysicalMap(TagsOnPhysicalMap oldTOPM, boolean filterDuplicates) {
        this.tagLengthInLong=oldTOPM.tagLengthInLong;
        this.maxVariants=oldTOPM.maxVariants;
        oldTOPM.sortTable(true);
        int uniqueCnt=1;
        for (int i = 1; i < oldTOPM.getSize(); i++) {
            if(!Arrays.equals(oldTOPM.getTag(i-1), oldTOPM.getTag(i))) uniqueCnt++;
        }
        System.out.println("The Physical Map Files has UniqueTags:"+uniqueCnt+" TotalLocations:"+oldTOPM.getSize());
        initMatrices(uniqueCnt);
        this.tagNum=uniqueCnt;
        uniqueCnt=0;
        this.copyTagMapRow(oldTOPM, 0, 0, filterDuplicates);
        for (int i = 1; i < oldTOPM.getTagCount(); i++) {
          //  System.out.println(this.getTag(uniqueCnt)[1]+":"+ oldTOPM.getTag(i)[1]);
          //  System.out.println(":"+ oldTOPM.getTag(i)[1]);
           if(!Arrays.equals(this.getTag(uniqueCnt), oldTOPM.getTag(i))) {
               uniqueCnt++;
     //          copyTagMapRow(oldTOPM, i, uniqueCnt, filterDuplicates);
           } else {
           // System.out.printf("i=%d uniqueCnt=%d %n",i, uniqueCnt);
            }
           copyTagMapRow(oldTOPM, i, uniqueCnt, filterDuplicates); 
        }
        initPhysicalSort();
    }

    void initMatrices(int rows) {
	tags=new long[tagLengthInLong][rows];  //16 bytes

	tagLength=new byte[rows];  //TODO record length of each tag - 1 byte
	multimaps=new byte[rows];  //number of locations this readSet maps to, unknown Byte.MIN_VALUE
	chromosome=new byte[rows]; // 1 byte
	strand=new byte[rows]; //'+', '-',"?" //1 byte
	positionMin=new int[rows];
	positionMax=new int[rows];;  //8 byte
	divergence=new byte[rows];  //number of diverging bp from reference, unknown Byte.MIN_VALUE
	variantPosOff=new byte[maxVariants][rows];  //offset from position minimum, maximum number of variants is defined above - 4 bytes
	variantDef=new byte[maxVariants][rows]; //allele state - A, C, G, T or some indel definition - 4 bytes
	dcoP=new byte[rows];
	mapP=new byte[rows];  //Round(Log2(P)), unknown Byte.MIN_VALUE
		//if these disagree with the location, then set the p to negative
        tagNum=rows;
    }

    void initPhysicalSort() {
        System.out.println("initPhysicalSort");
        indicesOfSortByPosition=new int[tagNum];
        for (int i = 0; i < indicesOfSortByPosition.length; i++) {
            indicesOfSortByPosition[i]=i;
        }
        Swapper swapperPos = new Swapper() {
           public void swap(int a, int b) {
              int t1;
              t1 = indicesOfSortByPosition[a];
              indicesOfSortByPosition[a] = indicesOfSortByPosition[b];
              indicesOfSortByPosition[b] = t1;
           }
        };
        IntComparator compPos = new IntComparator() {
           public int compare(int a, int b) {
            int index1=indicesOfSortByPosition[a];
            int index2=indicesOfSortByPosition[b];
            if(chromosome[index1]<chromosome[index2]) return -1;
            if(chromosome[index1]>chromosome[index2]) return 1;
            if(positionMin[index1]<positionMin[index2]) return -1;
            if(positionMin[index1]>positionMin[index2]) return 1;
            if(strand[index1]<strand[index2]) return -1;
            if(strand[index1]>strand[index2]) return 1;
            for (int i = 0; i < tagLengthInLong; i++) {
                if(tags[i][index1]<tags[i][index2]) return -1;
                if(tags[i][index1]>tags[i][index2]) return 1;
            }
            return 0;
           }
        };
        System.out.println("Position index sort begin.");
        GenericSorting.quickSort(0, indicesOfSortByPosition.length, compPos, swapperPos);
         System.out.println("Position index sort end.");
    }



   /**
    * This helps collapse identical reads from different regions of the genome 
    * together.
    * @param sourceTOPM
    * @param sourceRow
    * @param destRow
    * @param merge
    */
    private void copyTagMapRow(TagsOnPhysicalMap sourceTOPM, int sourceRow, int destRow, boolean merge) {
        boolean overwrite=true;
        long[] ctag=sourceTOPM.getTag(sourceRow);
        if(Arrays.equals(ctag, this.getTag(destRow))&&merge) overwrite=false;
        for (int i = 0; i < tagLengthInLong; i++) {
            tags[i][destRow] = ctag[i];
        }
        if(overwrite) {
            tagLength[destRow]=sourceTOPM.tagLength[sourceRow];  //TODO record length of each tag - 1 byte
            multimaps[destRow]=sourceTOPM.multimaps[sourceRow];  //number of locations this readSet maps to, unknown Byte.MIN_VALUE
            chromosome[destRow]=sourceTOPM.chromosome[sourceRow]; // 1 byte
            strand[destRow]=sourceTOPM.strand[sourceRow]; //'+', '-',"?" //1 byte
            positionMin[destRow]=sourceTOPM.positionMin[sourceRow];
            positionMax[destRow]=sourceTOPM.positionMax[sourceRow];  //8 byte
            divergence[destRow]=sourceTOPM.divergence[sourceRow];  //number of diverging bp from reference, unknown Byte.MIN_VALUE
            for (int j = 0; j < maxVariants; j++) {
                variantPosOff[j][destRow]=sourceTOPM.variantPosOff[j][sourceRow];
                variantDef[j][destRow]=sourceTOPM.variantPosOff[j][sourceRow];
            }
            dcoP[destRow]=sourceTOPM.dcoP[sourceRow];
            mapP[destRow]=sourceTOPM.mapP[sourceRow];
        } else {
            //tagLength[destRow]=tagLength[sourceRow];
            if((chromosome[destRow]!=sourceTOPM.chromosome[sourceRow])||
                    (strand[destRow]!=sourceTOPM.strand[sourceRow])||
                    (positionMin[destRow]!=sourceTOPM.positionMin[sourceRow])||
                    (positionMax[destRow]!=sourceTOPM.positionMax[sourceRow])) {
                multimaps[destRow]+=sourceTOPM.multimaps[sourceRow];
                chromosome[destRow]=strand[destRow]=Byte.MIN_VALUE;
                positionMin[destRow]=positionMax[destRow]=Integer.MIN_VALUE;
            }
            //dcoP[destRow]=dcoP[sourceRow];
            //mapP[destRow]=mapP[sourceRow];
        }
    }

    public String printRow(int row) {
        StringBuilder sb=new StringBuilder();
        sb.append(sb);
        //long
        sb.append(BaseEncoder.getSequenceFromLong(this.getTag(row))+"\t");
        sb.append(printWithMissing(tagLength[row])+"\t");
        sb.append(printWithMissing(multimaps[row])+"\t");
        sb.append(printWithMissing(chromosome[row])+"\t");
        sb.append(printWithMissing(strand[row])+"\t");
        sb.append(printWithMissing(positionMin[row]) + "\t");
        sb.append(printWithMissing(positionMax[row])+"\t");
        sb.append(printWithMissing(divergence[row])+"\t");
        for (int j = 0; j < maxVariants; j++) {
            sb.append(printWithMissing(variantPosOff[j][row])+"\t");
            sb.append(printWithMissing(variantDef[j][row])+"\t");
        }
        sb.append(printWithMissing(dcoP[row])+"\t");
        sb.append(printWithMissing(mapP[row])+"\t");
        return sb.toString();
    }

    public String printRow(int row, boolean byPosition) {
        if(byPosition) return printRow(indicesOfSortByPosition[row]);
        return printRow(row);
    }

    protected void printRows(int numRows) {
        for(int i=0; i<numRows; i++) {
            System.out.println(printRow(i));
        }
    }


   public void printRows(int numRows, boolean requirePhysPosition, boolean byPosition) {
       int outCount=0;
       for(int i=0; outCount<numRows; i++) {
            int r=(byPosition)?indicesOfSortByPosition[i]:i;
            if((requirePhysPosition==true)&&(chromosome[r]<1)) continue;
            System.out.println(printRow(r));
            outCount++;
        }
    }

    public long sortTable(boolean byHaplotype) {
        System.out.print("Starting Read Table Sort ...");
        if(byHaplotype==false) {
            //TODO change the signature at some time
            System.out.print("ERROR:  Position sorting has been eliminated ...");
            return -1;
        }
        long time=System.currentTimeMillis();
        GenericSorting.quickSort(0, tags[0].length, this, this);
        long totalTime=System.currentTimeMillis()-time;
        System.out.println("Done in "+totalTime+"ms");
        initPhysicalSort();
        return totalTime;
    }


    protected void readBinaryFile(File currentFile) {
        try {
            DataInputStream dis = new DataInputStream(new BufferedInputStream(new FileInputStream(currentFile), 65536));
            System.out.println("File = " + currentFile);
            tagNum = dis.readInt();
            tagLengthInLong = dis.readInt();
            maxVariants = dis.readInt();
            initMatrices(tagNum);
            for (int row = 0; row < tagNum; row++) {
                for (int j = 0; j < tagLengthInLong; j++) {
                    tags[j][row] = dis.readLong();
                }
                tagLength[row] = dis.readByte();
                multimaps[row] = dis.readByte();
                chromosome[row] = dis.readByte();
                strand[row] = dis.readByte();
                positionMin[row] = dis.readInt();
                positionMax[row] = dis.readInt();
                divergence[row] = dis.readByte();
                for (int j = 0; j < maxVariants; j++) {
                    variantPosOff[j][row] = dis.readByte();
                    variantDef[j][row] = dis.readByte();
                }
                dcoP[row] = dis.readByte();
                mapP[row] = dis.readByte();
                //tagsInput++;
                if(row%1000000==0) System.out.println("TagMapFile Row Read:"+row);
            }
            dis.close();
        } catch (Exception e) {
            System.out.println("Error c=" + currentSize + " e=" + e);
        }
        System.out.println("Count of Tags=" + currentSize);
    }

   public void writeBinaryFile(File outFile, int minResolution, boolean requirePhysPosition,
       boolean requireDCOMap, float minDCOP, boolean binary) {
       int hapsOutput=0;
       try{
       DataOutputStream fw=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(outFile),4000000));
       fw.writeInt(tagNum);
       fw.writeInt(tagLengthInLong);
       fw.writeInt(maxVariants);
       for (int row = 0; row < tagNum; row++) {
//         if((requirePhysPosition==true)&&(shp[i].isChromosomeKnown()!=true)) continue;
//         if((shp[i].positionMax-shp[i].positionMin)>minResolution) continue;
//         if(requireDCOMap) {
//         if(Float.isNaN(shp[i].getDcoP())||(shp[i].getDcoP()>minDCOP)||(shp[i].getDcoP()<0)) continue;
           for (int j = 0; j < tagLengthInLong; j++) {
               fw.writeLong(tags[j][row]);
           }
           fw.writeByte(tagLength[row]);
           fw.writeByte(multimaps[row]);
           fw.writeByte(chromosome[row]);
           fw.writeByte(strand[row]);
           fw.writeInt(positionMin[row]);
           fw.writeInt(positionMax[row]);
           fw.writeByte(divergence[row]);
           for (int j = 0; j < maxVariants; j++) {
               fw.writeByte(variantPosOff[j][row]);
               fw.writeByte(variantDef[j][row]);
           }
           fw.writeByte(dcoP[row]);
           fw.writeByte(mapP[row]);
           hapsOutput++;
       }

       fw.flush();
       fw.close();
       System.out.println("Haplotypes positions written to:"+outFile.toString());
       System.out.println("Number of Haplotypes in file:"+hapsOutput);
       }
       catch(Exception e) {
             System.out.println("Catch in writing output file e="+e);
       }
   }

   public void writeBinaryFile(File outFile) {
       writeBinaryFile(outFile, Integer.MAX_VALUE, false, false, Float.NaN, true);
   }

   protected void writeBinaryFile(File outFile, boolean binary) {
       writeBinaryFile(outFile, Integer.MAX_VALUE, false, false, Float.NaN, binary);
   }


   public void readTextFile(File inFile) {
        System.out.println("Reading tag alignment from:" + inFile.toString());
	String[] inputLine={"NotRead"};
	try {
	    BufferedReader br = new BufferedReader(new FileReader(inFile), 65536);
	    inputLine = br.readLine().split("\t");

	    //Parse header line (Number of tags, number of Long ints per tag, maximum variant bases per tag).
	    this.tagNum = Integer.parseInt(inputLine[0]);
	    this.tagLengthInLong = Integer.parseInt(inputLine[1]);
	    this.maxVariants = Integer.parseInt(inputLine[2]);
           // initMatrices(9000000);
	    initMatrices(tagNum);
	    //Loop through remaining lines, store contents in a series of arrays indexed by row number
	    for (int row = 0; row < tagNum; row++) {
		inputLine = br.readLine().split("\t");
                int c=0;
		long[] tt = BaseEncoder.getLongArrayFromSeq(inputLine[c++]);
                for (int j = 0; j < tt.length; j++) {
                    tags[j][row] = tt[j];
                }
		tagLength[row]=parseByteWMissing(inputLine[c++]);  //TODO record length of each tag - 1 byte
		multimaps[row] = parseByteWMissing(inputLine[c++]);  //number of locations this readSet maps to, unknown Byte.MIN_VALUE
		chromosome[row] = parseByteWMissing(inputLine[c++]); // 1 byte
                strand[row]=parseByteWMissing(inputLine[c++]);
		positionMin[row] = parseIntWMissing(inputLine[c++]);
		positionMax[row] = parseIntWMissing(inputLine[c++]);  //8 byte
		divergence[row] = parseByteWMissing(inputLine[c++]);  //number of diverging bp from reference, unknown Byte.MIN_VALUE
                for (int j = 0; j < maxVariants; j++) {
                    variantPosOff[j][row]=parseByteWMissing(inputLine[c++]);//offset from position minimum, maximum number of variants is defined above - 4 bytes
                    variantDef[j][row]=parseByteWMissing(inputLine[c++]);//allele state - A, C, G, T or some indel definition - 4 bytes
                }
		dcoP[row]=parseByteWMissing(inputLine[c++]);
		mapP[row]=parseByteWMissing(inputLine[c++]);
                if(row%100000==0) System.out.println("Row Read:"+row);
	    }
	} catch (Exception e) {
	    System.out.println("Catch in reading TagOnPhysicalMap file e=" + e);
            e.printStackTrace();
            System.out.println(Arrays.toString(inputLine));
	}
        System.out.println("Number of tags in file:" + tagNum);
    }

   public void writeTextFile(File outfile) {
       try{
           DataOutputStream fw = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(outfile), 65536));
           fw.writeBytes(tagNum + "\t" + tagLengthInLong + "\t"+maxVariants+"\n");
           for (int row = 0; row < tagNum; row++) {
               fw.writeBytes(printRow(row)+"\n");
           }
           fw.flush();
           fw.close();
       } catch (Exception e) {
	    System.out.println("Catch in writeTextFile file e=" + e);
	}
        System.out.println("Number of tags in file:" + tagNum);

   }

   public int getReadIndexForPositionIndex(int posIndex) {
       return indicesOfSortByPosition[posIndex];
   }
   
   public int[] getPositionArray(int index) {
       int[] r={chromosome[index],strand[index],positionMin[index]};
       return r;
   }

    public int getReadIndex(byte chr, byte strand, int posMin) {
   //     dep_ReadWithPositionInfo querySHP=new dep_ReadWithPositionInfo(chr, strand, posMin);
   //     PositionComparator posCompare = new PositionComparator();
    //    int hit1=Arrays.binarySearch(shp, querySHP, posCompare);
        int hit1=-1;  //redo
        return hit1;
    }

    public static String printWithMissing(byte b){
        if(b==Byte.MIN_VALUE) return "*";
        return Byte.toString(b);
    }

    public static String printWithMissing(int i){
        if(i==Integer.MIN_VALUE) return "*";
        return Integer.toString(i);
    }

    public static byte parseByteWMissing(String s) {
        if(s.equals("*")) return Byte.MIN_VALUE;
        int i;
        try{i=Integer.parseInt(s);
            if(i>127) return 127;
            return (byte)i;
        }
        catch(NumberFormatException nf) {
            return Byte.MIN_VALUE;
        }
    }

    public static int parseIntWMissing(String s) {
        if(s.equals("*")) return Integer.MIN_VALUE;
        int i;
        try{i=Integer.parseInt(s);
            return i;
        }
        catch(NumberFormatException nf) {
            return Integer.MIN_VALUE;
        }
    }
   

    public int getSize() {
        return tagNum;
    }

    public byte getChromosome(int index) {
        return chromosome[index];
    }

    public int getPositionMax(int index) {
        return positionMax[index];
    }

    public int getPositionMin(int index) {
        return positionMin[index];
    }


    @Override
    public void swap(int index1, int index2) {
        long tl;
        for (int i = 0; i < tagLengthInLong; i++) {
            tl=tags[i][index1];
            tags[i][index1]=tags[i][index2];
            tags[i][index2]=tl;
        }
        byte tb;
        tb=tagLength[index1];tagLength[index1]=tagLength[index2]; tagLength[index2]=tb;
        tb=multimaps[index1];multimaps[index1]=multimaps[index2]; multimaps[index2]=tb;
        tb=chromosome[index1];chromosome[index1]=chromosome[index2]; chromosome[index2]=tb;
        tb=strand[index1];strand[index1]=strand[index2]; strand[index2]=tb;
        int ti;
        ti=positionMin[index1];positionMin[index1]=positionMin[index2]; positionMin[index2]=ti;
        ti=positionMax[index1];positionMax[index1]=positionMax[index2]; positionMax[index2]=ti;
        tb=divergence[index1];divergence[index1]=divergence[index2]; divergence[index2]=tb;
        for (int j = 0; j < maxVariants; j++) {
            tb=variantPosOff[j][index1]; variantPosOff[j][index1]=variantPosOff[j][index2]; variantPosOff[j][index2]=tb;
            tb=variantDef[j][index1]; variantDef[j][index1]=variantDef[j][index2]; variantDef[j][index2]=tb;
        }
        tb=dcoP[index1];dcoP[index1]=dcoP[index2]; dcoP[index2]=tb;
        tb=mapP[index1];mapP[index1]=mapP[index2]; mapP[index2]=tb;
    }

    @Override
    public int compare(int index1, int index2) {
        for (int i = 0; i < tagLengthInLong; i++) {
            if(tags[i][index1]<tags[i][index2]) return -1;
            if(tags[i][index1]>tags[i][index2]) return 1;
        }
        if(chromosome[index1]<chromosome[index2]) return -1;
        if(chromosome[index1]>chromosome[index2]) return 1;
        if(positionMin[index1]<positionMin[index2]) return -1;
        if(positionMin[index1]>positionMin[index2]) return 1;
        if(strand[index1]<strand[index2]) return -1;
        if(strand[index1]>strand[index2]) return 1;
        return 0;
    }

}
