package net.maizegenetics.gbs.tagdist;

import net.maizegenetics.gbs.tagdist.TagCounts;
import net.maizegenetics.gbs.tagdist.Tags;
import cern.colt.GenericSorting;
import java.io.File;
import java.util.Arrays;

/**
 * Tags and collapses ReadCount files from multiple taxa (entire directory of read
 * count files.  It tries to hold as
 * many haplotypes as memory will allow, and then it eliminates the rare ones.
 *
 * User: ed
 * Date: Jan 26, 2008
 * Time: 8:12:12 AM
 * To change this template use File | Settings | File Templates.
 */
public class CombineReadCounts extends TagCounts {
    private int maxRows=30000000;  // 50000000 works for Jeff on Aztec

    public CombineReadCounts(String inDir, String outFile, int minCount, boolean binary) {
        super();
        init();
        processDirectoryForFusion(new File(inDir), new File(outFile), minCount, binary);
    }
    
    public CombineReadCounts(Tags baseReads, String inDir, String outFile, int minCount, boolean binary) {
        super();
        init();
        addBaseReads(baseReads, minCount);
        baseReads=null;
        System.gc();
        GenericSorting.quickSort(0, tags[0].length, this, this);
        processDirectoryForFusion(new File(inDir), new File(outFile), minCount, binary);
    }

    public CombineReadCounts(Tags baseReads1, Tags baseReads2, String inDir, String outFile, int minCount, boolean binary) {
        super();
        init();
        addBaseReads(baseReads1, minCount);
        baseReads1=null;
        System.gc();
        addBaseReads(baseReads2, minCount);
        baseReads2=null;
        System.gc();
        GenericSorting.quickSort(0, tags[0].length, this, this);
        processDirectoryForFusion(new File(inDir), new File(outFile), minCount, binary);
    }

    public CombineReadCounts(String inFile1, String inFile2, String outFile, int minCount, boolean binary) {
        super();
        init();
        TagCounts rc1 = new TagCounts(inFile1, true);
        addReadCounts(rc1);
        rc1=null;
        System.gc();
        TagCounts rc2 = new TagCounts(inFile2, true);
        addReadCounts(rc2);
        rc2=null;
        System.gc();
        GenericSorting.quickSort(0, tags[0].length, this, this);
        collapseCounts();
        writeCountFile(new File(outFile), minCount, binary);
    }


    private void init() {
      tags=new long[2][maxRows];
      readCount=new int[maxRows];
        for (int i = 0; i < getSize(); i++) {
            tags[0][i]=Long.MAX_VALUE;
            tags[1][i]=Long.MAX_VALUE;
        }
    }

    /**
     * This adds a series of reference reads to the list, and by setting them to 
     * the minCount they will always remain
     * @param baseReads
     * @param minCount
     */
    private void addBaseReads(Tags baseReads, int minCount) {
        long[] lastRead=new long[2];
        int duplicates=0;
        for (int i = 0; i < baseReads.getTagCount(); i++) {
           long[] ls = baseReads.getTag(i);
           if(Arrays.equals(ls, lastRead)) {duplicates++; continue;}
           tags[0][currentRows]=ls[0];
           tags[1][currentRows]=ls[1];
           readCount[currentRows]=minCount;
           currentRows++;
           lastRead=ls;
        }
        System.out.println("Reads:"+baseReads.getTagCount()+"Duplicates Found:"+duplicates);
    }


    /**
     * This adds a series of TagCounts to the list, preserving the count that each read has.
     * Assumes no duplicates, so Duplicates Found should be 0.
     * Designed to make it easy to combine TagCounts from multiple flowcells.
     * @param ReadCountsToAdd
     */
    private void addReadCounts(TagCounts ReadCountsToAdd) {
        long[] lastRead=new long[2];
        int duplicates=0;
        for (int i = 0; i < ReadCountsToAdd.getTagCount(); i++) {
           long[] ls = ReadCountsToAdd.getTag(i);
           if(Arrays.equals(ls, lastRead)) {duplicates++; continue;}
           tags[0][currentRows]=ls[0];
           tags[1][currentRows]=ls[1];
           readCount[currentRows]=ReadCountsToAdd.getReadCount(i);
           currentRows++;
           lastRead=ls;
        }
        System.out.println("Reads:"+ReadCountsToAdd.getTagCount()+"Duplicates Found:"+duplicates);
    }


    public void processDirectoryForFusion(File inDirectory, File outFile, int minCount, boolean binary) {
        System.out.println("Current Rows:"+currentRows);
        int totalHapsRead=0;
        int fileCnt=0;
        for(File fn: inDirectory.listFiles())  {
            if(fn.getPath().contains("DS_Store")) continue;  //a mac problem
       //    printRows(50);
            fileCnt++;
           TagCounts currSHF=new TagCounts(fn.getPath(),true);
           if(currSHF.getSize()+currentRows>maxRows) {
               //eliminate the infrequent rows
               resetRareHaplotypes(2);
               GenericSorting.quickSort(0, tags[0].length, this, this);
           }
           addHaplotypes(currSHF);
           GenericSorting.quickSort(0, tags[0].length, this, this);
           totalHapsRead+=currSHF.getTagCount();
           System.out.println("Current Rows: "+currentRows+"   totalHapsRead: "+totalHapsRead+"   from: "+fileCnt+" files");
 //          System.out.println("Rows Sorted");printRows(100);
 //          collapseCounts();
 //          System.out.println("Rows collapsed");printRows(100);
       }
       writeCountFile(outFile, minCount, binary);
    }

   protected void addHaplotypes(TagCounts currSHF) {
       //the is just binary add not mergesort.  I could try merge sort
       int start=0, end=currentRows;
       for (int i = 0; i < currSHF.getSize(); i++) {
           long[] ls = {currSHF.tags[0][i],currSHF.tags[1][i]};
           int hit=this.binarySearchOfHaps(ls, start, end);
           if(hit<0) {
               //add a new read the end of the list
               tags[0][currentRows]=currSHF.tags[0][i];
               tags[1][currentRows]=currSHF.tags[1][i];
               readCount[currentRows]=currSHF.readCount[i];
               currentRows++;
           } else {
               //add to the current list
               readCount[hit]+=currSHF.readCount[i];
           }
       }
   }

   private void resetRareHaplotypes(int minCount) {
       for (int i = 0; i < tags[0].length; i++) {
           if((readCount[i]>0)&&(readCount[i]<minCount)) {
                tags[0][i]=Long.MAX_VALUE;
                tags[1][i]=Long.MAX_VALUE;
                readCount[i]=0;
                currentRows--;
           }
       }
       GenericSorting.quickSort(0, tags[0].length, this, this);
   }


   public static void main(String[] args) {
       if((args.length<2)||(args[0].equals("-h"))) {
           System.out.println("Require args: inDirectory outFile (-c minCount) (-b txt/binary)");
           System.exit(1);
       } else if (args.length==2) {
           CombineReadCounts be=new CombineReadCounts(args[0], args[1], 2, true);
       }  else if (args.length>2) {
           System.out.println("Need to implement the parser");
           System.exit(1);
       }
  }
}
