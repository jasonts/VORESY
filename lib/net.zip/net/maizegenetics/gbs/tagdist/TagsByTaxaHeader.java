package net.maizegenetics.gbs.tagdist;
import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.File;

/** @author jvh39 */

/** Holds the taxon names and counts found at the beginning of each TagsByTaxa file.*/
public class TagsByTaxaHeader {
    int tagNum;
    int tagLengthInLong;
    int taxaNum;
    String[] taxaNames;
    DataInputStream rw;

    TagsByTaxaHeader(File inputFile){
        try{
            rw = new DataInputStream(new BufferedInputStream(new FileInputStream(inputFile), 4000000));
            tagNum = rw.readInt(); //Read header
            tagLengthInLong = rw.readInt();
            taxaNum = rw.readInt();
            taxaNames = new String[taxaNum];

            for (int t = 0; t < taxaNum; t++){
                taxaNames[t] = rw.readUTF();
            }
            rw.close();

        } catch (Exception e) {
	    System.out.println("Caught exception while reading file header: " + e);
	    e.printStackTrace();
	}

    }
}
