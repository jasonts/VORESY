package net.maizegenetics.gbs.tagdist;

import cern.colt.GenericSorting;
import cern.colt.Swapper;
import cern.colt.function.IntComparator;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Arrays;
import net.maizegenetics.genome.BaseEncoder;

/**
 * Holds tags data compressed in long and read counts.  Has basic filtering methods.
 *
 * User: ed
 * Date: Jan 26, 2008
 * Time: 8:12:12 AM
 * To change this template use File | Settings | File Templates.
 */
public class TagCounts extends AbstractTags {
//    int tagLengthInLong=2;  //TODO fully implement on reading
//    long[][] tags;  //for memory efficiency the rows first and second half of the read
    //columns are the index of the reads.
    int[] readCount;
//    byte[] tagLength;  //TODO record length of each tag
    int currentRows;

    public TagCounts() {
        currentRows = 0;
    }

    public TagCounts(String inFile, String outFile, int minCount, boolean binary, boolean simpleFilter, boolean combineIdenticalTaxa) {
        currentRows = 0;
        if(simpleFilter) {
            simpleFilter(new File( inFile), new File(outFile), minCount, binary);
        } 
        else if (combineIdenticalTaxa) {
            combineIdenticalTaxa(new File(inFile), binary);
            processDirectoryForCounting(new File(inFile), new File(outFile), minCount, binary);
        }
        else {
            processDirectoryForCounting(new File(inFile), new File(outFile), minCount, binary);
        }
    }

    public TagCounts(String inFile, String rowOut) {
        currentRows = 0;
        File fn=new File(inFile);
        int rows=(int)(fn.length()/20);  //20 is the number of bytes 2 longs (2*8b) + 1 int (4b)
        tags=new long[2][rows];
        readCount=new int[rows];
        readSolexaFastaToCountList(new File(inFile),rows);
        this.printRows(Integer.parseInt(rowOut));
    }

    public TagCounts(String inFile, boolean binary) {
        currentRows = 0;
        File fn=new File(inFile);
        int rows=(int)(fn.length()/20);  //20 is the number of bytes 2 longs (2*8b) + 1 int (4b)
        tags=new long[2][rows];
        readCount=new int[rows];
        readSolexaFastaToCountList(new File(inFile),rows);
    }

    public TagCounts(long[][] haps, int[] hapcnt, int maxCount) {
        currentRows = 0;
        if((haps.length!=2)||(haps[0].length!=hapcnt.length)) return;
        if((maxCount>haps[0].length)||(maxCount<0)) maxCount=haps[0].length;
        this.tags=new long[haps.length][maxCount];
        this.readCount=new int[maxCount];
        for (int i = 0; i < maxCount; i++) {
            tags[0][i]=haps[0][i];
            tags[1][i]=haps[1][i];
            readCount[i] = hapcnt[i];
            ++currentRows;
        }
        printRows(100);
 //       GenericSorting.quickSort(0, tags[0].length, comp, swapper);
        GenericSorting.quickSort(0, tags[0].length, this, this);
        printRows(100);
    }

    public int getReadCount(int index) {
        if(index>=readCount.length) return -1;
        return readCount[index];
    }

    public long[] getTag(int index) {
        if(index>=tags[0].length) return null;
        long[] result={tags[0][index],tags[1][index]};
        return result;
    }

    @Override
    public int getTagIndex(long[] read) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    /**
     * This is the number of different reads in the list (NOT THE SUM OF THE COUNTS)
     * The index will vary from 0 to (ReadTotal-1)
     * This is the number of distinct reads if readUnique is true
     * @return total number of reads
     */
    public int getTagCount() {
        return tags[0].length;
    }

    private void processDirectoryForCounting(File inDirectory, File outDirectory, int minCount, boolean binary) {
        for(File fn: inDirectory.listFiles())  {
           int rows=(int)(fn.length()/20);  //20 is the number of bytes 2 longs (2*8b) + 1 int (4b)
           currentRows = 0;
           tags=new long[2][rows];
           readCount=new int[rows];
           readSolexaFastaToCountList(fn, rows);
 //           System.out.println("Rows Read");printRows(100);
 //          GenericSorting.quickSort(0, tags[0].length, comp, swapper);
           GenericSorting.quickSort(0, tags[0].length, this, this);
 //          System.out.println("Rows Sorted");printRows(100);
           collapseCounts();
 //          System.out.println("Rows collapsed");printRows(100);
           File outFile=new File(outDirectory.getPath()+"/"+fn.getName());
           writeCountFile(outFile, minCount, binary);
       }
    }

    private void combineIdenticalTaxa(File inDirectory, boolean binary) {
        File[] FileList = inDirectory.listFiles();
        Arrays.sort(FileList);
        System.out.println("\n\nSorted readCount files in input directory:");
        for(File fn: FileList)  {
           System.out.println(fn.getName());
        }
        System.out.println("\n");
        File prevFile = null;
        String prevTaxon = "";
        String prevFlowcell = "";
        for(File currFile: FileList)  {
            String[] fileParts = currFile.getName().split("_");
            String currTaxon = fileParts[0];
            String currFlowcell = fileParts[1];
            fileParts = currFile.getName().split("\\.");
            String ext = fileParts[fileParts.length-1];
            if (currTaxon.equals(prevTaxon) && ext.equals("cnt")) {  // the second condition was added to prevent unintentional deletion of files
                System.out.println(prevFile.getName() + " and " + currFile.getName() + " are being merged");
                boolean sameFlowcell;
                if (currFlowcell.equals(prevFlowcell)) {
                    sameFlowcell = true;
                }
                else {
                    sameFlowcell = false;
                    currFlowcell = "merge";
                }
                currFile = mergeIdenticalTaxa(prevFile, currFile, currTaxon, sameFlowcell, binary);
            }
            prevFile = currFile;
            prevTaxon = currTaxon;
            prevFlowcell = currFlowcell;
        }
    }

    private File mergeIdenticalTaxa(File prevFile, File currFile, String Taxon, boolean sameFlowcell, boolean binary) {
        String mergedFileName;
        if (sameFlowcell) {
           mergedFileName = currFile.getParent() + "/" + Taxon + "_" + currFile.getName().split("_")[1] + "_merged.cnt";
        }
        else {
           mergedFileName = currFile.getParent() + "/" + Taxon + "_merged.cnt";
        }
        TagCounts mergedRC = new TagCounts();
        TagCounts rc1 = new TagCounts(prevFile.getPath(), true);
        TagCounts rc2 = new TagCounts(currFile.getPath(), true);
        int rows = rc1.currentRows + rc2.currentRows;
        mergedRC.tags=new long[2][rows];
        mergedRC.readCount=new int[rows];
        mergedRC.addReadCounts(rc1);
        rc1=null;
        prevFile.delete();
        System.gc();
        mergedRC.addReadCounts(rc2);
        rc2=null;
        currFile.delete();
        System.gc();
        File mergedFile = new File(mergedFileName);
        mergedRC.writeCountFile(mergedFile, 0, binary);
        return mergedFile;
    }


    /**
     * This adds a series of TagCounts to the list, preserving the count that each read has.
     * Designed to make it easy to combine TagCounts from multiple barcodes, lanes or flowcells.
     * @param ReadCountsToAdd
     */
   private void addReadCounts(TagCounts ReadCountsToAdd) {
        for (int i = 0; i < ReadCountsToAdd.getTagCount(); i++) {
           long[] ls = ReadCountsToAdd.getTag(i);
           this.tags[0][currentRows]=ls[0];
           this.tags[1][currentRows]=ls[1];
           this.readCount[currentRows]=ReadCountsToAdd.getReadCount(i);
           currentRows++;
        }
    }

    protected void printRows(int numRows) {
        for(int i=0; i<numRows; i++) {
            System.out.println(BaseEncoder.getSequenceFromLong(tags[0][i])+
                    BaseEncoder.getSequenceFromLong(tags[1][i])+
                    " "+
                   readCount[i]
                    );
        }
    }

    protected void readSolexaFastaToCountList(File currentFile, int hapsToRead) {
        int totalReads=0;
        try{
         DataInputStream dis = new DataInputStream(new BufferedInputStream (new FileInputStream(currentFile),65536));
        System.out.println("File = " + currentFile);
            String temp, sl;
            for(int i=0; i<hapsToRead; i++) {
                tags[0][i]=dis.readLong();
                tags[1][i]=dis.readLong();
                readCount[i]=dis.readInt();
                totalReads++;
                ++currentRows;
            }
        dis.close();
        }
        catch(Exception e) {
            System.out.println("Error c="+totalReads+" e="+e);
        }
       System.out.println("Count of Tags="+totalReads);
    }

   protected void collapseCounts() {
       //requires that the reads are sorted
       int collapsedRows=0;
       for(int i=1; i<currentRows; i++) {  // formerly: i<tags[0].length  (changed by Jeff)
           if((tags[0][i-1]==tags[0][i])&&(tags[1][i-1]==tags[1][i])) {
               readCount[i]+=readCount[i-1];
               readCount[i-1]=0;
               collapsedRows++;
           }
       }
       System.out.println("Rows collapsed:"+collapsedRows);
   }

   protected void writeCountFile(File outFile, int minCount, boolean binary) {
      // int c=1;
       int hapsOutput=0;
       try{
       DataOutputStream fw=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(outFile),4000000));       
       for(int i=0; i<tags[0].length; i++) {
//         if((tags[0][i]==tags[0][i+1])&&(tags[1][i]==tags[1][i+1])) {
//             c++;
//         }
//         else {
         if(readCount[i]>=minCount) {
             if(!binary) {fw.writeBytes(
             BaseEncoder.getSequenceFromLong(tags[0][i])+
             BaseEncoder.getSequenceFromLong(tags[1][i])+" "+readCount[i]+"\n");}
             else {fw.writeLong(tags[0][i]);
                fw.writeLong(tags[1][i]);
                fw.writeInt(readCount[i]);
             }
            hapsOutput++;
//          c=1;
         }
       }
       fw.flush();
       fw.close();
       System.out.println("Haplotypes written to:"+outFile.toString());
       System.out.println("Number of Haplotypes in file:"+hapsOutput);
       }
       catch(Exception e) {
             System.out.println("Catch in writing output file e="+e);
       }
   }

    private void simpleFilter(File infile, File outfile, int minCount, boolean binary) {
       int hapsOutput=0;
       try{
       DataInputStream dis = new DataInputStream(new BufferedInputStream (new FileInputStream(infile),65536));
       DataOutputStream dos=new DataOutputStream(new BufferedOutputStream(new FileOutputStream(outfile),65536));
       System.out.println(infile+" being subsetted to:"+ outfile);
       int rows=(int)(infile.length()/20);  //20 is the number of bytes 2 longs (2*8b) + 1 int (4b)
       System.out.println("Number of Haplotypes in file:"+rows);
       long[] hap=new long[2];
       int hcnt;
       for(int i=0; i<rows; i++) {
         hap[0]=dis.readLong();
         hap[1]=dis.readLong();
         hcnt=dis.readInt();
         if(hcnt>=minCount) {
             if(!binary) {dos.writeBytes(
             BaseEncoder.getSequenceFromLong(hap[0])+
             BaseEncoder.getSequenceFromLong(hap[1])+" "+hcnt+"\n");}
             else {dos.writeLong(hap[0]);
                dos.writeLong(hap[1]);
                dos.writeInt(hcnt);
             }
            hapsOutput++;
         }
       }
       dos.flush();
       dos.close();
       dis.close();
       System.out.println("Number of Haplotypes written to outfile:"+hapsOutput);
       }
       catch(Exception e) {
             System.out.println("Catch in writing output file e="+e);
       }
   }

    public int getSize() {
        return tags[0].length;
    }

    public int getTotalCount() {
        int totalCount=0;
        for (int i = 0; i < readCount.length; i++) {
            totalCount+=readCount[i];
        }
        return totalCount;
    }


   public int binarySearchOfHaps(long[] key, int start, int end) {
      int hit1=Arrays.binarySearch(tags[0], start, end, key[0]);
      if(hit1<0) return -1;
      int hit2=hit1;
      while((hit2>0)&&(tags[0][hit2-1]==key[0])) {
          hit2--;
      }
      while((tags[0][hit2]==key[0])&&(hit2<tags[0].length)) {
          if(tags[1][hit2]==key[1]) {
              return hit2;
          }
          hit2++;
      }
      return -1;
  }


   @Override
    public void swap(int index1, int index2) {
        long temp;
        for (int i = 0; i < tagLengthInLong; i++) {
            temp=tags[i][index1];
            tags[i][index1]=tags[i][index2];
            tags[i][index2]=temp;
        }
        byte tl;
        tl=tagLength[index1];tagLength[index1]=tagLength[index2]; tagLength[index2]=tl;
        int t3;
        t3=readCount[index1]; readCount[index1]=readCount[index2]; readCount[index2]=t3;
    }

    @Override
    public int compare(int index1, int index2) {
        for (int i = 0; i < tagLengthInLong; i++) {
            if(tags[i][index1]<tags[i][index2]) return -1;
            if(tags[i][index1]>tags[i][index2]) return 1;
        }
        if(readCount[index1]<readCount[index2]) return -1;
        if(readCount[index1]>readCount[index2]) return 1;
        return 0;
    }

//// Swapper swapper = new Swapper() {
//   public void swap(int a, int b) {
//      long t1, t2;
//      t1 = tags[0][a]; tags[0][a] = tags[0][b];	tags[0][b] = t1;
//      t2 = tags[1][a]; tags[1][a] = tags[1][b]; tags[1][b] = t2;
//      int t3;
//      t3=readCount[a]; readCount[a]=readCount[b]; readCount[b]=t3;
//   }
////};
//
////IntComparator comp = new IntComparator() {
//   public int compare(int a, int b) {
//      if (tags[0][a]==tags[0][b]) return tags[1][a]==tags[1][b] ? 0 : (tags[1][a]<tags[1][b] ? -1 : 1);
//      return tags[0][a]<tags[0][b] ? -1 : 1;
//   }
////};

   public static void main(String[] args) {
       if((args.length<1)||(args[0].equals("-h"))) {
           System.out.println("Require args: inDirectory (outDirectory) (-c minCount) (-b txt/binary)");
           System.exit(1);
       } else if (args[0].equals("-f")) {
           TagCounts be=new TagCounts(args[1],args[2], 10, true, true, false);
       } else if (args[0].equals("-p")) {
           TagCounts be=new TagCounts(args[1],args[2]);
       } else if (args.length==1) {
           TagCounts be=new TagCounts(args[0],args[0], 1, true, false, false);
       } else if (args.length==2) {
           TagCounts be=new TagCounts(args[0], args[1], 1, true, false, false);
       }  else if (args.length>2) {
           System.out.println("Need to implement the parser");
           System.exit(1);
       }
  }

    @Override
    public int[] getTagIndexSet(long[] read) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public boolean areTagsUnique() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int getTagSizeInLong() {
        return tagLengthInLong;
    }

    @Override
    public int getTagLength(int index) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public long[][] getTags() {
        return tags;
    }


}
