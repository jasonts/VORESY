/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.maizegenetics.gbs.tagdist;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.Random;


/**
 *
 * @author edbuckler
 */
public class TagsByTaxaBitFileMap extends AbstractTagsByTaxa{
    private RandomAccessFile theRAF;
   // private FileInputStream theRAF;
    private FileChannel inChannel;
    private long dataStartPos=-1;
 //   private BitSet[] tagDist;
    private int bufferedTagIndex=Integer.MIN_VALUE;
    private OpenBitSet bufferedTagDist=null;
    private int numLongPerTaxaDist=-1;
    private long byteLenRow=-1;

  

     public TagsByTaxaBitFileMap(String infile) {
        readDistFile(new File(infile), FilePacking.Bit);
        bufferedTagDist=new OpenBitSet(taxaNum);
    }

    @Override
    public void readDistFile(File inFile, FilePacking binary) {
        int hapsOutput = 0;
        try {
            theRAF=new RandomAccessFile(inFile, "r");
            int tagNum = theRAF.readInt();
            tagLengthInLong = theRAF.readInt();
            taxaNum = theRAF.readInt();
            initMatrices(taxaNum, tagNum);
            for (int t = 0; t < taxaNum; t++) {
                taxaNames[t] = theRAF.readUTF();
            }
            dataStartPos=theRAF.getFilePointer();
            System.out.printf("TaxaRead: %d %n", theRAF.getFilePointer());
            numLongPerTaxaDist=OpenBitSet.bits2words(taxaNum);
//            long[] distInLong=new long[numLongPerTaxaDist];
//            OpenBitSet obs;
            byteLenRow=1+(8*(tagLengthInLong+numLongPerTaxaDist));
            byte[] b=new byte[(int)byteLenRow];
            for (int i = 0; i < tagNum; i++) {
                if(i%1000000==0) System.out.println("Read tag"+i);
                theRAF.read(b);
                ByteBuffer bb=ByteBuffer.wrap(b);
                for (int j = 0; j < tagLengthInLong; j++) {
		    tags[j][i] = bb.getLong();
		}
                tagLength[i]=bb.get();

                hapsOutput++;
            }
   //         theRAF.close();
            inChannel=(new FileInputStream(inFile)).getChannel();
         //   inChannel=theRAF.getChannel();
        } catch (Exception e) {
            System.out.println("Catch in reading input file: " + e);
	    e.printStackTrace();
        }
        System.out.println("Number of Taxa in file:" + taxaNum);
        System.out.println("Number of Haplotypes in file:" + hapsOutput);
    }




    @Override
    public void setReadCountForTagTaxon(int tagIndex, int taxaIndex, int value) {
        throw new UnsupportedOperationException("Not supported yet.");
//        tagDist[taxaIndex].set(tagIndex, (value!=0));
    }



    @Override
    public int getReadCountForTagTaxon(int tagIndex, int taxaIndex) {
        if(tagIndex!=bufferedTagIndex) bufferTagDist(tagIndex);
        if(bufferedTagDist.get(taxaIndex)) return 1;
        return 0;

    }

    synchronized private void bufferTagDist(int tagIndex) {
        try{
            long pos=(byteLenRow*(long)tagIndex)+dataStartPos+((long)tagLengthInLong*8L)+1L;
            theRAF.seek(pos);
 //           if(tagIndex<10) System.out.printf("G: %d %d %n", tagIndex, theRAF.getFilePointer());
            byte[] b=new byte[numLongPerTaxaDist*8];
            theRAF.read(b);
            ByteBuffer bb=ByteBuffer.wrap(b);
            for (int j = 0; j < numLongPerTaxaDist; j++) {
                bufferedTagDist.bits[j] = bb.getLong();
            }
            bufferedTagIndex=tagIndex;
        } catch(IOException e) {
            System.out.println("Catch in reading bufferTagDist: " + e);
	    e.printStackTrace();
        }
    }

    synchronized private void bufferTagDistX(int tagIndex) {
        try{
            long pos=(byteLenRow*(long)tagIndex)+dataStartPos+((long)tagLengthInLong*8L)+1L;
            bufferedTagDist.bits[0]=pos;

  //          theRAF.seek(pos);
  //          if(tagIndex!=10) System.out.printf("G: %d %d %n", tagIndex, theRAF.getFilePointer());
            byte[] b=new byte[numLongPerTaxaDist*8];
           // theRAF.read(b);
            
            ByteBuffer bb=ByteBuffer.wrap(b);
//            System.out.println(Arrays.toString(bb.array()));
            int bread=inChannel.read(bb, pos);
//            System.out.println(bread+":"+b.length);
//            System.out.println(Arrays.toString(bb.array()));
            bb.rewind();
            for (int j = 0; j < numLongPerTaxaDist; j++) {
                bufferedTagDist.bits[j] = bb.getLong();
            }
            bufferedTagIndex=tagIndex;
        } catch(IOException e) {
            System.out.println("Catch in reading bufferTagDist: " + e);
	    e.printStackTrace();
        }
    }

    @Override
    public void initMatrices(int taxaNum, int tagNum) {
        taxaNames = new String[taxaNum];
        tags = new long[tagLengthInLong][tagNum];
        tagLength = new byte[tagNum];
    }

    @Override
    public void addTaxa(String[] addTaxaNames) {
        throw new UnsupportedOperationException("Not supported yet.");
//        taxaNum=tagDist.length+addTaxaNames.length;
//        BitSet[] newTagDist = new BitSet[taxaNum];
//        String[] newTaxaNames = new String[taxaNum];
//        for(int i=0; i<newTagDist.length; i++) {
//            if(i<tagDist.length) {
//                newTagDist[i]=tagDist[i];
//                newTaxaNames[i]=taxaNames[i];
//                }
//            else {
//                newTagDist[i]=new BitSet(getTagCount());
//                newTaxaNames[i]=addTaxaNames[i-tagDist.length];
//            }
//        }
//        tagDist=newTagDist;
//        taxaNames=newTaxaNames;
    }

     public static void main(String[] args) {
	System.out.println("Running main method in TagsByTaxaBitFileMap");
//        String infile="/Users/edbuckler/SolexaAnal/GBS/test/h10000HiSeq282_110214.dist.bibin";
         String infile="/Users/edbuckler/SolexaAnal/GBS/dist/NAMsort_110303.bibin";
    //    String infile="/Users/edbuckler/SolexaAnal/GBS/test/real_output.bibin";
        String outfile2="/Users/edbuckler/SolexaAnal/GBS/test/dupfm_h10000HiSeq282_110322.dist.txt";
        TagsByTaxaBitFileMap tbtb2=new TagsByTaxaBitFileMap(infile);
        long currTime=System.currentTimeMillis();
        int count=0;
        Random rnd=new Random();
        int rows=10000, currRow=10;
        for(int i=0; i<rows; i++) {
            if(i%4!=0) {currRow++;} else {currRow=rnd.nextInt(8000000);}
            if(tbtb2.getReadCountForTagTaxon(currRow, i%280)==1) count++;

  //          if(tbtb2.getReadCountForTagTaxon(75, i%280)==1) count++;
        }
        long totTime=System.currentTimeMillis()-currTime;
        double rate=(double)rows/(double)totTime;
         System.out.printf("Total time: %d   Count:%d Rate: %g %n", totTime, count, rate);
  //      tbtb2.writeDistFile(new File(outfile2), FilePacking.Text, -1);

    }

}
