/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.maizegenetics.gbs.tagdist;

import java.io.File;
import net.maizegenetics.pal.ids.IdGroup;

/**
 *
 * @author edbuckler
 */
public interface TagsByTaxa extends Tags
//        , IdGroup
{
    public static enum FilePacking {Bit, Byte, Short, Int, Text};

    void addReadsToTagTaxon(int tagIndex, int taxaIndex, int addValue);

    int getIndexOfTaxaName(String taxon);

    int getReadCountForTagTaxon(int tagIndex, int taxaIndex);

    byte[] getTaxaReadCountsForTag(int readIndex);

    int getTaxaCount();

    /**
     * Get the number of taxa with a given tag 
     * It is count of the taxa with readCount>0
     * @param readIndex
     * @return number of taxa with a read
     */
    int getNumberOfTaxaWithTag(int readIndex);

    String getTaxaName(int taxaIndex);

    String[] getTaxaNames();

    void setReadCountForTagTaxon(int tagIndex, int taxaIndex, int value);

    void writeDistFile(File outFile, FilePacking fileType, int minCount);

    void initMatrices(int taxaNum, int tagNum);

    /**
     * Add taxa to the TagsByTaxa matrix, they will all be set to distribution value of
     * zero.
     * @param addTaxaNames
     */
    void addTaxa(String[] addTaxaNames);

}
