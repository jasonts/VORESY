/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package net.maizegenetics.gbs.tagdist;

import cern.colt.GenericSorting;
import cern.colt.Swapper;
import cern.colt.function.IntComparator;
import java.util.Arrays;
import java.util.HashMap;
import net.maizegenetics.pal.alignment.AbstractAlignment;
import net.maizegenetics.pal.alignment.Alignment;
import net.maizegenetics.pal.alignment.Locus;
import net.maizegenetics.pal.datatype.DataType;
import net.maizegenetics.pal.datatype.IUPACNucleotides;
import net.maizegenetics.pal.ids.IdGroup;

/**
 *
 * @author edbuckler
 */
public class MutableSimpleAlignment extends AbstractAlignment {
 
    private byte[][] seq;

    private Locus[] myLocus;
    private byte[] lociForSite;
    private int[] variableSites;
    private byte[] strand;
    private byte[] sitePrefix;
    private int siteNumber;
    private int nextFreeSite=0;
    private HashMap<String,Byte> locusNameToLociByte;

    public MutableSimpleAlignment(IdGroup taxa, int maxSites, Locus[] myLoci) {
       super(taxa,new IUPACNucleotides());
       myLocus=myLoci;
       siteNumber=maxSites;
       seq=new byte[getSequenceCount()][siteNumber];
       variableSites=new int[siteNumber];
       strand = new byte[siteNumber];
       lociForSite = new byte[siteNumber];
       sitePrefix= new byte[siteNumber];
       for(int t=0; t<getSequenceCount(); t++) Arrays.fill(seq[t], DataType.UNKNOWN_BYTE);
       Arrays.fill(variableSites, -1);
       Arrays.fill(strand, (byte)0);
       Arrays.fill(lociForSite, (byte)0);
       Arrays.fill(sitePrefix, (byte)'S');
       locusNameToLociByte=new HashMap<String,Byte>();
       for (byte i = 0; i < myLoci.length; i++) {
            locusNameToLociByte.put(myLoci[i].getName(),i);
        }

    }

    public MutableSimpleAlignment(String[] taxaNames, int maxSites, Locus[] myLoci) {
        this(new net.maizegenetics.pal.ids.SimpleIdGroup(taxaNames), maxSites, myLoci);
    }

    public MutableSimpleAlignment(Alignment a) {
        this(a.getIdGroup(), a.getSiteCount(), a.getLoci());
        for (int s = 0; s < a.getSiteCount(); s++) {
            setLocusOfSite(s, a.getLocusName(s));
            setPositionOfSite(s, a.getPositionInLocus(s));
            setSitePrefix(s, (byte)a.getSNPID(s).charAt(0));
            for (int i = 0; i < a.getSequenceCount(); i++) {
                setBase(i,s,a.getBase(i, s));
            }
        }
    }


    public void sortSiteByPhysicalPosition() {
        System.out.println("initPhysicalSort");
        Swapper swapperPos = new Swapper() {
           public void swap(int a, int b) {
              byte bt;
              bt=lociForSite[a]; lociForSite[a]=lociForSite[b]; lociForSite[b]=bt;
              bt=strand[a]; strand[a]=strand[b]; strand[b]=bt;
              bt=sitePrefix[a]; sitePrefix[a]=sitePrefix[b]; sitePrefix[b]=bt;
               for (int t = 0; t < getSequenceCount(); t++) {
                   bt=getBase(t,a);
                   setBase(t,a,getBase(t,b));
                   setBase(t,b,bt);
               }
              int it;
              it=variableSites[a]; variableSites[a]=variableSites[b]; variableSites[b]=it;
           }
        };
        IntComparator compPos = new IntComparator() {
           public int compare(int a, int b) {
            if(lociForSite[a]<lociForSite[b]) return -1;
            if(lociForSite[a]>lociForSite[b]) return 1;
            if(variableSites[a]<variableSites[b]) return -1;
            if(variableSites[a]>variableSites[b]) return 1;
            if(strand[a]<strand[b]) return -1;
            if(strand[a]>strand[b]) return 1;
            return 0;
           }
        };
        System.out.println("Alignment sort begin.");
        GenericSorting.quickSort(0, this.getSiteCount(), compPos, swapperPos);
         System.out.println("Alginment sort end.");
    }

    @Override
    public char getBaseChar(int taxon, int site) {
        return (char)getBase(taxon,site);
    }

    @Override
    public byte getBase(int taxon, int site) {
        return seq[taxon][site];
    }

    public void setPositionOfSite(int site, int position) {
        variableSites[site]=position;
        if(site>=nextFreeSite) nextFreeSite=site+1;
    }
    
    public void setStrandOfSite(int site, byte strand) {
        this.strand[site]=strand;
        if(site>=nextFreeSite) nextFreeSite=site+1;
    }

    public void setBase(int taxon, int site, byte base) {
        seq[taxon][site]=base;
    }

    public void setLocusOfSite(int site, byte locusIndex) {
        lociForSite[site]=locusIndex;
        if(site>=nextFreeSite) nextFreeSite=site+1;
    }

    public void setLocusOfSite(int site, String locusName) {
        setLocusOfSite(site,locusNameToLociByte.get(locusName));
    }

    public byte getSitePrefix(int site) {
        return sitePrefix[site];
    }

    public void setSitePrefix(int site, byte prefix) {
        this.sitePrefix[site] = prefix;
    }



    public int getNextFreeSite() {
        return nextFreeSite;
    }

    @Override
    public byte getBase(int taxon, int site, int allele) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public byte getBase(int taxon, Locus locus, int physicalPosition, int allele) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    public String[] getSNPIDs() {
        int sites = getSiteCount();
        String[] SNPids = new String[sites];
        for (int i = 0; i < sites; i++) {
            SNPids[i] = getSNPID(i);
        }
        return SNPids;
    }

    @Override
    public String getSNPID(int site) {
        return ((char)getSitePrefix(site))+getLocus(site).getChromosomeName()+"_"+variableSites[site];
    }

    @Override
    public int getSiteCount() {
        return nextFreeSite;
    }

    @Override
    public int getLocusSiteCount(Locus locus) {
        return getSiteCount();
    }

    @Override
    public int getPositionInLocus(int site) {
        return variableSites[site];
    }

    @Override
    public int getSiteOfPhysicalPosition(int physicalPosition, Locus locus) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public byte getPositionType(int site) {
        throw new UnsupportedOperationException("Not supported yet.");
    }



    @Override
    public byte[] getPositionTypes() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Locus getLocus(int site) {
        return myLocus[lociForSite[site]];
    }

    @Override
    public Locus[] getLoci() {
        return myLocus;
    }

    @Override
    public int getNumLoci() {
        return 1;
    }

}
