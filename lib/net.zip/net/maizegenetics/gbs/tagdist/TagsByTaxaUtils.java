package net.maizegenetics.gbs.tagdist;
import java.util.Arrays;
import java.util.HashSet;
import java.util.TreeSet;
import java.util.ArrayList;
import java.io.File;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedReader;
import java.io.FileReader;
import net.maizegenetics.genome.BaseEncoder;

/** @author jvh39 */
public class TagsByTaxaUtils {

    /**Prints bitsets in human-readable format for debugging purposes.
     *@param bitset An OpenBitSet object.
     *@return result A string of 1s and 0s representing the contents of the bitset.     */
    public static String bitsetToString(OpenBitSet bitset){
        String result=null;
        for(int i=0; i<bitset.wlen;i++){
            if(bitset.fastGet(i)){result.concat("1");}
            else{result.concat("0");}
        }
        return result;
    }

    public static void streamTextToBinary(String inputFileName, String outputFileName){
     	try{
            BufferedReader br = new BufferedReader(new FileReader(inputFileName), 65536);
            int hapsOutput=0; //Number of tags written to output file
            
            //Read header
            String[] inputLine = br.readLine().split("\t");
            int tagNum = Integer.parseInt(inputLine[0]);
            int tagLengthInLong=Integer.parseInt(inputLine[1]);
            int taxaNum = Integer.parseInt(inputLine[2]);
            String[] taxaNames = new String[taxaNum];   //Taxa name array
            OpenBitSet obs = new OpenBitSet(taxaNum);   //Distribution bitset

            //Read taxon names
            inputLine = br.readLine().trim().split("\t");
            for (int t = 0; t < taxaNum; t++) {
                taxaNames[t] = inputLine[t];
            }
            
            //Write header
            DataOutputStream fw = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(outputFileName), 65536));
            fw.writeInt(tagNum);
            fw.writeInt(tagLengthInLong);
            fw.writeInt(taxaNum);
            for (int t = 0; t < taxaNum; t++) {
                fw.writeUTF(taxaNames[t]);
            }

            //Loop through tags
            for (int i = 0; i < tagNum; i++) {
                inputLine = br.readLine().split("\t");                              //Read tag...
                long[] tagSequence = BaseEncoder.getLongArrayFromSeq(inputLine[0]); //Sequence
                byte tagLength = Byte.parseByte(inputLine[1]);                      //Length
                for (int t = 0; t < taxaNum; t++) {
                    if(inputLine[t+2]=="1"){obs.set(t);}                            //Distribution
                }

                for (int j = 0; j < tagLengthInLong; j++) fw.writeLong(tagSequence[j]); //Write sequence
                fw.writeByte(tagLength);                                                //Write length
                long[] obsInLong=obs.getBits();                                         //Put bitset in array
                for (int t = 0; t < obsInLong.length; t++) {
                    fw.writeLong(obsInLong[t]);                                         //Write distribution
                }
                hapsOutput++;
            }
            fw.close();
            br.close();
            
            System.out.println("Number of Taxa in file:" + taxaNum);
            System.out.println("Number of Haplotypes in file:" + hapsOutput);
        } catch (Exception e) {
            System.out.println("Catch in writing output file e=" + e);
            e.printStackTrace();
        }
    }

    /**<p>Combines two TagsByTaxa files, updating the number and distribution of tags and taxa
     *accordingly.</p>
     *<p>It first loops through each provided file, reading only the headers, to generate
     *a master list of taxa that will be in the output file.  It then loops through the
     *files again, this time reading each tag record.  It creates a new presence/absence
     * bitfield for each tag, and sets the bits that correspond to bits in the previous
     * distribution.  It uses a TreeSet collection (red-black tree) to look up taxa
     * quickly by name, since the bit representing them may vary from file to file.</p>
     * @param inputFiles TagsByTaxa files to be merged.
     * @param outputFile Merged output file.*/
    public static void mergeBitDistFiles(File[] inputFiles, File outputFile){
	TreeSet<String> mergedTaxaNameList = new TreeSet<String>();
	ArrayList<String> currTaxaNameList = new ArrayList<String>();
	int totalTaxaNumber =0;
	int totalTagNumber = 0;
        int tagLengthInLong = 0;
        int currTaxaNum;
        String currTaxon = null;
        TagsByTaxaHeader fileHeader;
	try{
	    for(File inputFile: inputFiles){ //Loop through files once to determine total # of tags and taxa.
		DataInputStream rw = new DataInputStream(new BufferedInputStream(new FileInputStream(inputFile), 4000000));

                int tagNum = rw.readInt(); //Read header
		totalTagNumber+=tagNum;
                tagLengthInLong = rw.readInt();
		currTaxaNum = rw.readInt();

                //Add taxon names to TreeSet.  Set objects are checked before adding
                //new elements so that they never contain duplicates.
		for (int t = 0; t < currTaxaNum; t++){
                    mergedTaxaNameList.add(rw.readUTF());
                }
		rw.close();
	    }
	} catch (Exception e) {
	    System.out.println("Caught exception while merging input file: " + e);
	    e.printStackTrace();
            }
	

        //Set objects are not ordered, so I dump the master list into an array before looping over it.
	totalTaxaNumber = mergedTaxaNameList.size();
        Object[] mergedTaxaNameArray = mergedTaxaNameList.toArray(); 
 	int longsInMergedBitset = OpenBitSet.bits2words(totalTaxaNumber);

	//Loop through again to merge all records
        try{
		DataOutputStream w = new DataOutputStream(new BufferedOutputStream(new FileOutputStream(outputFile), 4000000));
		w.writeInt(totalTagNumber);
		w.writeInt(tagLengthInLong);
		w.writeInt(totalTaxaNumber);
		for(int i=0; i<totalTaxaNumber; i++){
  		    w.writeUTF(mergedTaxaNameArray[i].toString()); //Write merged taxon names
		}

		for(File inputFile: inputFiles){
		    DataInputStream rw = new DataInputStream(new BufferedInputStream(new FileInputStream(inputFile), 4000000));

                    int tagNum = rw.readInt();  //Read header and declare file-specific variables
		    tagLengthInLong = rw.readInt();
		    currTaxaNum = rw.readInt();

                    long[] currTag = new long[tagLengthInLong]; //tag sequence
                    byte currTagLength = 0;
                    String[] currTaxaNames = new String[currTaxaNum]; //taxon names in current file
                    int numberOfLongs=OpenBitSet.bits2words(currTaxaNum);
                    long[] distInLong=new long[numberOfLongs]; //Array for current bitset
                    long[] mergedBitSetArray = new long[longsInMergedBitset]; //Array for output bitset
                    OpenBitSet mergedBitSet = new OpenBitSet(mergedBitSetArray, longsInMergedBitset);//Output bitset

                    //Read current taxon names
		    for (int t = 0; t < currTaxaNum; t++){
			currTaxaNames[t]= rw.readUTF();
		    }


		    /*  Begin loop of PAIN */
		    for (int i = 0; i < tagNum; i++) {
                        currTaxaNameList.clear();  //Get name list ready for next record

                        for (int j = 0; j < tagLengthInLong; j++) { //Read tag sequence
			    currTag[j] = rw.readLong();
			}

			currTagLength=rw.readByte();                 //Read tag length

                        for (int j = 0; j < numberOfLongs; j++) {   //Read distribution into array
                            distInLong[j] = rw.readLong();
                        }
                        OpenBitSet obs = new OpenBitSet(distInLong,currTaxaNum); //Convert array to bitset

                        //If current tag's bit is set, add corresponding name to list of taxa for tag
                        //NOTE: taxon names should be in register with bits in bitset!
			for (int t = 0; t < currTaxaNames.length; t++) {
			    if(obs.fastGet(t)){
                                currTaxaNameList.add(currTaxaNames[t]);
                                obs.clear(t);
                            }
			}


			for(int v=0; v<mergedTaxaNameArray.length; v++){
                                mergedBitSet.fastClear(v);  //Clear first, in case it is still set
			    if(currTaxaNameList.contains(mergedTaxaNameArray[v])){  //If current taxa are in the merged list,
				mergedBitSet.set(v);                                //set their corresponding bits in the merged bitset
			    }
			}
                        mergedBitSetArray = mergedBitSet.getBits(); //Put merged dist. into array

                        for (int j = 0; j < tagLengthInLong; j++) { //Write tag sequence
			    w.writeLong(currTag[j]);
			}
			w.writeByte(currTagLength);                  //Write tag length

			for (int j = 0; j < longsInMergedBitset; j++) {
			    w.writeLong(mergedBitSetArray[j]);      //write distribution
			}
		    }
		    rw.close();

		}
		w.close();
	    } catch (Exception e) {
		System.out.println("Caught exception while merging output file: " + e);
		e.printStackTrace();
	    }
       }
}
