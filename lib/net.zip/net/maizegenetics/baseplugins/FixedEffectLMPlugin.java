package net.maizegenetics.baseplugins;

import java.awt.Frame;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.TreeSet;

import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

import org.apache.log4j.Logger;

import net.maizegenetics.gui.ReportDestinationDialog;
import net.maizegenetics.jGLiM.LinearModelUtils;
import net.maizegenetics.jGLiM.dm.CovariateModelEffect;
import net.maizegenetics.jGLiM.dm.FactorModelEffect;
import net.maizegenetics.jGLiM.dm.ModelEffect;
import net.maizegenetics.jGLiM.dm.ModelEffectUtils;
import net.maizegenetics.jGLiM.dm.SweepFastLinearModel;
import net.maizegenetics.jGLiM.dm.SweepFastNestedModel;
import net.maizegenetics.pal.alignment.GeneticMap;
import net.maizegenetics.pal.alignment.MarkerPhenotype;
import net.maizegenetics.pal.alignment.MarkerPhenotypeAdapter;
import net.maizegenetics.pal.alignment.MarkerPhenotypeAdapterUtils;
import net.maizegenetics.pal.alignment.Phenotype;
import net.maizegenetics.pal.alignment.SimplePhenotype;
import net.maizegenetics.pal.alignment.Trait;
import net.maizegenetics.pal.ids.Identifier;
import net.maizegenetics.pal.ids.SimpleIdGroup;
import net.maizegenetics.pal.report.SimpleTableReport;
import net.maizegenetics.pal.report.TableReport;
import net.maizegenetics.plugindef.AbstractPlugin;
import net.maizegenetics.plugindef.DataSet;
import net.maizegenetics.plugindef.Datum;

public class FixedEffectLMPlugin extends AbstractPlugin {
    private static final Logger myLogger = Logger.getLogger(FixedEffectLMPlugin.class);
    private GeneticMap myMap;
    private boolean hasMap;
    private boolean writeOutputToFile = false;
    private String outputName = null;
    private boolean filterOutput = false;
    private double maxp = 1;
    private boolean reportBLUEs = true;
    
    public FixedEffectLMPlugin (Frame parentFrame, boolean isInteractive) {
        super(parentFrame, isInteractive);
    }

    public DataSet performFunction(DataSet input) {
    	
    	List<Datum> maps = input.getDataOfType(GeneticMap.class);
    	if (maps.size() > 0) {
    		myMap = (GeneticMap) maps.get(0).getData();
    		hasMap = true;
    	} else {
    		myMap = null;
    		hasMap = false;
    	}

    	List<Datum> datasets = input.getDataOfType(Phenotype.class);
    	if (datasets.size() < 1) {
    		String msg = "Error in performFuntion: No appropriate dataset selected.";
    		myLogger.error(msg);
			if (isInteractive()) JOptionPane.showMessageDialog(getParentFrame(), msg, "Error in GLM", JOptionPane.ERROR_MESSAGE);

    		return null;
    	}
    	
    	if (isInteractive()) {
    		ReportDestinationDialog rdd = new ReportDestinationDialog();
            rdd.setLocationRelativeTo(getParentFrame());
    		rdd.setVisible(true);
    		if (!rdd.isOkayChecked()) return null;
    		writeOutputToFile = rdd.wasUseFileChecked();
    		if (writeOutputToFile) outputName = rdd.getOutputFileName();
    		filterOutput = rdd.wasRestrictOutputChecked();
    		if (filterOutput) maxp = rdd.getMaxP();
    	}
    	
    	LinkedList<Datum> results= new LinkedList<Datum>();
    	for (Datum dataset : datasets) {
    		LinkedList<Datum> result = null;
    		try {result = processDatum(dataset);}
    		catch (Exception e) {
    			myLogger.error(e.getMessage());
    			e.printStackTrace();
    			if (isInteractive()) JOptionPane.showMessageDialog(getParentFrame(), e.getMessage(), "Error in GLM", JOptionPane.ERROR_MESSAGE);
    		}
    		if (result != null) results.addAll(result);
    		fireDataSetReturned(new DataSet(result, this));
    	}
    	return new DataSet(results, this);
    }

    private LinkedList<Datum> processDatum(Datum dataset) {
    	ArrayList<Object[]> markerTestResults = new ArrayList<Object[]>();
    	ArrayList<Object[]> alleleEstimateResults = new ArrayList<Object[]>();
    	boolean hasAlleleNames = false;
    	String blank = new String("");
    	
    	//build the base model
    	MarkerPhenotypeAdapter theAdapter;
    	if (dataset.getDataType().equals(MarkerPhenotype.class)) {
    		theAdapter = new MarkerPhenotypeAdapter((MarkerPhenotype) dataset.getData());
    	}
    	else theAdapter = new MarkerPhenotypeAdapter((Phenotype) dataset.getData());
    		
    	//numberof markers
    	int numberOfMarkers = theAdapter.getNumberOfMarkers();
    	
    	//are there markers? If not calculate BLUEs for taxa
    	if (numberOfMarkers == 0) {
    		return calculateBLUEsFromPhenotypes(theAdapter, dataset.getName());
    	} 
    	
    	//numbers of various model components
    	int numberOfCovariates = theAdapter.getNumberOfCovariates();
    	int numberOfFactors = theAdapter.getNumberOfFactors();
    	int numberOfPhenotypes = theAdapter.getNumberOfPhenotypes();
    	
    	//calculate total iterations
    	int expectedIterations = numberOfPhenotypes * numberOfMarkers;
    	int iterationsSofar = 0;
    	int percentFinished = 0;
    	
    	//open files for output if that was chosen
    	BufferedWriter ftestWriter = null;
    	BufferedWriter BLUEWriter = null;
    	if (writeOutputToFile) {
            String outputbase = outputName;
            if (outputbase.endsWith(".txt")) {
                int index = outputbase.lastIndexOf(".");
                outputbase = outputbase.substring(0, index);
            }
            String datasetNameNoSpace = dataset.getName().trim().replaceAll("\\ ", "_");
    		String ftestHeader;
    		String BLUEHeader;
			ftestHeader = "Trait\tMarker\tLocus\tLocus_pos\tChr\tChr_pos\tmarker_F\tmarker_p\tmarkerR2\tmarkerDF\tmarkerMS\terrorDF\terrorMS\tmodelDF\tmodelMS";
			BLUEHeader = "Trait\tMarker\tObs\tLocus\tLocus_pos\tChr\tChr_pos\tAllele\tEstimate";
    		File output = null;
    		try {
    			output = new File(outputbase + "_" + datasetNameNoSpace + "_ftest.txt");
    			int count = 0;
    			while (output.exists()) {
    				count++;
    				output = new File(outputbase + "_" + datasetNameNoSpace + "_ftest" + count + ".txt");
    			}
				ftestWriter = new BufferedWriter(new FileWriter(output));
				ftestWriter.write(ftestHeader);
				ftestWriter.newLine();
				
				if (reportBLUEs) {
	    			output = new File(outputbase + "_" + datasetNameNoSpace + "_BLUEs.txt");
	    			count = 0;
	    			while (output.exists()) {
	    				count++;
	    				output = new File(outputbase + "_" + datasetNameNoSpace + "_BLUEs" + count + ".txt");
	    			}
					BLUEWriter = new BufferedWriter(new FileWriter(output));
					BLUEWriter.write(BLUEHeader);
					BLUEWriter.newLine();
				}
			} catch (IOException e) {
				myLogger.error("Failed to open " + output.getName() + " for output");
				myLogger.error(e);
				return null;
			}
    	}
    	
    	//cycle through the phenotypes
    	//notation: 
    	//X is the design matrix without the markers, rows of X will be deleted if marker data is missing
    	//Xm is the design matrix with markers
    	//y is the data
    	
    	
    	for (int ph = 0; ph < numberOfPhenotypes; ph++) {
    		//get phenotype data
    		double[] phenotypeData = theAdapter.getPhenotypeValues(ph);
    		
    		//keep track of missing rows
    		boolean[] missing = theAdapter.getMissingPhenotypes(ph);
    		
    		//get factors
    		ArrayList<String[]> factorList = MarkerPhenotypeAdapterUtils.getFactorList(theAdapter, ph, missing);

    		//get covariates
    		ArrayList<double[]> covariateList = MarkerPhenotypeAdapterUtils.getCovariateList(theAdapter, ph, missing);

    		//cycle through the markers
    		for (int m = 0; m < numberOfMarkers; m++) {
    			Object[] markerData = theAdapter.getMarkerValue(ph, m);
    			boolean[] finalMissing = new boolean[missing.length];
    			System.arraycopy(missing, 0, finalMissing, 0, missing.length);
    			MarkerPhenotypeAdapterUtils.updateMissing(finalMissing, theAdapter.getMissingMarkers(ph, m));
    			
    			//identify the rows with no missing data
    			int[] nonmissingRows = MarkerPhenotypeAdapterUtils.getNonMissingIndex(finalMissing);

    			//number of observations in this data set
    			int numberOfObs = nonmissingRows.length;
    			
    			//the phenotype data
    			double[] y = new double[numberOfObs];
    			for (int i = 0; i < numberOfObs; i++) y[i] = phenotypeData[nonmissingRows[i]];

    			//keep track of X matrix columns, so that the position of marker effect estimates in beta can be determined
    			int firstMarkerAlleleEstimate = 1; //for the mean
    			
    			//first, add the mean to the model
    	    	ArrayList<ModelEffect> modelEffects = new ArrayList<ModelEffect>();
    			FactorModelEffect meanEffect = new FactorModelEffect(new int[numberOfObs], false);
    			meanEffect.setID("mean");
    			modelEffects.add(meanEffect);
    			
    			//add factors
    			if (numberOfFactors > 0) {
    				for (int f = 0; f < numberOfFactors; f++) {
    					String[] afactor = factorList.get(f);
    					String[] factorLabels = new String[numberOfObs];
    					for (int i = 0; i < numberOfObs; i++) factorLabels[i] = afactor[nonmissingRows[i]];
    					FactorModelEffect fme = new FactorModelEffect(ModelEffectUtils.getIntegerLevels(factorLabels), true, theAdapter.getFactorName(f));
    					modelEffects.add(fme);
    					firstMarkerAlleleEstimate += fme.getNumberOfLevels() - 1;
    				}
    			}
    			
    			//add covariates
    			if (numberOfCovariates > 0) {
    				for (int c = 0; c < numberOfCovariates; c++) {
    					double[] covar = new double[numberOfObs];
    					double[] covariateData = covariateList.get(c);
    					for (int i = 0; i < numberOfObs; i++) covar[i] = covariateData[nonmissingRows[i]];
    					modelEffects.add(new CovariateModelEffect(covar, theAdapter.getCovariateName(c)));
    					firstMarkerAlleleEstimate++;
    				}
    			}
    			
    			//add marker
    			ModelEffect markerEffect;
    			boolean markerIsDiscrete = theAdapter.isMarkerDiscrete(m);
    			ArrayList<Object> alleleNames = new ArrayList<Object>();
    			
    			if (markerIsDiscrete) {
        			Object[] markers = new Object[numberOfObs];
        			for (int i = 0; i < numberOfObs; i++) markers[i] = markerData[nonmissingRows[i]];
        			
        			int[] markerLevels = ModelEffectUtils.getIntegerLevels(markers, alleleNames);
    				markerEffect = new FactorModelEffect(markerLevels, true, theAdapter.getMarkerName(m));
    				hasAlleleNames = true;
    			}
    			else {
    				double[] markerdbl = new double[numberOfObs];
    				for (int i = 0; i < numberOfObs; i++)markerdbl[i] = ((Double)markerData[nonmissingRows[i]]).doubleValue();
    				markerEffect = new CovariateModelEffect(markerdbl, theAdapter.getMarkerName(m));
    			}

    			int[] alleleCounts = markerEffect.getLevelCounts();
    			modelEffects.add(markerEffect);
    			int markerEffectNumber = modelEffects.size() - 1;
    			
    			//if taxa are replicated, add taxa:marker to use as error term
    			//if the full list has duplicates, check to see if it still has
				Identifier[] taxaSublist = new Identifier[numberOfObs];
    			Identifier[] taxa = theAdapter.getTaxa(ph);
    			for (int i = 0; i < numberOfObs; i++) taxaSublist[i] = taxa[nonmissingRows[i]];
    			boolean areTaxaReplicated = containsDuplicates(taxaSublist);
    			
    			double[] markerSSdf = null, errorSSdf = null, modelSSdf = null;
    			double F,p;
    			double[] beta = null;
    			if (areTaxaReplicated && markerIsDiscrete) {
    				ModelEffect taxaEffect = new FactorModelEffect(ModelEffectUtils.getIntegerLevels(taxaSublist), true);
    				modelEffects.add(taxaEffect);
    				SweepFastNestedModel sfnm = new SweepFastNestedModel(modelEffects, y);
    				double[] taxaSSdf = sfnm.getTaxaInMarkerSSdf();
    				double[] residualSSdf = sfnm.getErrorSSdf();
    				markerSSdf = sfnm.getMarkerSSdf();
    				errorSSdf = sfnm.getErrorSSdf();
    				modelSSdf = sfnm.getModelcfmSSdf();
        			F = markerSSdf[0] / markerSSdf[1] / taxaSSdf[0] * taxaSSdf[1];
    				try {p = LinearModelUtils.Ftest(F, markerSSdf[1], taxaSSdf[1]);}
    				catch (Exception e) {p = Double.NaN;}
    				beta = sfnm.getBeta();
    			} else {
        			SweepFastLinearModel sflm = new SweepFastLinearModel(modelEffects, y);
        			modelSSdf = sflm.getModelcfmSSdf();
    				markerSSdf = sflm.getMarginalSSdf(markerEffectNumber);
    				errorSSdf = sflm.getResidualSSdf();
        			F = markerSSdf[0] / markerSSdf[1] / errorSSdf[0] * errorSSdf[1];
    				try {p = LinearModelUtils.Ftest(F, markerSSdf[1], errorSSdf[1]);}
    				catch (Exception e) {p = Double.NaN;}
    				beta = sflm.getBeta();
    			}
    			
    			//output: {"Trait", "Marker", "Locus", "Locus_pos", "Chr", "Chr_pos", "marker_F", "marker_p", "markerR2", "markerDF", 
				//	"markerMS", "errorDF", "errorMS", "modelDF", "modelMS"}
				
    			if (!filterOutput || p < maxp) {
    				String traitname = theAdapter.getPhenotypeName(ph);
    				if (traitname == null) traitname = blank;
    				String marker = theAdapter.getMarkerName(m);
    				if (marker == null) marker = blank;
    				String locus = theAdapter.getLocusName(m);
    				Integer site = new Integer(theAdapter.getLocusPosition(m));
    				String chrname = "";
    				Double chrpos = Double.NaN;
    				if (hasMap) {
    					int ndx = -1;
    					ndx = myMap.getMarkerIndex(marker);
    					if (ndx > -1) {
    						chrname = myMap.getChromosome(ndx);
    						chrpos = myMap.getGeneticPosition(ndx);
    					}
    				}

    				Object[] result = new Object[15];
    				result[0] = traitname;
    				result[1] = marker;
    				result[2] = locus;
    				result[3] = site;
    				result[4] = chrname;
    				result[5] = chrpos;
    				result[6] = new Double(F);
    				result[7] = new Double(p);
    				result[8] = new Double(markerSSdf[0]/(modelSSdf[0] + errorSSdf[0]));
    				result[9] = new Double(markerSSdf[1]);
    				result[10] = new Double(markerSSdf[0] / markerSSdf[1]);
    				result[11] = new Double(errorSSdf[1]);
    				result[12] = new Double(errorSSdf[0] / errorSSdf[1]);
    				result[13] = new Double(modelSSdf[1]);
    				result[14] = new Double(modelSSdf[0] / modelSSdf[1]);

    				if (writeOutputToFile) {
    					StringBuilder sb = new StringBuilder();
    					sb.append(result[0]);
    					for (int i = 1; i < 15; i++) sb.append("\t").append(result[i]);
    					try {
    						ftestWriter.write(sb.toString());
    						ftestWriter.newLine();
    					} catch (IOException e) {
    						myLogger.error("Failed to write output to ftest file. Ending prematurely");
    						try{
    							ftestWriter.flush();
    							BLUEWriter.flush();
    						} catch (Exception e1) {}
    						myLogger.error(e);
    						return null;
    					}
    				} else {
    					markerTestResults.add(result);
    				}
    				//leave phenotypic variance for later

    				//output allele estimates
    				//{"Trait", "Marker", "Locus", "Locus.Postion", "Chr", "Chr.pos", "Allele", "Estimate"}
    				int numberOfMarkerAlleles = alleleNames.size();
    				if (numberOfMarkerAlleles == 0) numberOfMarkerAlleles++;

    				for (int i = 0; i < numberOfMarkerAlleles; i++) {
    					result = new Object[9];
    					result[0] = traitname;
    					result[1] = marker;
    					result[2] = new Integer(alleleCounts[i]);
    					result[3] = locus;
    					result[4] = site;
    					result[5] = chrname;
    					result[6] = chrpos;

    					if (numberOfMarkerAlleles == 1) result[7] = "";
    					else result[7] = alleleNames.get(i);

    					if (i == numberOfMarkerAlleles - 1) result[8] = 0.0;
    					else result[8] = beta[firstMarkerAlleleEstimate + i];

    					if (writeOutputToFile) {
    						StringBuilder sb = new StringBuilder();
    						sb.append(result[0]);
    						for (int j = 1; j < 9; j++) sb.append("\t").append(result[j]);
    						try {
    							BLUEWriter.write(sb.toString());
    							BLUEWriter.newLine();
    						} catch (IOException e) {
    							myLogger.error("Failed to write output to ftest file. Ending prematurely");
    							try{
    								ftestWriter.flush();
    								BLUEWriter.flush();
    							} catch (Exception e1) {}
    							myLogger.error(e);
    							return null;
    						}
    					} else {
    						alleleEstimateResults.add(result);
    					}

    				}
    			}
    			
    			int tmpPercent = ++iterationsSofar * 100 / expectedIterations;
    			if (tmpPercent > percentFinished)  {
    				percentFinished = tmpPercent;
    				fireProgress(percentFinished);
    			}
    		}
    	}
    	
    	
    	//columns without meaningful information should be deleted from the data
    	//check to see if the adapter has marker names
    	//only report chr and chr.pos if there is a genetic map
    	
    	//set colnames
    	
    	if (writeOutputToFile) {
    		try {
    			ftestWriter.close();
    			BLUEWriter.close();
    		} catch (IOException e) {
    			e.printStackTrace();
    		}
    		fireProgress(0);
    		return null;
    	}
    	
    	String[] columnLabels = new String[]{"Trait", "Marker", "Locus", "Locus_pos", "Chr", "Chr_pos", "marker_F", "marker_p", "markerR2", "markerDF", 
    			"markerMS", "errorDF", "errorMS", "modelDF", "modelMS"};
    	boolean hasMarkerNames = theAdapter.hasMarkerNames();
    	int numberOfColumns = 6;
    	if (hasMarkerNames) numberOfColumns++;
    	if (hasMap) numberOfColumns += 2;
    	String[] colnames = new String[numberOfColumns];

    	int[] outputIndex;
    	if (hasMarkerNames && hasMap) {
    		outputIndex = new int[]{0,1,2,3,4,5,6,7,8,9,10,11,12,13,14};
    	} else if (hasMarkerNames) {
    		outputIndex = new int[]{0,1,2,3,6,7,8,9,10,11,12,13,14};
    	} else if (hasMap) {
    		outputIndex = new int[]{0,2,3,4,5,6,7,8,9,10,11,12,13,14};
    	} else {
    		outputIndex = new int[]{0,2,3,6,7,8,9,10,11,12,13,14};
    	}
    	
    	LinkedList<Datum> resultset = new LinkedList<Datum>();
    	int nrows = markerTestResults.size();
    	Object[][] table = new Object[nrows][];
    	
    	numberOfColumns = outputIndex.length;
    	colnames = new String[numberOfColumns];
    	for (int j = 0; j < numberOfColumns; j++) {
    		colnames[j] = columnLabels[outputIndex[j]];
    	}

    	for (int i = 0; i < nrows; i++) {
    		table[i] = new Object[numberOfColumns];
    		Object[] result = markerTestResults.get(i);
    		for (int j = 0; j < numberOfColumns; j++) {
    			table[i][j] = result[outputIndex[j]];
    		}
    	}
    	
    	//the table name and comments
    	StringBuilder tableName = new StringBuilder("GLM_marker_test_");
    	tableName.append(dataset.getName());
    	StringBuilder comments = new StringBuilder("Tests of Marker-Phenotype Association");
    	comments.append("GLM: fixed effect linear model\n");
    	comments.append("Data set: ").append(dataset.getName());
    	comments.append("\nmodel: trait = mean");
    	for (int i = 0; i < theAdapter.getNumberOfFactors(); i++) {
    		comments.append(" + ");
    		comments.append(theAdapter.getFactorName(i));
    	}
    	for (int i = 0; i < theAdapter.getNumberOfCovariates(); i++) {
    		comments.append(" + ");
    		comments.append(theAdapter.getCovariateName(i));
    	}
    	comments.append(" + marker");
    	
    	TableReport markerTestReport = new SimpleTableReport("Marker Test", colnames, table);
    	resultset.add(new Datum(tableName.toString(), markerTestReport, comments.toString()));

    	//add BLUE table
    	columnLabels  = new String[]{"Trait","Marker", "Obs", "Locus", "Locus_pos", "Chr", "Chr_pos", "Allele", "Estimate"}; 
    	if (hasAlleleNames) {
    		if (hasMarkerNames && hasMap) {
    			outputIndex = new int[]{0,1,2,3,4,5,6,7,8};
    		} else if (hasMarkerNames) {
    			outputIndex = new int[]{0,1,2,3,4,7,8};
    		} else if (hasMap) {
    			outputIndex = new int[]{0,2,3,4,5,6,7,8};
    		} else {
    			outputIndex = new int[]{0,2,3,4,7,8};
    		}
    	} else {
    		if (hasMarkerNames && hasMap) {
    			outputIndex = new int[]{0,1,2,3,4,5,6,8};
    		} else if (hasMarkerNames) {
    			outputIndex = new int[]{0,1,2,3,4,8};
    		} else if (hasMap) {
    			outputIndex = new int[]{0,2,3,4,5,6,8};
    		} else {
    			outputIndex = new int[]{0,2,3,4,8};
    		}
    	}
    	
    	nrows = alleleEstimateResults.size();
    	table = new Object[nrows][];
    	numberOfColumns = outputIndex.length;
    	colnames = new String[numberOfColumns];
    	for (int j = 0; j < numberOfColumns; j++) {
    		colnames[j] = columnLabels[outputIndex[j]];
    	}
    	for (int i = 0; i < nrows; i++) {
    		table[i] = new Object[numberOfColumns];
    		Object[] result = alleleEstimateResults.get(i);
    		for (int j = 0; j < numberOfColumns; j++) {
    			table[i][j] = result[outputIndex[j]];
    		}
    	}
    	
    	//the table name and comments
    	tableName = new StringBuilder("GLM allele estimates for ");
    	tableName.append(dataset.getName());
    	comments = new StringBuilder("Marker allele effect estimates\n");
    	comments.append("GLM: fixed effect linear model\n");
    	comments.append("Data set: ").append(dataset.getName());
    	comments.append("\nmodel: trait = mean");
    	for (int i = 0; i < theAdapter.getNumberOfFactors(); i++) {
    		comments.append(" + ");
    		comments.append(theAdapter.getFactorName(i));
    	}
    	for (int i = 0; i < theAdapter.getNumberOfCovariates(); i++) {
    		comments.append(" + ");
    		comments.append(theAdapter.getCovariateName(i));
    	}
    	comments.append(" + marker");
    	
    	TableReport alleleEstimateReport = new SimpleTableReport("Allele Estimates", colnames, table);
    	resultset.add(new Datum(tableName.toString(), alleleEstimateReport, comments.toString()));
    	fireProgress(0);
    	return resultset;
    }
    
    private LinkedList<Datum> calculateBLUEsFromPhenotypes(MarkerPhenotypeAdapter mpa, String datasetName) {
    	if (isInteractive()) {
    		String msg ="The data set you have selected does not contain any marker data. Do you want to calculate BLUEs (best linear unbiased estimates) of the phenotypes?";
    		String title = "Calculate BLUEs";
    		
    		int action = JOptionPane.showConfirmDialog(getParentFrame(), msg, title, JOptionPane.YES_NO_OPTION);
    		if (action != JOptionPane.YES_OPTION) return null;
    	}
    	
    	
    	LinkedList<Datum> theResults = new LinkedList<Datum>();
    	LinkedList<Object[]> anovaResults = new LinkedList<Object[]>();
    	LinkedList<double[]> blueList = new LinkedList<double[]>();
    	ArrayList<ArrayList<Object>> taxaListList = new ArrayList<ArrayList<Object>>();
    	
    	//numbers of various model components
    	int numberOfCovariates = mpa.getNumberOfCovariates();
    	int numberOfFactors = mpa.getNumberOfFactors();
    	int numberOfPhenotypes = mpa.getNumberOfPhenotypes();
    	
		//for each phenotype do the following:
    	for (int ph = 0; ph < numberOfPhenotypes; ph++) {

    		//get phenotype data
    		double[] phenotypeData = mpa.getPhenotypeValues(ph);
    		
    		//keep track of missing rows
    		boolean[] missing = mpa.getMissingPhenotypes(ph);
    		
    		//get factors
    		ArrayList<String[]> factorList = MarkerPhenotypeAdapterUtils.getFactorList(mpa, ph, missing);

    		//get covariates
    		ArrayList<double[]> covariateList = MarkerPhenotypeAdapterUtils.getCovariateList(mpa, ph, missing);

    		//identify the rows with no missing data
    		int[] nonmissingRows = MarkerPhenotypeAdapterUtils.getNonMissingIndex(missing);

    		//number of observations in this data set
    		int numberOfObs = nonmissingRows.length;

    		//the phenotype data
    		double[] y = new double[numberOfObs];
    		for (int i = 0; i < numberOfObs; i++) {
    			y[i] = phenotypeData[nonmissingRows[i]];
    		}

    		//first, add the mean to the model
    		ArrayList<ModelEffect> modelEffects = new ArrayList<ModelEffect>();
    		FactorModelEffect meanEffect = new FactorModelEffect(new int[numberOfObs], false);
    		meanEffect.setID("mean");
    		modelEffects.add(meanEffect);

    		//now add the taxa
    		Identifier[] alltaxa = mpa.getTaxa(ph);
    		Identifier[] taxa = new Identifier[numberOfObs];
    		ArrayList<Object> taxaIds = new ArrayList<Object>();
    		for (int i = 0; i < numberOfObs; i++) {
    			taxa[i] = alltaxa[nonmissingRows[i]];
    		}
    		int[] taxaLevels = ModelEffectUtils.getIntegerLevels(taxa, taxaIds);
    		taxaListList.add(taxaIds);
    		FactorModelEffect taxaEffect = new FactorModelEffect(taxaLevels, true, "Taxa");
    		modelEffects.add(taxaEffect);
    		
    		//add factors
    		if (numberOfFactors > 0) {
    			for (int f = 0; f < numberOfFactors; f++) {
    				String[] afactor = factorList.get(f);
    				String[] factorLabels = new String[numberOfObs];
    				for (int i = 0; i < numberOfObs; i++) factorLabels[i] = afactor[nonmissingRows[i]];
    				FactorModelEffect fme = new FactorModelEffect(ModelEffectUtils.getIntegerLevels(factorLabels), true, mpa.getFactorName(f));
    				modelEffects.add(fme);
    			}
    		}

    		//add covariates
    		if (numberOfCovariates > 0) {
    			for (int c = 0; c < numberOfCovariates; c++) {
    				double[] covar = new double[numberOfObs];
    				double[] covariateData = covariateList.get(c);
    				for (int i = 0; i < numberOfObs; i++) covar[i] = covariateData[nonmissingRows[i]];
    				modelEffects.add(new CovariateModelEffect(covar, mpa.getCovariateName(c)));
    			}
    		}
    		
        	//solve the model
			SweepFastLinearModel sflm = new SweepFastLinearModel(modelEffects, y);
			double[] taxaSSdf = sflm.getMarginalSSdf(1);
			double[] modelSSdf = sflm.getFullModelSSdf();
			double[] errorSSdf = sflm.getResidualSSdf();
			double[] beta = sflm.getBeta();
			double F, p;
			F = taxaSSdf[0] / taxaSSdf[1] / errorSSdf[0] * errorSSdf[1];
			try {p = LinearModelUtils.Ftest(F, taxaSSdf[1], errorSSdf[1]);}
			catch (Exception e) {p = Double.NaN;}

			//record {"Trait", "F", "p", "taxaDF", "taxaMS", "errorDF", "errorMS", "modelDF", "modelMS"}
	    	Object[] result = new Object[9];
	    	result[0] = mpa.getPhenotypeName(ph);
	    	result[1] = new Double(F);
	    	result[2] = new Double(p);
	    	result[3] = new Double(taxaSSdf[1]);
	    	result[4] = new Double(taxaSSdf[0] / taxaSSdf[1]);
	    	result[5] = new Double(errorSSdf[1]);
	    	result[6] = new Double(errorSSdf[0] / errorSSdf[1]);
	    	result[7] = new Double(modelSSdf[1]);
	    	result[8] = new Double(modelSSdf[0] / modelSSdf[1]);
	    	anovaResults.add(result);
	    	
	    	// calculate the BLUEs for taxa
	    	// first calculate the average of the level estimates for all other factors (including the mean)
	    	double overallMean = beta[0]; //the mean
	    	int nEffects = modelEffects.size();
	    	int start = 0;
	    	for (int i = 1; i < nEffects; i++) {
	    		ModelEffect me = modelEffects.get(i);
	    		if (me instanceof FactorModelEffect && !me.getID().equals("Taxa")) {
	    			FactorModelEffect fme  = (FactorModelEffect) me;
	    			int nLevels = fme.getNumberOfLevels();
	    			int nEstimates;
	    			if (fme.getRestricted()) {
	    				nEstimates = nLevels - 1;
	    			} else {
	    				nEstimates = nLevels;
	    			}
	    			double factorMean = 0;
	    			for (int j = 0; j < nEstimates; j++) {
	    				factorMean += beta[j + start];
	    			}
	    			factorMean /= nLevels;
	    			overallMean += factorMean;
	    			start += nEstimates;
	    		} else {
	    			start += me.getNumberOfLevels();
	    		}
	    	}
	    	
	    	int n = taxaIds.size();
	    	double[] blues = new double[n];
	    	for (int i = 0; i < n - 1; i++) {
	    		blues[i] = beta[i + 1] + overallMean;
	    	}
			
	    	blueList.add(blues);
	    	taxaListList.add(taxaIds);
	    	
    	}
    	
    	//add the anova table to the results
    	String[] anovaColumnLabels = new String[]{"Trait", "F", "p", "taxaDF", "taxaMS", "errorDF", "errorMS", "modelDF", "modelMS"};
    	Object[][] table = new Object[anovaResults.size()][];
    	anovaResults.toArray(table);
    	String datumName = "Phenotype ANOVA from " + datasetName;
    	StringBuilder datumComments = new StringBuilder("ANOVA for Phenotypes using GLM\n");
    	datumComments.append("Data set: ").append(datasetName);
    	datumComments.append("\nmodel: trait = mean + taxa");
    	for (int i = 0; i < mpa.getNumberOfFactors(); i++) {
    		datumComments.append(" + ");
    		datumComments.append(mpa.getFactorName(i));
    	}
    	for (int i = 0; i < mpa.getNumberOfCovariates(); i++) {
    		datumComments.append(" + ");
    		datumComments.append(mpa.getCovariateName(i));
    	}

    	SimpleTableReport str = new SimpleTableReport(datumName, anovaColumnLabels, table);
    	Datum theAnova = new Datum(datumName, str, datumComments.toString());
    	theResults.add(theAnova);

    	//add the BLUEs to the results
    	//the individual phenotypes must first be merged to create a unified table with taxa as rows and phenotypes as columns
    	
    	TreeSet<Identifier> taxaSet = new TreeSet<Identifier>();
    	for (ArrayList<Object> list : taxaListList) {
    		for (Object taxon:list) taxaSet.add((Identifier) taxon);
    	}
    	
    	HashMap<Identifier, Integer> taxaMap = new HashMap<Identifier, Integer>();
    	int count = 0;
    	for (Identifier taxon:taxaSet) {
    		taxaMap.put(taxon, count++);
    	}
    	String[] blueColumnLabels = new String[numberOfPhenotypes + 1];
    	blueColumnLabels[0] = "Taxa";
    	for (int i = 0; i < numberOfPhenotypes; i++) {
    		blueColumnLabels[i + 1] = mpa.getPhenotypeName(i);
    	}
    	
    	int nrows = taxaSet.size();
    	double[][] blues = new double[nrows][numberOfPhenotypes];
    	for (int r = 0; r < nrows; r++) {
    		for (int c = 0; c < numberOfPhenotypes; c++) {
    			blues[r][c] = Double.NaN;
    		}
    	}
    	
    	LinkedList<Trait> traitList = new LinkedList<Trait>();
    	for (int c = 0; c < numberOfPhenotypes; c++) {
    		traitList.add(new Trait(mpa.getPhenotypeName(c), false, Trait.TYPE_DATA));
    		double[] pheno = blueList.get(c);
    		int n = pheno.length;
    		ArrayList<Object> taxaList = taxaListList.get(c);
    		for (int i = 0; i < n; i++) {
    			int ndx = taxaMap.get(taxaList.get(i));
    			if (ndx > -1) blues[ndx][c] = pheno[i];
    		}
    	}
    	
    	Identifier[] taxaIds = new Identifier[taxaSet.size()];
    	taxaSet.toArray(taxaIds);
    	Phenotype thePhenotype = new SimplePhenotype(new SimpleIdGroup(taxaIds), traitList, blues);
    	
    	theResults.add(new Datum("BLUEs_" + datasetName, thePhenotype, "BLUEs calculated from " + datasetName));
    	return theResults;
    }
    
	@Override
	public String getButtonName() {
        return "GLM";
	}

	@Override
	public ImageIcon getIcon() {
        URL imageURL = FixedEffectLMPlugin.class.getResource("images/LinearAssociation.gif");
        if(imageURL == null)
            {return null;}
        else {return new ImageIcon(imageURL);}
	}

	@Override
	public String getToolTipText() {
        return "Use fixed effect model to test associations";
	}

	private boolean containsDuplicates(Identifier[] ids) {
		HashSet<Identifier> idSet = new HashSet<Identifier>();
		for (Identifier id:ids) idSet.add(id);
		if (idSet.size() < ids.length) return true;
		return false;
	}
    
    public void setOutputFile(String filename) {
        writeOutputToFile = true;
        outputName = filename;
    }

    public void setRestrictOutput(boolean restrict) {
        filterOutput = restrict;
    }

    public void setMaxP(double value) {
        filterOutput = true;
        maxp = value;
    }

}
